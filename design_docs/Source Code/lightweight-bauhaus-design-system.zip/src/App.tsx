import React, { useState } from 'react';
import { NavigationTab, ScreenModule } from './types';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DesignBriefOverview } from './components/brief/DesignBriefOverview';
import { ComponentLibrary } from './components/brief/ComponentLibrary';
import { TokenInspector } from './components/brief/TokenInspector';
import { DesignSpecDocument } from './components/brief/DesignSpecDocument';
import { DashboardScreen } from './components/screens/DashboardScreen';
import { AnnouncementsScreen } from './components/screens/AnnouncementsScreen';
import { RolloverWizardScreen } from './components/screens/RolloverWizardScreen';
import { StudentDirectoryScreen } from './components/screens/StudentDirectoryScreen';
import { BulkEditorScreen } from './components/screens/BulkEditorScreen';
import { ModuleManagerScreen } from './components/screens/ModuleManagerScreen';
import { GradingDashboardScreen } from './components/screens/GradingDashboardScreen';
import { AssignmentTemplatesScreen } from './components/screens/AssignmentTemplatesScreen';
import { RubricManagerScreen } from './components/screens/RubricManagerScreen';
import { AssignmentGroupsScreen } from './components/screens/AssignmentGroupsScreen';
import { AssignmentCopyScreen } from './components/screens/AssignmentCopyScreen';
import { QuizBuilderScreen } from './components/screens/QuizBuilderScreen';
import { MissingWorkScreen } from './components/screens/MissingWorkScreen';
import { GradeAdjustmentsScreen } from './components/screens/GradeAdjustmentsScreen';
import { LatePolicyScreen } from './components/screens/LatePolicyScreen';
import { CommunicationNudgesScreen } from './components/screens/CommunicationNudgesScreen';
import { StudentGroupsScreen } from './components/screens/StudentGroupsScreen';
import { SectionsManagerScreen } from './components/screens/SectionsManagerScreen';
import { AccommodationsScreen } from './components/screens/AccommodationsScreen';
import { AccommodationCreatorScreen } from './components/screens/AccommodationCreatorScreen';
import { SpeedGraderSuiteScreen } from './components/screens/SpeedGraderSuiteScreen';
import { SecurityAuditScreen } from './components/screens/SecurityAuditScreen';
import { SettingsPreferencesScreen } from './components/screens/SettingsPreferencesScreen';
import { GradeOutreachScreen } from './components/screens/GradeOutreachScreen';
import { ScreenCodeHeader } from './components/ScreenCodeHeader';
import { AppTestWorkflow } from './components/AppTestWorkflow';

export function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('design-brief');
  const [activeScreen, setActiveScreen] = useState<ScreenModule>('dashboard');
  const [selectedCourse, setSelectedCourse] = useState('Biology 101 — Principles of Life');

  const handleNavigateScreen = (screen: ScreenModule) => {
    setActiveTab('screens');
    setActiveScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#FAF9F5] text-[#1B1C1A] font-sans antialiased selection:bg-[#B7102A] selection:text-white flex flex-col">
      {/* Global Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedCourse={selectedCourse}
        setSelectedCourse={setSelectedCourse}
        activeScreen={activeScreen}
        setActiveScreen={setActiveScreen}
      />

      {/* Main Body Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          activeScreen={activeScreen}
          setActiveScreen={setActiveScreen}
        />

        {/* Primary Content Viewport */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto max-w-7xl mx-auto w-full">
          {activeTab === 'design-brief' && <DesignBriefOverview />}

          {activeTab === 'screens' && (
            <>
              <ScreenCodeHeader
                activeScreen={activeScreen}
                onNavigateScreen={handleNavigateScreen}
              />

              {activeScreen === 'dashboard' && (
                <DashboardScreen onNavigateScreen={handleNavigateScreen} />
              )}
              {activeScreen === 'announcements' && <AnnouncementsScreen />}
              {activeScreen === 'rollover-wizard' && <RolloverWizardScreen />}
              {activeScreen === 'student-directory' && <StudentDirectoryScreen />}
              {activeScreen === 'bulk-editor' && <BulkEditorScreen />}
              {activeScreen === 'module-manager' && <ModuleManagerScreen />}
              {activeScreen === 'grading-dashboard' && <GradingDashboardScreen />}
              {activeScreen === 'assignment-templates' && <AssignmentTemplatesScreen />}
              {activeScreen === 'rubric-manager' && <RubricManagerScreen />}
              {activeScreen === 'assignment-groups' && <AssignmentGroupsScreen />}
              {activeScreen === 'assignment-copy' && <AssignmentCopyScreen />}
              {activeScreen === 'quiz-builder' && <QuizBuilderScreen />}
              {activeScreen === 'missing-work' && <MissingWorkScreen />}
              {activeScreen === 'grade-adjustments' && <GradeAdjustmentsScreen />}
              {activeScreen === 'late-policy' && <LatePolicyScreen />}
              {activeScreen === 'communication-nudges' && <CommunicationNudgesScreen />}
              {activeScreen === 'student-groups' && <StudentGroupsScreen />}
              {activeScreen === 'sections-manager' && <SectionsManagerScreen />}
              {activeScreen === 'accommodations' && (
                <AccommodationsScreen onNavigateScreen={handleNavigateScreen} />
              )}
              {activeScreen === 'accommodation-creator' && (
                <AccommodationCreatorScreen onNavigateScreen={handleNavigateScreen} />
              )}
              {activeScreen === 'speedgrader-suite' && <SpeedGraderSuiteScreen />}
              {activeScreen === 'security-audit' && <SecurityAuditScreen />}
              {activeScreen === 'settings-preferences' && <SettingsPreferencesScreen />}
              {activeScreen === 'grade-outreach' && <GradeOutreachScreen />}
            </>
          )}

          {activeTab === 'component-library' && <ComponentLibrary />}
          {activeTab === 'token-inspector' && <TokenInspector />}
          {activeTab === 'spec-document' && <DesignSpecDocument />}
          {activeTab === 'app-test' && <AppTestWorkflow />}
        </main>
      </div>
    </div>
  );
}

export default App;
