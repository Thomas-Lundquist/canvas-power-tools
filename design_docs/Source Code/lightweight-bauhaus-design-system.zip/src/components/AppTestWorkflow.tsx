import React, { useState } from 'react';
import { ScreenModule } from '../types';
import {
  RotateCw,
  Settings,
  Lock,
  FileText,
  Copy,
  Layers,
  PieChart,
  CheckSquare,
  FolderKanban,
  Code2,
  BarChart2,
  AlertTriangle,
  TrendingUp,
  Clock,
  GraduationCap,
  Users,
  ShieldCheck,
  Plus,
  Megaphone,
  Send,
  Repeat,
  ArrowLeft,
  Zap,
  ChevronDown,
  ChevronUp,
  Home,
  BookOpen,
  Sliders,
  ChevronRight
} from 'lucide-react';

// Screen Components
import { DashboardScreen } from './screens/DashboardScreen';
import { AnnouncementsScreen } from './screens/AnnouncementsScreen';
import { RolloverWizardScreen } from './screens/RolloverWizardScreen';
import { StudentDirectoryScreen } from './screens/StudentDirectoryScreen';
import { BulkEditorScreen } from './screens/BulkEditorScreen';
import { ModuleManagerScreen } from './screens/ModuleManagerScreen';
import { GradingDashboardScreen } from './screens/GradingDashboardScreen';
import { AssignmentTemplatesScreen } from './screens/AssignmentTemplatesScreen';
import { RubricManagerScreen } from './screens/RubricManagerScreen';
import { AssignmentGroupsScreen } from './screens/AssignmentGroupsScreen';
import { AssignmentCopyScreen } from './screens/AssignmentCopyScreen';
import { QuizBuilderScreen } from './screens/QuizBuilderScreen';
import { MissingWorkScreen } from './screens/MissingWorkScreen';
import { GradeAdjustmentsScreen } from './screens/GradeAdjustmentsScreen';
import { LatePolicyScreen } from './screens/LatePolicyScreen';
import { CommunicationNudgesScreen } from './screens/CommunicationNudgesScreen';
import { StudentGroupsScreen } from './screens/StudentGroupsScreen';
import { SectionsManagerScreen } from './screens/SectionsManagerScreen';
import { AccommodationsScreen } from './screens/AccommodationsScreen';
import { AccommodationCreatorScreen } from './screens/AccommodationCreatorScreen';
import { SpeedGraderSuiteScreen } from './screens/SpeedGraderSuiteScreen';
import { SecurityAuditScreen } from './screens/SecurityAuditScreen';
import { SettingsPreferencesScreen } from './screens/SettingsPreferencesScreen';
import { GradeOutreachScreen } from './screens/GradeOutreachScreen';

export interface ModuleTool {
  id: ScreenModule;
  label: string;
  description: string;
  icon: React.ReactNode;
}

export interface ParentModule {
  id: string;
  name: string;
  badgeColor: string;
  borderTopColor: string;
  icon: React.ReactNode;
  defaultToolId: ScreenModule;
  tools: ModuleTool[];
}

export const CORE_PARENT_MODULES: ParentModule[] = [
  {
    id: 'assignments',
    name: 'Assignments',
    badgeColor: 'bg-[#2563EB] text-white',
    borderTopColor: 'border-t-[#2563EB]',
    icon: <CheckSquare className="w-4 h-4 text-[#2563EB]" />,
    defaultToolId: 'bulk-editor',
    tools: [
      { id: 'bulk-editor', label: 'Bulk Assignment Editor', description: 'Batch update dates, points, titles & publishing', icon: <CheckSquare className="w-3.5 h-3.5 text-[#2563EB]" /> },
      { id: 'assignment-templates', label: 'Templates Library', description: 'Capture & deploy course assignment blueprints', icon: <FileText className="w-3.5 h-3.5 text-[#B7102A]" /> },
      { id: 'assignment-copy', label: 'Cross-Course Copy', description: 'Copy assignments between courses with offset', icon: <Copy className="w-3.5 h-3.5 text-[#2563EB]" /> },
      { id: 'quiz-builder', label: 'Quiz Builder & Import', description: 'Author New Quizzes or import Markdown files', icon: <Code2 className="w-3.5 h-3.5 text-[#B7102A]" /> }
    ]
  },
  {
    id: 'grading',
    name: 'Grading',
    badgeColor: 'bg-[#059669] text-white',
    borderTopColor: 'border-t-[#059669]',
    icon: <BarChart2 className="w-4 h-4 text-[#059669]" />,
    defaultToolId: 'grading-dashboard',
    tools: [
      { id: 'grading-dashboard', label: 'Grading Overview', description: 'Progress monitor across all course assignments', icon: <BarChart2 className="w-3.5 h-3.5 text-[#059669]" /> },
      { id: 'missing-work', label: 'Missing Work Tracker', description: 'Track zero grades & bulk send unsubmitted nudges', icon: <AlertTriangle className="w-3.5 h-3.5 text-[#D97706]" /> },
      { id: 'grade-adjustments', label: 'Grade Curving', description: 'Mathematical grade adjustment curves', icon: <TrendingUp className="w-3.5 h-3.5 text-[#059669]" /> },
      { id: 'late-policy', label: 'Late Policy Manager', description: 'Automated late penalty deductions', icon: <Clock className="w-3.5 h-3.5 text-[#059669]" /> },
      { id: 'assignment-groups', label: 'Group Weights & Sim', description: 'Model gradebook group weights before saving', icon: <PieChart className="w-3.5 h-3.5 text-[#059669]" /> },
      { id: 'rubric-manager', label: 'Rubric Manager', description: 'Build, copy & attach rubrics across courses', icon: <Layers className="w-3.5 h-3.5 text-[#059669]" /> },
      { id: 'speedgrader-suite', label: 'SpeedGrader Suite', description: 'Injected comment bank & progress tools', icon: <GraduationCap className="w-3.5 h-3.5 text-[#059669]" /> }
    ]
  },
  {
    id: 'people',
    name: 'People',
    badgeColor: 'bg-[#EA580C] text-white',
    borderTopColor: 'border-t-[#EA580C]',
    icon: <Users className="w-4 h-4 text-[#EA580C]" />,
    defaultToolId: 'student-directory',
    tools: [
      { id: 'student-directory', label: 'Student Directory', description: 'Roster view, sections & student details', icon: <Users className="w-3.5 h-3.5 text-[#EA580C]" /> },
      { id: 'student-groups', label: 'Student Group Sets', description: 'Auto-grouping, random splits & tiering', icon: <Users className="w-3.5 h-3.5 text-[#EA580C]" /> },
      { id: 'sections-manager', label: 'Section Manager', description: 'Section-based due dates & analytics', icon: <Users className="w-3.5 h-3.5 text-[#EA580C]" /> },
      { id: 'accommodations', label: 'Accommodations', description: 'FERPA-compliant student date overrides', icon: <ShieldCheck className="w-3.5 h-3.5 text-[#EA580C]" /> },
      { id: 'accommodation-creator', label: 'Accommodation Creator', description: 'Build and deploy date extensions & extra time rules', icon: <Plus className="w-3.5 h-3.5 text-[#EA580C]" /> }
    ]
  },
  {
    id: 'communication',
    name: 'Communication',
    badgeColor: 'bg-[#7C3AED] text-white',
    borderTopColor: 'border-t-[#7C3AED]',
    icon: <Megaphone className="w-4 h-4 text-[#7C3AED]" />,
    defaultToolId: 'announcements',
    tools: [
      { id: 'announcements', label: 'Announcements Engine', description: 'Schedule & broadcast cross-course messages', icon: <Megaphone className="w-3.5 h-3.5 text-[#7C3AED]" /> },
      { id: 'communication-nudges', label: 'Student Nudges', description: 'Targeted threshold & unsubmitted reminders', icon: <Send className="w-3.5 h-3.5 text-[#7C3AED]" /> },
      { id: 'grade-outreach', label: 'Recurring Outreach', description: 'Automated periodic grade status emails', icon: <Repeat className="w-3.5 h-3.5 text-[#7C3AED]" /> }
    ]
  },
  {
    id: 'content-modules',
    name: 'Content Modules',
    badgeColor: 'bg-[#0D9488] text-white',
    borderTopColor: 'border-t-[#0D9488]',
    icon: <FolderKanban className="w-4 h-4 text-[#0D9488]" />,
    defaultToolId: 'module-manager',
    tools: [
      { id: 'module-manager', label: 'Module Manager', description: 'Organize course pages, items & prerequisites', icon: <FolderKanban className="w-3.5 h-3.5 text-[#0D9488]" /> }
    ]
  },
  {
    id: 'admin-setup',
    name: 'Admin & Setup',
    badgeColor: 'bg-[#334155] text-white',
    borderTopColor: 'border-t-[#334155]',
    icon: <Sliders className="w-4 h-4 text-[#334155]" />,
    defaultToolId: 'rollover-wizard',
    tools: [
      { id: 'rollover-wizard', label: 'Semester Rollover', description: 'Course copy date shifter & health checks', icon: <RotateCw className="w-3.5 h-3.5 text-[#334155]" /> },
      { id: 'security-audit', label: 'PIN Security Audit', description: 'Inactivity pin protection & audit trail', icon: <Lock className="w-3.5 h-3.5 text-[#1B1C1A]" /> },
      { id: 'settings-preferences', label: 'Extension Settings', description: 'API token setup & developer preferences', icon: <Settings className="w-3.5 h-3.5 text-[#1B1C1A]" /> }
    ]
  }
];

export const AppTestWorkflow: React.FC = () => {
  const [activeScreen, setActiveScreen] = useState<ScreenModule>('dashboard');
  const [guideMinimized, setGuideMinimized] = useState<boolean>(true);

  // Find parent module for active screen
  let activeParentModule: ParentModule | null = null;
  let activeTool: ModuleTool | null = null;

  if (activeScreen !== 'dashboard') {
    for (const p of CORE_PARENT_MODULES) {
      const match = p.tools.find((t) => t.id === activeScreen);
      if (match) {
        activeParentModule = p;
        activeTool = match;
        break;
      }
    }
  }

  const isDashboard = activeScreen === 'dashboard';

  const handleNavigate = (target: ScreenModule) => {
    setActiveScreen(target);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* 1. MINIMIZABLE WORKFLOW TEST CONTROLLER BANNER */}
      <div className="bg-[#1B1C1A] text-white rounded-[2px] border-2 border-[#1B1C1A] shadow-md transition-all">
        {/* Toggle Bar */}
        <div className="p-2.5 px-4 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 bg-[#FEF08A] text-[#1B1C1A] font-bold text-[10px] uppercase rounded-[1px] flex items-center gap-1">
              <Zap className="w-3 h-3 fill-current" />
              <span>APP TEST MODE</span>
            </span>
            <span className="text-gray-300 font-bold hidden sm:inline">
              Module: <span className="text-[#FEF08A]">{activeParentModule ? activeParentModule.name : 'Dashboard'}</span>
              {activeTool && <span className="text-gray-400"> › {activeTool.label}</span>}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setGuideMinimized(!guideMinimized)}
              className="text-[11px] text-gray-300 hover:text-white flex items-center gap-1 uppercase font-bold underline decoration-dotted"
            >
              <span>{guideMinimized ? 'Expand Test Bar' : 'Minimize Test Bar'}</span>
              {guideMinimized ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Expanded Guide Content */}
        {!guideMinimized && (
          <div className="p-4 border-t border-gray-800 space-y-3 font-mono text-xs bg-gray-950">
            <p className="text-gray-300 leading-relaxed">
              This environment simulates the live Canvas power extension with all 6 core modules fully connected.
            </p>

            <div className="flex flex-wrap items-center justify-between gap-3 bg-gray-900 p-2.5 rounded-[2px]">
              <span className="text-[#FEF08A] font-bold">JUMP TO TOOL:</span>
              <select
                value={activeScreen}
                onChange={(e) => handleNavigate(e.target.value as ScreenModule)}
                className="bg-white text-[#1B1C1A] p-1.5 font-bold rounded-[1px] text-xs outline-none"
              >
                <option value="dashboard">🏠 Main Command Dashboard</option>
                {CORE_PARENT_MODULES.map((pm) => (
                  <optgroup key={pm.id} label={`--- ${pm.name} Module ---`}>
                    {pm.tools.map((tool) => (
                      <option key={tool.id} value={tool.id}>
                        {tool.label}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>
          </div>
        )}
      </div>

      {/* 2. AUTHENTIC REAL-WORLD CANVAS APPLICATION SHELL */}
      <div className="bg-white border-2 border-[#1B1C1A] rounded-[2px] shadow-sm overflow-hidden">
        {/* Top Navigation Bar */}
        <div className="bg-[#1B1C1A] text-white p-3 px-4 flex flex-wrap items-center justify-between gap-3 font-mono text-xs">
          {/* Brand Logo & Course Selector */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleNavigate('dashboard')}
              className="flex items-center gap-2 hover:opacity-90 transition-opacity text-left"
            >
              <div className="p-1.5 bg-[#B7102A] text-white font-black rounded-[1px]">
                <BookOpen className="w-4 h-4" />
              </div>
              <div>
                <strong className="text-sm font-black uppercase text-white block leading-none">
                  CANVAS POWER TOOLS
                </strong>
                <span className="text-[10px] text-gray-400 block mt-0.5">BIOLOGY 101 // FALL 2026</span>
              </div>
            </button>
          </div>

          {/* Top Navbar Links (Home Only as requested) */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleNavigate('dashboard')}
              className={`px-3 py-1.5 rounded-[2px] font-bold uppercase transition-all flex items-center gap-1.5 ${
                isDashboard
                  ? 'bg-[#FEF08A] text-[#1B1C1A]'
                  : 'bg-gray-800 text-gray-200 hover:bg-gray-700'
              }`}
            >
              <Home className="w-3.5 h-3.5" />
              <span>HOME</span>
            </button>
          </div>

          {/* API Status Pill */}
          <div className="hidden lg:flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[10px] text-gray-300 font-bold uppercase">CANVAS API READY</span>
          </div>
        </div>

        {/* Breadcrumb Navigation Bar */}
        <div className="bg-[#FAF9F5] border-b border-[#1B1C1A] p-3 px-4 flex flex-wrap items-center justify-between gap-3 font-mono text-xs">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-gray-600">
            <button
              onClick={() => handleNavigate('dashboard')}
              className="hover:text-[#B7102A] font-bold uppercase"
            >
              Canvas Home
            </button>
            {activeParentModule && (
              <>
                <span>/</span>
                <span className="font-bold text-gray-700 uppercase">{activeParentModule.name}</span>
              </>
            )}
            {activeTool && (
              <>
                <span>/</span>
                <span className="font-extrabold text-[#1B1C1A] uppercase bg-[#FEF08A] px-2 py-0.5 border border-[#1B1C1A]">
                  {activeTool.label}
                </span>
              </>
            )}
          </div>

          {/* Fast Navigation Buttons */}
          <div className="flex items-center gap-2">
            {!isDashboard && (
              <button
                onClick={() => handleNavigate('dashboard')}
                className="px-3 py-1 bg-white hover:bg-gray-100 border border-[#1B1C1A] font-bold text-[11px] uppercase rounded-[2px] transition-all flex items-center gap-1 text-[#1B1C1A]"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>MAIN DASHBOARD</span>
              </button>
            )}
          </div>
        </div>

        {/* 3. MAIN WORKFLOW CONTENT CONTAINER */}
        <div className="flex flex-col md:flex-row min-h-[650px] bg-white">
          {/* IN-MODULE TOOL SIDEBAR (HIDDEN ON DASHBOARD) */}
          {!isDashboard && (
            <aside className="w-full md:w-64 bg-[#FAF9F5] border-b md:border-b-0 md:border-r border-[#1B1C1A] p-4 font-mono text-xs space-y-4 shrink-0">
              {/* Sidebar Header */}
              <div className="pb-2 border-b border-gray-300 flex items-center justify-between">
                <span className="font-extrabold uppercase text-[11px] text-[#1B1C1A] flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-[#B7102A]" />
                  <span>MODULE NAVIGATION</span>
                </span>
              </div>

              {/* Home Link */}
              <button
                onClick={() => handleNavigate('dashboard')}
                className="w-full text-left p-2 rounded-[1px] font-bold uppercase transition-all flex items-center gap-2 border bg-white text-gray-800 border-gray-200 hover:border-[#1B1C1A]"
              >
                <Home className="w-3.5 h-3.5 text-[#B7102A]" />
                <span>Command Center</span>
              </button>

              {/* The 6 Core Parent Modules & Their Member Tools */}
              <div className="space-y-4 pt-1">
                <div className="text-[10px] font-bold text-gray-500 uppercase tracking-wider px-1">
                  Core Canvas Modules (6)
                </div>

                {CORE_PARENT_MODULES.map((pm) => {
                  const isCurrentParent = activeParentModule?.id === pm.id;

                  return (
                    <div
                      key={pm.id}
                      className={`border rounded-[2px] transition-all overflow-hidden ${
                        isCurrentParent
                          ? 'border-[#1B1C1A] bg-white shadow-xs'
                          : 'border-gray-200 bg-[#EFEEEA]/60'
                      }`}
                    >
                      {/* Parent Module Header / Switch Button */}
                      <button
                        onClick={() => handleNavigate(pm.defaultToolId)}
                        className={`w-full text-left p-2.5 font-bold uppercase flex items-center justify-between border-b ${
                          isCurrentParent
                            ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                            : 'bg-white text-gray-800 border-gray-200 hover:bg-gray-100'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          {pm.icon}
                          <span className="truncate">{pm.name}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-[9px] px-1 py-0.2 font-mono bg-white/20 rounded-[1px]">
                            {pm.tools.length}
                          </span>
                          <ChevronRight
                            className={`w-3.5 h-3.5 transition-transform ${
                              isCurrentParent ? 'rotate-90' : ''
                            }`}
                          />
                        </div>
                      </button>

                      {/* Member Tools inside Parent Module */}
                      {isCurrentParent && (
                        <div className="p-1.5 space-y-1 bg-white">
                          <div className="text-[9px] font-bold text-gray-400 uppercase tracking-widest px-2 py-1">
                            {pm.name} Tools
                          </div>
                          {pm.tools.map((tool) => {
                            const isToolActive = activeScreen === tool.id;
                            return (
                              <button
                                key={tool.id}
                                onClick={() => handleNavigate(tool.id)}
                                className={`w-full text-left px-2.5 py-1.5 rounded-[1px] text-[11px] font-bold transition-all flex items-center justify-between border ${
                                  isToolActive
                                    ? 'bg-[#FEF08A] text-[#1B1C1A] border-[#1B1C1A] shadow-xs'
                                    : 'bg-transparent text-gray-700 border-transparent hover:bg-[#FAF9F5] hover:border-gray-300'
                                }`}
                              >
                                <div className="flex items-center gap-2 truncate">
                                  {tool.icon}
                                  <span className="truncate">{tool.label}</span>
                                </div>
                                {isToolActive && (
                                  <span className="w-1.5 h-1.5 rounded-full bg-[#B7102A] shrink-0" />
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </aside>
          )}

          {/* Main Screen Module Content Area */}
          <main className="flex-1 p-6 bg-white overflow-x-auto">
            {activeScreen === 'dashboard' && <DashboardScreen onNavigateScreen={handleNavigate} />}
            {activeScreen === 'announcements' && <AnnouncementsScreen />}
            {activeScreen === 'rollover-wizard' && <RolloverWizardScreen />}
            {activeScreen === 'student-directory' && <StudentDirectoryScreen />}
            {activeScreen === 'bulk-editor' && <BulkEditorScreen />}
            {activeScreen === 'module-manager' && <ModuleManagerScreen />}
            {activeScreen === 'grading-dashboard' && <GradingDashboardScreen />}
            {activeScreen === 'assignment-templates' && <AssignmentTemplatesScreen />}
            {activeScreen === 'rubric-manager' && <RubricManagerScreen />}
            {activeScreen === 'assignment-groups' && <AssignmentGroupsScreen />}
            {activeScreen === 'assignment-copy' && <AssignmentCopyScreen />}
            {activeScreen === 'quiz-builder' && <QuizBuilderScreen />}
            {activeScreen === 'missing-work' && <MissingWorkScreen />}
            {activeScreen === 'grade-adjustments' && <GradeAdjustmentsScreen />}
            {activeScreen === 'late-policy' && <LatePolicyScreen />}
            {activeScreen === 'communication-nudges' && <CommunicationNudgesScreen />}
            {activeScreen === 'student-groups' && <StudentGroupsScreen />}
            {activeScreen === 'sections-manager' && <SectionsManagerScreen />}
            {activeScreen === 'accommodations' && <AccommodationsScreen onNavigateScreen={handleNavigate} />}
            {activeScreen === 'accommodation-creator' && <AccommodationCreatorScreen onNavigateScreen={handleNavigate} />}
            {activeScreen === 'speedgrader-suite' && <SpeedGraderSuiteScreen />}
            {activeScreen === 'security-audit' && <SecurityAuditScreen />}
            {activeScreen === 'settings-preferences' && <SettingsPreferencesScreen />}
            {activeScreen === 'grade-outreach' && <GradeOutreachScreen />}
          </main>
        </div>
      </div>
    </div>
  );
};
