import React, { useState, useEffect } from 'react';
import {
  FileText,
  Calendar,
  Layers,
  CheckCircle,
  X,
  Upload,
  Shield,
  Users,
  Sparkles,
  Save,
  Globe,
  Clock,
  Sliders,
  Check,
  AlertCircle,
  FileCode
} from 'lucide-react';
import { Assignment } from '../types';

interface AssignmentEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (assignment: Assignment) => void;
  initialAssignment?: Assignment | null;
}

export const AssignmentEditorModal: React.FC<AssignmentEditorModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialAssignment
}) => {
  const isEditing = !!initialAssignment;

  const [title, setTitle] = useState('');
  const [asnId, setAsnId] = useState('');
  const [group, setGroup] = useState('HOMEWORK');
  const [dueDate, setDueDate] = useState('2026-10-25 23:59');
  const [availableFrom, setAvailableFrom] = useState('2026-10-15 08:00');
  const [untilDate, setUntilDate] = useState('2026-10-28 23:59');
  const [status, setStatus] = useState<'PUBLISHED' | 'UNPUBLISHED'>('PUBLISHED');
  
  // Advanced canvas settings
  const [points, setPoints] = useState<number>(100);
  const [gradeDisplay, setGradeDisplay] = useState('Points');
  const [submissionType, setSubmissionType] = useState('Online');
  const [fileUploadAllowed, setFileUploadAllowed] = useState(true);
  const [textEntryAllowed, setTextEntryAllowed] = useState(true);
  const [urlAllowed, setUrlAllowed] = useState(false);
  const [fileExtensions, setFileExtensions] = useState('pdf, docx, zip');
  const [isGroupAssignment, setIsGroupAssignment] = useState(false);
  const [peerReviews, setPeerReviews] = useState(false);
  const [turnitinSync, setTurnitinSync] = useState(true);
  const [countTowardsFinalGrade, setCountTowardsFinalGrade] = useState(true);
  
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    if (initialAssignment) {
      setTitle(initialAssignment.title);
      setAsnId(initialAssignment.asnId);
      setGroup(initialAssignment.group);
      setDueDate(initialAssignment.dueDate);
      setStatus(initialAssignment.status);
    } else {
      // Defaults for new assignment
      setTitle('');
      setAsnId(`ASGN-2026-0${Math.floor(Math.random() * 90 + 10)}`);
      setGroup('HOMEWORK');
      setDueDate('2026-10-28 23:59');
      setStatus('PUBLISHED');
    }
  }, [initialAssignment, isOpen]);

  if (!isOpen) return null;

  const handleApplyTemplate = (type: 'homework' | 'project' | 'quiz' | 'exam') => {
    if (type === 'homework') {
      setTitle('Weekly Problem Set & Analysis');
      setGroup('HOMEWORK');
      setPoints(50);
      setSubmissionType('Online');
      setFileUploadAllowed(true);
      setTextEntryAllowed(true);
      setFileExtensions('pdf, docx');
    } else if (type === 'project') {
      setTitle('Comprehensive Design & Engineering Capstone');
      setGroup('PROJECTS');
      setPoints(200);
      setSubmissionType('Online');
      setIsGroupAssignment(true);
      setPeerReviews(true);
      setFileExtensions('pdf, zip, pptx');
    } else if (type === 'quiz') {
      setTitle('Module Knowledge Check & Concept Review');
      setGroup('QUIZZES');
      setPoints(25);
      setSubmissionType('Online');
      setTextEntryAllowed(true);
    } else if (type === 'exam') {
      setTitle('Proctored Midterm Assessment');
      setGroup('EXAMS');
      setPoints(100);
      setSubmissionType('Online');
      setTurnitinSync(true);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalAsn: Assignment = {
      id: initialAssignment ? initialAssignment.id : `asn-${Date.now()}`,
      title: title.trim() || 'Untitled Assignment',
      asnId: asnId || 'ASGN-2026-099',
      group: group.toUpperCase(),
      dueDate: dueDate || '2026-10-28 23:59',
      status: status,
      checked: initialAssignment ? initialAssignment.checked : false
    };

    setSavedSuccess(true);
    setTimeout(() => {
      onSave(finalAsn);
      setSavedSuccess(false);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-white border-2 border-[#1B1C1A] rounded-[2px] w-full max-w-4xl shadow-2xl overflow-hidden font-mono text-xs my-8">
        {/* Header Bar */}
        <div className="bg-[#1B1C1A] text-white p-4 flex items-center justify-between border-b border-[#1B1C1A]">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-[#2563EB] text-white rounded-[2px]">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black uppercase tracking-tight text-white">
                {isEditing ? `EDIT ASSIGNMENT // ${asnId}` : 'CANVAS ASSIGNMENT AUTHORING TOOL'}
              </h2>
              <p className="text-[10px] text-gray-400 font-mono">
                Full Canvas LMS REST API schema configuration with live rule validation
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white rounded-[2px] transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Blueprints Preset Bar */}
        <div className="bg-[#FAF9F5] border-b border-[#1B1C1A] p-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 text-xs font-bold text-[#1B1C1A] uppercase">
            <Sparkles className="w-4 h-4 text-[#2563EB]" />
            <span>QUICK PRESET BLUEPRINTS:</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => handleApplyTemplate('homework')}
              className="px-2.5 py-1 bg-white border border-[#1B1C1A] hover:bg-blue-50 text-[11px] font-bold uppercase rounded-[1px] text-[#2563EB] transition-all"
            >
              + HOMEWORK (50 PT)
            </button>
            <button
              type="button"
              onClick={() => handleApplyTemplate('project')}
              className="px-2.5 py-1 bg-white border border-[#1B1C1A] hover:bg-purple-50 text-[11px] font-bold uppercase rounded-[1px] text-purple-700 transition-all"
            >
              + GROUP CAPSTONE (200 PT)
            </button>
            <button
              type="button"
              onClick={() => handleApplyTemplate('quiz')}
              className="px-2.5 py-1 bg-white border border-[#1B1C1A] hover:bg-emerald-50 text-[11px] font-bold uppercase rounded-[1px] text-emerald-700 transition-all"
            >
              + QUIZ (25 PT)
            </button>
            <button
              type="button"
              onClick={() => handleApplyTemplate('exam')}
              className="px-2.5 py-1 bg-white border border-[#1B1C1A] hover:bg-red-50 text-[11px] font-bold uppercase rounded-[1px] text-red-700 transition-all"
            >
              + PROCTORED EXAM (100 PT)
            </button>
          </div>
        </div>

        {/* Success Banner */}
        {savedSuccess && (
          <div className="bg-[#FEF08A] border-b border-[#1B1C1A] p-3 text-center font-bold text-[#1B1C1A] flex items-center justify-center gap-2 uppercase animate-pulse">
            <CheckCircle className="w-4 h-4 text-[#2563EB]" />
            <span>ASSIGNMENT COMPILED & SYNCED TO CANVAS API SUCCESSFULLY!</span>
          </div>
        )}

        <form onSubmit={handleFormSubmit} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Section 1: Title & Core Identifiers */}
          <div className="bg-white border-2 border-[#1B1C1A] rounded-[2px] p-4 space-y-4">
            <div className="border-b border-gray-200 pb-2 flex items-center justify-between">
              <span className="font-bold text-[#1B1C1A] uppercase flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-[#2563EB]" />
                <span>1. ASSIGNMENT IDENTIFIERS & CATEGORY</span>
              </span>
              <span className="text-[10px] text-gray-400">REQUIRED FIELDS</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
              <div className="sm:col-span-8 space-y-1">
                <label className="font-bold text-gray-700 block uppercase text-[11px]">
                  Assignment Title:
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Lab Report 3: Structural Thermodynamics"
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs font-mono rounded-[1px] outline-none focus:border-[#2563EB] font-bold text-[#1B1C1A]"
                />
              </div>

              <div className="sm:col-span-4 space-y-1">
                <label className="font-bold text-gray-700 block uppercase text-[11px]">
                  Assignment ID Code:
                </label>
                <input
                  type="text"
                  required
                  value={asnId}
                  onChange={e => setAsnId(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs font-mono rounded-[1px] outline-none focus:border-[#2563EB]"
                />
              </div>

              <div className="sm:col-span-6 space-y-1">
                <label className="font-bold text-gray-700 block uppercase text-[11px]">
                  Assignment Group Category:
                </label>
                <select
                  value={group}
                  onChange={e => setGroup(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs font-mono rounded-[1px] outline-none focus:border-[#2563EB] font-bold uppercase"
                >
                  <option value="HOMEWORK">HOMEWORK (20% WEIGHT)</option>
                  <option value="PROJECTS">PROJECTS (30% WEIGHT)</option>
                  <option value="EXAMS">EXAMS (35% WEIGHT)</option>
                  <option value="LABS">LABS (15% WEIGHT)</option>
                  <option value="QUIZZES">QUIZZES (10% WEIGHT)</option>
                  <option value="DISCUSSIONS">DISCUSSIONS (5% WEIGHT)</option>
                </select>
              </div>

              <div className="sm:col-span-6 space-y-1">
                <label className="font-bold text-gray-700 block uppercase text-[11px]">
                  Publication State:
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setStatus('PUBLISHED')}
                    className={`flex-1 py-2 font-bold uppercase rounded-[1px] border transition-all text-center ${
                      status === 'PUBLISHED'
                        ? 'bg-[#2563EB] text-white border-[#1B1C1A]'
                        : 'bg-[#FAF9F5] text-gray-600 border-gray-300'
                    }`}
                  >
                    PUBLISHED
                  </button>
                  <button
                    type="button"
                    onClick={() => setStatus('UNPUBLISHED')}
                    className={`flex-1 py-2 font-bold uppercase rounded-[1px] border transition-all text-center ${
                      status === 'UNPUBLISHED'
                        ? 'bg-amber-600 text-white border-[#1B1C1A]'
                        : 'bg-[#FAF9F5] text-gray-600 border-gray-300'
                    }`}
                  >
                    UNPUBLISHED (DRAFT)
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Points, Grading & Submissions */}
          <div className="bg-white border-2 border-[#1B1C1A] rounded-[2px] p-4 space-y-4">
            <div className="border-b border-gray-200 pb-2">
              <span className="font-bold text-[#1B1C1A] uppercase flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-[#2563EB]" />
                <span>2. GRADING & SUBMISSION TYPE</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
              <div className="sm:col-span-4 space-y-1">
                <label className="font-bold text-gray-700 block uppercase text-[11px]">
                  Points Possible:
                </label>
                <input
                  type="number"
                  value={points}
                  onChange={e => setPoints(Number(e.target.value))}
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs font-mono font-bold rounded-[1px] outline-none"
                />
              </div>

              <div className="sm:col-span-4 space-y-1">
                <label className="font-bold text-gray-700 block uppercase text-[11px]">
                  Display Grade As:
                </label>
                <select
                  value={gradeDisplay}
                  onChange={e => setGradeDisplay(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs font-mono rounded-[1px] outline-none"
                >
                  <option value="Points">Points (e.g. 100 pt)</option>
                  <option value="Percentage">Percentage (e.g. 95%)</option>
                  <option value="Complete/Incomplete">Complete / Incomplete</option>
                  <option value="Letter Grade">Letter Grade (A, B, C...)</option>
                </select>
              </div>

              <div className="sm:col-span-4 space-y-1">
                <label className="font-bold text-gray-700 block uppercase text-[11px]">
                  Submission Type:
                </label>
                <select
                  value={submissionType}
                  onChange={e => setSubmissionType(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs font-mono rounded-[1px] outline-none font-bold"
                >
                  <option value="Online">Online Submission</option>
                  <option value="Paper">On Paper / In Class</option>
                  <option value="External Tool">External Tool (LTI Integrations)</option>
                  <option value="No Submission">No Submission Required</option>
                </select>
              </div>
            </div>

            {/* Online Submission Detailed Checkboxes */}
            {submissionType === 'Online' && (
              <div className="p-3 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] space-y-3">
                <span className="font-bold text-gray-800 uppercase block text-[11px]">
                  Online Entry Options:
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <label className="flex items-center gap-2 cursor-pointer bg-white p-2 border border-gray-300 rounded-[1px]">
                    <input
                      type="checkbox"
                      checked={fileUploadAllowed}
                      onChange={e => setFileUploadAllowed(e.target.checked)}
                      className="accent-[#2563EB] w-4 h-4 cursor-pointer"
                    />
                    <span className="font-bold">File Uploads</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer bg-white p-2 border border-gray-300 rounded-[1px]">
                    <input
                      type="checkbox"
                      checked={textEntryAllowed}
                      onChange={e => setTextEntryAllowed(e.target.checked)}
                      className="accent-[#2563EB] w-4 h-4 cursor-pointer"
                    />
                    <span className="font-bold">Text Entry / Editor</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer bg-white p-2 border border-gray-300 rounded-[1px]">
                    <input
                      type="checkbox"
                      checked={urlAllowed}
                      onChange={e => setUrlAllowed(e.target.checked)}
                      className="accent-[#2563EB] w-4 h-4 cursor-pointer"
                    />
                    <span className="font-bold">Website URL Link</span>
                  </label>
                </div>

                {fileUploadAllowed && (
                  <div className="space-y-1 pt-1">
                    <label className="font-bold text-gray-700 block uppercase text-[10px]">
                      Restrict Upload File Types (Comma-Separated Extensions):
                    </label>
                    <input
                      type="text"
                      value={fileExtensions}
                      onChange={e => setFileExtensions(e.target.value)}
                      placeholder="e.g. pdf, docx, zip"
                      className="w-full bg-white border border-[#1B1C1A] px-2.5 py-1 text-xs font-mono rounded-[1px] outline-none"
                    />
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Section 3: Availability & Deadlines */}
          <div className="bg-white border-2 border-[#1B1C1A] rounded-[2px] p-4 space-y-4">
            <div className="border-b border-gray-200 pb-2">
              <span className="font-bold text-[#1B1C1A] uppercase flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-[#2563EB]" />
                <span>3. DATES, DEADLINES & AVAILABILITY WINDOW</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="font-bold text-gray-700 block uppercase text-[11px]">
                  Due Date & Time:
                </label>
                <input
                  type="text"
                  value={dueDate}
                  onChange={e => setDueDate(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs font-mono font-bold rounded-[1px] outline-none text-[#2563EB]"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-gray-700 block uppercase text-[11px]">
                  Available From:
                </label>
                <input
                  type="text"
                  value={availableFrom}
                  onChange={e => setAvailableFrom(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs font-mono rounded-[1px] outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-gray-700 block uppercase text-[11px]">
                  Until / Lock Date:
                </label>
                <input
                  type="text"
                  value={untilDate}
                  onChange={e => setUntilDate(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs font-mono rounded-[1px] outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Advanced Canvas Integrations & Rules */}
          <div className="bg-white border-2 border-[#1B1C1A] rounded-[2px] p-4 space-y-3">
            <div className="border-b border-gray-200 pb-2">
              <span className="font-bold text-[#1B1C1A] uppercase flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-[#2563EB]" />
                <span>4. ADVANCED CANVAS ENGINE CONFIGURATION</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
              <label className="flex items-center gap-2.5 p-2 bg-[#FAF9F5] border border-gray-300 rounded-[1px] cursor-pointer">
                <input
                  type="checkbox"
                  checked={isGroupAssignment}
                  onChange={e => setIsGroupAssignment(e.target.checked)}
                  className="accent-[#2563EB] w-4 h-4 cursor-pointer"
                />
                <div>
                  <strong className="block text-[#1B1C1A]">Is Group Assignment</strong>
                  <span className="text-[10px] text-gray-500">Assign grade to group set members</span>
                </div>
              </label>

              <label className="flex items-center gap-2.5 p-2 bg-[#FAF9F5] border border-gray-300 rounded-[1px] cursor-pointer">
                <input
                  type="checkbox"
                  checked={peerReviews}
                  onChange={e => setPeerReviews(e.target.checked)}
                  className="accent-[#2563EB] w-4 h-4 cursor-pointer"
                />
                <div>
                  <strong className="block text-[#1B1C1A]">Require Peer Reviews</strong>
                  <span className="text-[10px] text-gray-500">Auto-assign 2 peer reviewers per submission</span>
                </div>
              </label>

              <label className="flex items-center gap-2.5 p-2 bg-[#FAF9F5] border border-gray-300 rounded-[1px] cursor-pointer">
                <input
                  type="checkbox"
                  checked={turnitinSync}
                  onChange={e => setTurnitinSync(e.target.checked)}
                  className="accent-[#2563EB] w-4 h-4 cursor-pointer"
                />
                <div>
                  <strong className="block text-[#1B1C1A]">Turnitin Similarity Report</strong>
                  <span className="text-[10px] text-gray-500">Plagiarism scan on submission</span>
                </div>
              </label>

              <label className="flex items-center gap-2.5 p-2 bg-[#FAF9F5] border border-gray-300 rounded-[1px] cursor-pointer">
                <input
                  type="checkbox"
                  checked={countTowardsFinalGrade}
                  onChange={e => setCountTowardsFinalGrade(e.target.checked)}
                  className="accent-[#2563EB] w-4 h-4 cursor-pointer"
                />
                <div>
                  <strong className="block text-[#1B1C1A]">Include in Final Grade</strong>
                  <span className="text-[10px] text-gray-500">Uncheck for diagnostic ungraded assignments</span>
                </div>
              </label>
            </div>
          </div>

          {/* Bottom Action Footer Buttons */}
          <div className="pt-4 border-t border-[#1B1C1A] flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white border border-[#1B1C1A] hover:bg-gray-100 text-[#1B1C1A] font-bold uppercase rounded-[2px] transition-all"
            >
              CANCEL
            </button>

            <button
              type="submit"
              className="px-6 py-2.5 bg-[#2563EB] hover:bg-[#1D4ED8] text-white border border-[#1B1C1A] font-extrabold uppercase tracking-wider rounded-[2px] transition-all flex items-center gap-2 shadow-xs"
            >
              <Save className="w-4 h-4" />
              <span>{isEditing ? 'SAVE CHANGES & SYNC' : 'CREATE & SYNC TO CANVAS'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
