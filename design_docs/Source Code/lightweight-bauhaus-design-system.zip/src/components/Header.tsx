import React from 'react';
import { NavigationTab, ScreenModule } from '../types';
import { BookOpen, Layout, Grid, Sliders, FileText } from 'lucide-react';

interface HeaderProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  selectedCourse?: string;
  setSelectedCourse?: (course: string) => void;
  activeScreen?: ScreenModule;
  setActiveScreen?: (screen: ScreenModule) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
}) => {
  return (
    <header className="w-full bg-[#FAF9F5] border-b border-[#1B1C1A] px-4 py-2.5 sticky top-0 z-40 flex flex-wrap items-center justify-between gap-3">
      {/* Brand Title */}
      <div className="flex items-center gap-2 font-black text-lg tracking-tight text-[#1B1C1A]">
        <div className="w-4 h-4 bg-[#B7102A] border border-[#1B1C1A]" />
        <span>Canvas Power Tools</span>
      </div>

      {/* Main Navigation Tabs */}
      <nav className="flex items-center gap-1 bg-[#EFEEEA] p-1 border border-[#1B1C1A] rounded-[2px] text-xs font-bold">
        <button
          onClick={() => setActiveTab('design-brief')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-[2px] border transition-all ${
            activeTab === 'design-brief'
              ? 'bg-[#1B1C1A] text-[#FAF9F5] border-[#1B1C1A]'
              : 'bg-transparent text-[#1B1C1A] border-transparent hover:bg-[#FAF9F5]'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Design Brief</span>
        </button>

        <button
          onClick={() => setActiveTab('screens')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-[2px] border transition-all ${
            activeTab === 'screens'
              ? 'bg-[#1B1C1A] text-[#FAF9F5] border-[#1B1C1A]'
              : 'bg-transparent text-[#1B1C1A] border-transparent hover:bg-[#FAF9F5]'
          }`}
        >
          <Layout className="w-3.5 h-3.5" />
          <span>Screen Replicas</span>
        </button>

        <button
          onClick={() => setActiveTab('component-library')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-[2px] border transition-all ${
            activeTab === 'component-library'
              ? 'bg-[#1B1C1A] text-[#FAF9F5] border-[#1B1C1A]'
              : 'bg-transparent text-[#1B1C1A] border-transparent hover:bg-[#FAF9F5]'
          }`}
        >
          <Grid className="w-3.5 h-3.5" />
          <span>Component Sandbox</span>
        </button>

        <button
          onClick={() => setActiveTab('token-inspector')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-[2px] border transition-all ${
            activeTab === 'token-inspector'
              ? 'bg-[#1B1C1A] text-[#FAF9F5] border-[#1B1C1A]'
              : 'bg-transparent text-[#1B1C1A] border-transparent hover:bg-[#FAF9F5]'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Token Tweaker</span>
        </button>

        <button
          onClick={() => setActiveTab('spec-document')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-[2px] border transition-all ${
            activeTab === 'spec-document'
              ? 'bg-[#1B1C1A] text-[#FAF9F5] border-[#1B1C1A]'
              : 'bg-transparent text-[#1B1C1A] border-transparent hover:bg-[#FAF9F5]'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Spec Handoff</span>
        </button>

        <button
          onClick={() => setActiveTab('app-test')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-[2px] border transition-all ${
            activeTab === 'app-test'
              ? 'bg-[#B7102A] text-white border-[#1B1C1A] shadow-sm'
              : 'bg-[#FEF08A] text-[#1B1C1A] border-[#1B1C1A] hover:bg-yellow-300'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-[#1B1C1A] animate-pulse" />
          <span>App Test Mode</span>
        </button>
      </nav>
    </header>
  );
};

