import React, { useState } from 'react';
import {
  Code2,
  Copy,
  Check,
  Download,
  X,
  ChevronDown,
  ChevronUp,
  FileCode,
  Terminal,
  Search,
  ExternalLink,
  Layers,
  Sparkles,
  Eye,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { ScreenModule } from '../types';

// Raw module imports via Vite ?raw loader
import dashboardCode from './screens/DashboardScreen.tsx?raw';
import announcementsCode from './screens/AnnouncementsScreen.tsx?raw';
import rolloverWizardCode from './screens/RolloverWizardScreen.tsx?raw';
import studentDirectoryCode from './screens/StudentDirectoryScreen.tsx?raw';
import bulkEditorCode from './screens/BulkEditorScreen.tsx?raw';
import moduleManagerCode from './screens/ModuleManagerScreen.tsx?raw';
import gradingDashboardCode from './screens/GradingDashboardScreen.tsx?raw';
import assignmentTemplatesCode from './screens/AssignmentTemplatesScreen.tsx?raw';
import rubricManagerCode from './screens/RubricManagerScreen.tsx?raw';
import assignmentGroupsCode from './screens/AssignmentGroupsScreen.tsx?raw';
import assignmentCopyCode from './screens/AssignmentCopyScreen.tsx?raw';
import quizBuilderCode from './screens/QuizBuilderScreen.tsx?raw';
import missingWorkCode from './screens/MissingWorkScreen.tsx?raw';
import gradeAdjustmentsCode from './screens/GradeAdjustmentsScreen.tsx?raw';
import latePolicyCode from './screens/LatePolicyScreen.tsx?raw';
import communicationNudgesCode from './screens/CommunicationNudgesScreen.tsx?raw';
import studentGroupsCode from './screens/StudentGroupsScreen.tsx?raw';
import sectionsManagerCode from './screens/SectionsManagerScreen.tsx?raw';
import accommodationsCode from './screens/AccommodationsScreen.tsx?raw';
import accommodationCreatorCode from './screens/AccommodationCreatorScreen.tsx?raw';
import speedgraderSuiteCode from './screens/SpeedGraderSuiteScreen.tsx?raw';
import securityAuditCode from './screens/SecurityAuditScreen.tsx?raw';
import settingsPreferencesCode from './screens/SettingsPreferencesScreen.tsx?raw';
import gradeOutreachCode from './screens/GradeOutreachScreen.tsx?raw';

export const SCREEN_CODE_MAP: Record<
  ScreenModule,
  { name: string; filename: string; path: string; code: string; category: string }
> = {
  dashboard: {
    name: 'Dashboard Overview',
    filename: 'DashboardScreen.tsx',
    path: '/src/components/screens/DashboardScreen.tsx',
    code: dashboardCode,
    category: 'Navigation & Launcher',
  },
  announcements: {
    name: 'Announcements Engine',
    filename: 'AnnouncementsScreen.tsx',
    path: '/src/components/screens/AnnouncementsScreen.tsx',
    code: announcementsCode,
    category: 'Communication',
  },
  'rollover-wizard': {
    name: 'Course Rollover Wizard',
    filename: 'RolloverWizardScreen.tsx',
    path: '/src/components/screens/RolloverWizardScreen.tsx',
    code: rolloverWizardCode,
    category: 'Course Administration',
  },
  'student-directory': {
    name: 'Student Directory & Roster',
    filename: 'StudentDirectoryScreen.tsx',
    path: '/src/components/screens/StudentDirectoryScreen.tsx',
    code: studentDirectoryCode,
    category: 'Roster & Roster Analytics',
  },
  'bulk-editor': {
    name: 'Bulk Assignment Editor',
    filename: 'BulkEditorScreen.tsx',
    path: '/src/components/screens/BulkEditorScreen.tsx',
    code: bulkEditorCode,
    category: 'Assignments & Dates',
  },
  'module-manager': {
    name: 'Module Manager & Progression',
    filename: 'ModuleManagerScreen.tsx',
    path: '/src/components/screens/ModuleManagerScreen.tsx',
    code: moduleManagerCode,
    category: 'Curriculum & Structure',
  },
  'grading-dashboard': {
    name: 'SpeedGrader & Analytics',
    filename: 'GradingDashboardScreen.tsx',
    path: '/src/components/screens/GradingDashboardScreen.tsx',
    code: gradingDashboardCode,
    category: 'Grading & Submissions',
  },
  'assignment-templates': {
    name: 'Assignment Templates',
    filename: 'AssignmentTemplatesScreen.tsx',
    path: '/src/components/screens/AssignmentTemplatesScreen.tsx',
    code: assignmentTemplatesCode,
    category: 'Templates & Deployment',
  },
  'rubric-manager': {
    name: 'Rubric Manager & Library',
    filename: 'RubricManagerScreen.tsx',
    path: '/src/components/screens/RubricManagerScreen.tsx',
    code: rubricManagerCode,
    category: 'Grading',
  },
  'assignment-groups': {
    name: 'Assignment Group Manager',
    filename: 'AssignmentGroupsScreen.tsx',
    path: '/src/components/screens/AssignmentGroupsScreen.tsx',
    code: assignmentGroupsCode,
    category: 'Grading',
  },
  'assignment-copy': {
    name: 'Cross-Course Assignment Copy',
    filename: 'AssignmentCopyScreen.tsx',
    path: '/src/components/screens/AssignmentCopyScreen.tsx',
    code: assignmentCopyCode,
    category: 'Assignments',
  },
  'quiz-builder': {
    name: 'Quiz Builder & Markdown Import',
    filename: 'QuizBuilderScreen.tsx',
    path: '/src/components/screens/QuizBuilderScreen.tsx',
    code: quizBuilderCode,
    category: 'Assignments',
  },
  'missing-work': {
    name: 'Missing Work Dashboard',
    filename: 'MissingWorkScreen.tsx',
    path: '/src/components/screens/MissingWorkScreen.tsx',
    code: missingWorkCode,
    category: 'Grading',
  },
  'grade-adjustments': {
    name: 'Grade Adjustments & Curving',
    filename: 'GradeAdjustmentsScreen.tsx',
    path: '/src/components/screens/GradeAdjustmentsScreen.tsx',
    code: gradeAdjustmentsCode,
    category: 'Grading',
  },
  'late-policy': {
    name: 'Late Policy & Deductions',
    filename: 'LatePolicyScreen.tsx',
    path: '/src/components/screens/LatePolicyScreen.tsx',
    code: latePolicyCode,
    category: 'Grading',
  },
  'communication-nudges': {
    name: 'Nudges & Threshold Messenger',
    filename: 'CommunicationNudgesScreen.tsx',
    path: '/src/components/screens/CommunicationNudgesScreen.tsx',
    code: communicationNudgesCode,
    category: 'Communication',
  },
  'student-groups': {
    name: 'Student Group Sets',
    filename: 'StudentGroupsScreen.tsx',
    path: '/src/components/screens/StudentGroupsScreen.tsx',
    code: studentGroupsCode,
    category: 'People',
  },
  'sections-manager': {
    name: 'Section Manager & Analytics',
    filename: 'SectionsManagerScreen.tsx',
    path: '/src/components/screens/SectionsManagerScreen.tsx',
    code: sectionsManagerCode,
    category: 'People',
  },
  accommodations: {
    name: 'Accommodation Override Manager',
    filename: 'AccommodationsScreen.tsx',
    path: '/src/components/screens/AccommodationsScreen.tsx',
    code: accommodationsCode,
    category: 'People',
  },
  'accommodation-creator': {
    name: 'Accommodation Creator Tool',
    filename: 'AccommodationCreatorScreen.tsx',
    path: '/src/components/screens/AccommodationCreatorScreen.tsx',
    code: accommodationCreatorCode,
    category: 'People',
  },
  'speedgrader-suite': {
    name: 'SpeedGrader Injected Suite',
    filename: 'SpeedGraderSuiteScreen.tsx',
    path: '/src/components/screens/SpeedGraderSuiteScreen.tsx',
    code: speedgraderSuiteCode,
    category: 'SpeedGrader',
  },
  'security-audit': {
    name: 'PIN Security & Audit Log',
    filename: 'SecurityAuditScreen.tsx',
    path: '/src/components/screens/SecurityAuditScreen.tsx',
    code: securityAuditCode,
    category: 'Setup & Security',
  },
  'settings-preferences': {
    name: 'Extension Settings',
    filename: 'SettingsPreferencesScreen.tsx',
    path: '/src/components/screens/SettingsPreferencesScreen.tsx',
    code: settingsPreferencesCode,
    category: 'Setup & Security',
  },
  'grade-outreach': {
    name: 'Recurring Grade Outreach',
    filename: 'GradeOutreachScreen.tsx',
    path: '/src/components/screens/GradeOutreachScreen.tsx',
    code: gradeOutreachCode,
    category: 'Communication',
  },
};

interface ScreenCodeHeaderProps {
  activeScreen: ScreenModule;
  onNavigateScreen?: (screen: ScreenModule) => void;
}

export const ScreenCodeHeader: React.FC<ScreenCodeHeaderProps> = ({
  activeScreen,
  onNavigateScreen,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  const [selectedScreenTab, setSelectedScreenTab] = useState<ScreenModule>(activeScreen);
  const [searchFilter, setSearchFilter] = useState('');
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Sync tab with activeScreen prop if activeScreen changes
  React.useEffect(() => {
    setSelectedScreenTab(activeScreen);
  }, [activeScreen]);

  const currentModule = SCREEN_CODE_MAP[selectedScreenTab] || SCREEN_CODE_MAP.dashboard;
  const rawCode = currentModule.code;
  const lines = rawCode.split('\n');
  const lineCount = lines.length;
  const kbSize = (new Blob([rawCode]).size / 1024).toFixed(1);

  const handleCopyCode = (codeToCopy: string) => {
    navigator.clipboard.writeText(codeToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([rawCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = currentModule.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Filter lines if search query active
  const filteredLines = searchFilter
    ? lines
        .map((line, idx) => ({ line, num: idx + 1 }))
        .filter((item) => item.line.toLowerCase().includes(searchFilter.toLowerCase()))
    : lines.map((line, idx) => ({ line, num: idx + 1 }));

  return (
    <div className="mb-6 font-sans">
      {/* Top Mechanical Action Toolbar */}
      <div className="bg-[#EFEEEA] border border-[#1B1C1A] rounded-[2px] p-3 flex flex-wrap items-center justify-between gap-3 shadow-none font-mono text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <span className="px-2 py-0.5 bg-[#1B1C1A] text-white font-bold text-[10px] uppercase flex items-center gap-1.5 rounded-[1px]">
            <Code2 className="w-3.5 h-3.5 text-[#FEF08A]" />
            <span>MODULE SOURCE CODE</span>
          </span>

          <span className="font-bold text-[#1B1C1A] flex items-center gap-1.5 bg-white border border-[#1B1C1A] px-2 py-0.5 rounded-[1px]">
            <FileCode className="w-3.5 h-3.5 text-[#2563EB]" />
            <span>{currentModule.path}</span>
          </span>

          <span className="text-[10px] text-gray-600 bg-[#FAF9F5] border border-[#1B1C1A] px-1.5 py-0.5">
            {lineCount} LINES ({kbSize} KB)
          </span>
        </div>

        {/* Copy & View Actions */}
        <div className="flex items-center gap-2">
          {/* Direct Copy Code Button */}
          <button
            onClick={() => handleCopyCode(rawCode)}
            className={`px-3 py-1.5 border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] transition-all flex items-center gap-1.5 ${
              copied
                ? 'bg-[#FEF08A] text-[#1B1C1A] border-[#1B1C1A]'
                : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-[#059669]" />
                <span>COPIED CODE!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-[#1B1C1A]" />
                <span>COPY MODULE CODE</span>
              </>
            )}
          </button>

          {/* Toggle Code Inspector Drawer */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className={`px-3 py-1.5 border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] transition-all flex items-center gap-1.5 ${
              isExpanded
                ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-[#FEF08A]" />
            <span>{isExpanded ? 'HIDE CODE INSPECTOR' : 'INSPECT SOURCE CODE'}</span>
            {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>
      </div>

      {/* Expanded Code Inspector Drawer */}
      {isExpanded && (
        <div
          className={`mt-2 bg-[#1B1C1A] text-[#FEF08A] border border-[#1B1C1A] rounded-[2px] overflow-hidden shadow-2xl transition-all ${
            isFullscreen ? 'fixed inset-4 z-50 flex flex-col m-0' : 'relative'
          }`}
        >
          {/* Code Viewer Header Toolbar */}
          <div className="bg-[#262724] border-b border-[#383935] p-3 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
            {/* Screen Module Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto max-w-full pb-1 sm:pb-0">
              {(Object.keys(SCREEN_CODE_MAP) as ScreenModule[]).map((key) => {
                const mod = SCREEN_CODE_MAP[key];
                const isSelected = selectedScreenTab === key;
                return (
                  <button
                    key={key}
                    onClick={() => {
                      setSelectedScreenTab(key);
                      if (onNavigateScreen) onNavigateScreen(key);
                    }}
                    className={`px-2.5 py-1 text-[11px] font-bold uppercase rounded-[1px] border transition-all whitespace-nowrap ${
                      isSelected
                        ? 'bg-[#FEF08A] text-[#1B1C1A] border-[#FEF08A]'
                        : 'bg-[#1B1C1A] text-gray-300 border-[#383935] hover:bg-[#383935]'
                    }`}
                  >
                    {mod.filename.replace('.tsx', '')}
                  </button>
                );
              })}
            </div>

            {/* Actions & Controls */}
            <div className="flex items-center gap-2">
              {/* Search Within Code */}
              <div className="relative">
                <Search className="w-3 h-3 text-gray-400 absolute left-2 top-2" />
                <input
                  type="text"
                  value={searchFilter}
                  onChange={(e) => setSearchFilter(e.target.value)}
                  placeholder="FILTER LINES..."
                  className="bg-[#1B1C1A] text-white border border-[#383935] pl-7 pr-2 py-1 text-[10px] font-mono rounded-[1px] outline-none focus:border-[#FEF08A] w-32 sm:w-40"
                />
                {searchFilter && (
                  <button
                    onClick={() => setSearchFilter('')}
                    className="absolute right-1.5 top-1.5 text-gray-400 hover:text-white"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* Copy Code */}
              <button
                onClick={() => handleCopyCode(rawCode)}
                className="px-2.5 py-1 bg-[#FEF08A] text-[#1B1C1A] font-bold text-[10px] uppercase rounded-[1px] hover:bg-yellow-300 flex items-center gap-1"
                title="Copy current module code"
              >
                {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'COPIED' : 'COPY'}</span>
              </button>

              {/* Download */}
              <button
                onClick={handleDownload}
                className="p-1.5 bg-[#383935] text-white hover:bg-gray-600 rounded-[1px]"
                title="Download .tsx file"
              >
                <Download className="w-3.5 h-3.5" />
              </button>

              {/* Toggle Fullscreen */}
              <button
                onClick={() => setIsFullscreen(!isFullscreen)}
                className="p-1.5 bg-[#383935] text-white hover:bg-gray-600 rounded-[1px]"
                title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen Code View'}
              >
                {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              </button>

              {/* Close Drawer */}
              <button
                onClick={() => setIsExpanded(false)}
                className="p-1.5 bg-[#B7102A] text-white hover:bg-red-700 rounded-[1px]"
                title="Close Code Inspector"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Line Numbers + Code Viewport */}
          <div className="p-4 overflow-auto font-mono text-xs leading-relaxed max-h-[500px] bg-[#111210] flex-1">
            <div className="table w-full">
              {filteredLines.map(({ line, num }) => (
                <div key={num} className="table-row hover:bg-[#1B1C1A] group">
                  <span className="table-cell select-none text-right pr-4 text-gray-600 border-r border-[#262724] text-[10px] w-12 font-mono">
                    {num}
                  </span>
                  <span className="table-cell pl-4 text-gray-200 whitespace-pre font-mono">
                    {highlightCodeLine(line)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Footer Metadata */}
          <div className="bg-[#262724] border-t border-[#383935] px-4 py-2 flex items-center justify-between text-[10px] font-mono text-gray-400">
            <span>
              LOCATION: <strong className="text-white">{currentModule.path}</strong>
            </span>
            <span>TYPESCRIPT / REACT 18 + TAILWIND CSS</span>
          </div>
        </div>
      )}
    </div>
  );
};

// Basic syntax highlighting helper for React/TSX lines
function highlightCodeLine(line: string) {
  if (line.trim().startsWith('//') || line.trim().startsWith('/*')) {
    return <span className="text-gray-500 italic">{line}</span>;
  }
  if (line.trim().startsWith('import ') || line.trim().startsWith('export ')) {
    return <span className="text-[#38BDF8]">{line}</span>;
  }
  if (line.includes('const ') || line.includes('interface ') || line.includes('type ')) {
    return <span className="text-[#F472B6]">{line}</span>;
  }
  if (line.includes('return ') || line.includes('function ')) {
    return <span className="text-[#FACC15]">{line}</span>;
  }
  return <span>{line}</span>;
}
