import React, { useState } from 'react';
import { NavigationTab, ScreenModule } from '../types';
import {
  LayoutDashboard,
  Megaphone,
  RotateCw,
  Users,
  CheckSquare,
  FolderKanban,
  GraduationCap,
  Copy,
  Sparkles,
  BookOpen,
  Grid,
  Sliders,
  FileText,
  ChevronDown,
  Layers,
  PieChart,
  Code2,
  AlertTriangle,
  TrendingUp,
  Clock,
  Send,
  ShieldCheck,
  Plus,
  Lock,
  Settings,
  Repeat
} from 'lucide-react';

interface SidebarProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  activeScreen: ScreenModule;
  setActiveScreen: (screen: ScreenModule) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  activeScreen,
  setActiveScreen
}) => {
  const [isScreensOpen, setIsScreensOpen] = useState(true);

  const screensList: { id: ScreenModule; label: string; icon: React.ReactNode; color: string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" />, color: '#2563EB' },
    { id: 'bulk-editor', label: 'Bulk Assignment Editor', icon: <CheckSquare className="w-4 h-4" />, color: '#2563EB' },
    { id: 'assignment-templates', label: 'Assignment Templates', icon: <Copy className="w-4 h-4" />, color: '#B7102A' },
    { id: 'assignment-copy', label: 'Assignment Copy', icon: <Copy className="w-4 h-4" />, color: '#2563EB' },
    { id: 'quiz-builder', label: 'Quiz Builder & MD Import', icon: <Code2 className="w-4 h-4" />, color: '#B7102A' },
    { id: 'grading-dashboard', label: 'Grading Overview', icon: <GraduationCap className="w-4 h-4" />, color: '#059669' },
    { id: 'missing-work', label: 'Missing Work Tracker', icon: <AlertTriangle className="w-4 h-4" />, color: '#059669' },
    { id: 'grade-adjustments', label: 'Grade Curving', icon: <TrendingUp className="w-4 h-4" />, color: '#059669' },
    { id: 'late-policy', label: 'Late Policy Manager', icon: <Clock className="w-4 h-4" />, color: '#059669' },
    { id: 'assignment-groups', label: 'Assignment Group Manager', icon: <FolderKanban className="w-4 h-4" />, color: '#059669' },
    { id: 'rubric-manager', label: 'Rubric Manager', icon: <Layers className="w-4 h-4" />, color: '#059669' },
    { id: 'speedgrader-suite', label: 'SpeedGrader Suite', icon: <GraduationCap className="w-4 h-4" />, color: '#059669' },
    { id: 'announcements', label: 'Announcements Engine', icon: <Megaphone className="w-4 h-4" />, color: '#7C3AED' },
    { id: 'communication-nudges', label: 'Student Nudges', icon: <Send className="w-4 h-4" />, color: '#7C3AED' },
    { id: 'grade-outreach', label: 'Recurring Grade Outreach', icon: <Repeat className="w-4 h-4" />, color: '#7C3AED' },
    { id: 'student-directory', label: 'Student Directory', icon: <Users className="w-4 h-4" />, color: '#EA580C' },
    { id: 'student-groups', label: 'Student Group Sets', icon: <Users className="w-4 h-4" />, color: '#EA580C' },
    { id: 'sections-manager', label: 'Section Manager', icon: <Users className="w-4 h-4" />, color: '#EA580C' },
    { id: 'accommodations', label: 'Accommodations', icon: <ShieldCheck className="w-4 h-4" />, color: '#EA580C' },
    { id: 'accommodation-creator', label: 'Accommodation Creator', icon: <Plus className="w-4 h-4" />, color: '#EA580C' },
    { id: 'module-manager', label: 'Module Manager', icon: <FolderKanban className="w-4 h-4" />, color: '#0D9488' },
    { id: 'speedgrader-suite', label: 'SpeedGrader Suite', icon: <GraduationCap className="w-4 h-4" />, color: '#059669' },
    { id: 'rollover-wizard', label: 'Course Rollover Wizard', icon: <RotateCw className="w-4 h-4" />, color: '#334155' },
    { id: 'security-audit', label: 'PIN Security & Audit', icon: <Lock className="w-4 h-4" />, color: '#1B1C1A' },
    { id: 'settings-preferences', label: 'Extension Settings', icon: <Settings className="w-4 h-4" />, color: '#1B1C1A' },
  ];

  return (
    <aside className="w-16 md:w-64 bg-[#FAF9F5] border-r border-[#1B1C1A] shrink-0 min-h-[calc(100vh-53px)] flex flex-col justify-between py-4 select-none">
      <div className="space-y-6">
        {/* Navigation Categories */}
        <div className="px-3">
          <div className="hidden md:block text-xs font-mono font-bold tracking-widest text-gray-500 uppercase mb-2 px-2">
            Main Modes
          </div>
          <div className="space-y-1">
            <button
              onClick={() => setActiveTab('design-brief')}
              className={`w-full flex items-center gap-3 px-2.5 py-2 rounded-[2px] border text-xs font-bold transition-colors ${
                activeTab === 'design-brief'
                  ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                  : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#EFEEEA]'
              }`}
            >
              <BookOpen className="w-4 h-4 shrink-0" />
              <span className="hidden md:inline">Design System Brief</span>
            </button>

            <button
              onClick={() => setActiveTab('screens')}
              className={`w-full flex items-center gap-3 px-2.5 py-2 rounded-[2px] border text-xs font-bold transition-colors ${
                activeTab === 'screens'
                  ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                  : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#EFEEEA]'
              }`}
            >
              <Sparkles className="w-4 h-4 shrink-0 text-[#B7102A]" />
              <span className="hidden md:inline">Live Screen Replicas</span>
            </button>

            <button
              onClick={() => setActiveTab('component-library')}
              className={`w-full flex items-center gap-3 px-2.5 py-2 rounded-[2px] border text-xs font-bold transition-colors ${
                activeTab === 'component-library'
                  ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                  : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#EFEEEA]'
              }`}
            >
              <Grid className="w-4 h-4 shrink-0" />
              <span className="hidden md:inline">Component Sandbox</span>
            </button>

            <button
              onClick={() => setActiveTab('token-inspector')}
              className={`w-full flex items-center gap-3 px-2.5 py-2 rounded-[2px] border text-xs font-bold transition-colors ${
                activeTab === 'token-inspector'
                  ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                  : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#EFEEEA]'
              }`}
            >
              <Sliders className="w-4 h-4 shrink-0" />
              <span className="hidden md:inline">Token Tweaker</span>
            </button>

            <button
              onClick={() => setActiveTab('spec-document')}
              className={`w-full flex items-center gap-3 px-2.5 py-2 rounded-[2px] border text-xs font-bold transition-colors ${
                activeTab === 'spec-document'
                  ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                  : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#EFEEEA]'
              }`}
            >
              <FileText className="w-4 h-4 shrink-0" />
              <span className="hidden md:inline">Spec Document</span>
            </button>

            <button
              onClick={() => setActiveTab('app-test')}
              className={`w-full flex items-center gap-3 px-2.5 py-2 rounded-[2px] border text-xs font-bold transition-colors ${
                activeTab === 'app-test'
                  ? 'bg-[#B7102A] text-white border-[#1B1C1A]'
                  : 'bg-[#FEF08A] text-[#1B1C1A] border-[#1B1C1A] hover:bg-yellow-300'
              }`}
            >
              <Repeat className="w-4 h-4 shrink-0 text-[#1B1C1A]" />
              <span className="hidden md:inline">App Test Mode</span>
            </button>
          </div>
        </div>

        {/* Screen Module Selection Accordion */}
        <div className="px-3">
          <button
            onClick={() => setIsScreensOpen(!isScreensOpen)}
            className="w-full hidden md:flex items-center justify-between text-xs font-mono font-bold tracking-widest text-gray-600 uppercase mb-2 px-2 py-1 bg-[#EFEEEA] border border-[#1B1C1A] rounded-[2px] hover:bg-[#E2E1DC] transition-colors"
          >
            <span>Screen Modules ({screensList.length} Views)</span>
            <ChevronDown
              className={`w-3.5 h-3.5 text-[#1B1C1A] transition-transform duration-200 ${
                isScreensOpen ? 'rotate-180' : ''
              }`}
            />
          </button>

          {isScreensOpen && (
            <div className="space-y-1 animate-pop pt-1">
              {screensList.map((screen) => {
                const isSelected = activeTab === 'screens' && activeScreen === screen.id;
                return (
                  <button
                    key={screen.id}
                    onClick={() => {
                      setActiveTab('screens');
                      setActiveScreen(screen.id);
                    }}
                    className={`w-full flex items-center gap-3 px-2.5 py-2 rounded-[2px] border text-xs font-medium transition-all ${
                      isSelected
                        ? 'bg-[#1B1C1A] text-white border-[#1B1C1A] font-bold shadow-none'
                        : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#EFEEEA]'
                    }`}
                  >
                    <div
                      className="p-1 border border-[#1B1C1A] rounded-[2px]"
                      style={{ backgroundColor: isSelected ? screen.color : '#FFFFFF', color: isSelected ? '#FFF' : '#1B1C1A' }}
                    >
                      {screen.icon}
                    </div>
                    <span className="hidden md:inline truncate">{screen.label}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>


    </aside>
  );
};
