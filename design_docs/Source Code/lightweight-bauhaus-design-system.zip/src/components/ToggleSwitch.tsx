import React from 'react';

export interface ToggleSwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: string;
  sublabel?: string;
  disabled?: boolean;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'yellow' | 'blue' | 'green' | 'red' | 'dark';
  showLabels?: boolean;
  className?: string;
}

export const ToggleSwitch: React.FC<ToggleSwitchProps> = ({
  checked,
  onChange,
  label,
  sublabel,
  disabled = false,
  size = 'md',
  variant = 'yellow',
  showLabels = true,
  className = '',
}) => {
  // Configurable size geometry
  const sizeMap = {
    sm: {
      track: 'w-11 h-5.5',
      thumb: 'w-4.5 h-4.5',
      translate: 'translate-x-[21px]',
      text: 'text-[8px]',
      padding: 'p-[1px]',
      ridgeHeight: 'h-2',
    },
    md: {
      track: 'w-13 h-6.5',
      thumb: 'w-5.5 h-5.5',
      translate: 'translate-x-[25px]',
      text: 'text-[9px]',
      padding: 'p-[1px]',
      ridgeHeight: 'h-2.5',
    },
    lg: {
      track: 'w-16 h-8',
      thumb: 'w-7 h-7',
      translate: 'translate-x-[31px]',
      text: 'text-[10px]',
      padding: 'p-[1px]',
      ridgeHeight: 'h-3',
    },
  };

  const activeBgMap = {
    yellow: 'bg-[#1B1C1A]',
    blue: 'bg-[#2563EB]',
    green: 'bg-[#059669]',
    red: 'bg-[#B7102A]',
    dark: 'bg-[#1B1C1A]',
  };

  const activeThumbMap = {
    yellow: 'bg-[#FEF08A]',
    blue: 'bg-[#FEF08A]',
    green: 'bg-white',
    red: 'bg-[#FEF08A]',
    dark: 'bg-[#FEF08A]',
  };

  const activeTextMap = {
    yellow: 'text-[#FEF08A]',
    blue: 'text-white',
    green: 'text-white',
    red: 'text-[#FEF08A]',
    dark: 'text-[#FEF08A]',
  };

  const { track, thumb, translate, text, padding, ridgeHeight } = sizeMap[size];

  return (
    <div
      className={`inline-flex items-center gap-2.5 select-none ${
        disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'
      } ${className}`}
    >
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        disabled={disabled}
        onClick={() => !disabled && onChange(!checked)}
        className={`relative ${track} ${padding} border border-[#1B1C1A] rounded-[2px] font-mono transition-colors duration-150 flex items-center shrink-0 focus:outline-none focus:ring-1 focus:ring-[#2563EB] ${
          checked ? activeBgMap[variant] : 'bg-[#EFEEEA]'
        }`}
      >
        {/* Track ON label */}
        {showLabels && (
          <span
            className={`absolute left-1.5 font-bold uppercase ${text} ${activeTextMap[variant]} ${
              checked ? 'opacity-100' : 'opacity-0'
            } transition-opacity duration-150 pointer-events-none z-0`}
          >
            ON
          </span>
        )}

        {/* Track OFF label */}
        {showLabels && (
          <span
            className={`absolute right-1.5 font-bold uppercase ${text} text-gray-500 ${
              !checked ? 'opacity-100' : 'opacity-0'
            } transition-opacity duration-150 pointer-events-none z-0`}
          >
            OFF
          </span>
        )}

        {/* Mechanical Slider Knob / Thumb */}
        <div
          className={`${thumb} border border-[#1B1C1A] rounded-[1px] flex items-center justify-center gap-[1px] transition-transform duration-150 ease-out z-10 ${
            checked ? `${activeThumbMap[variant]} ${translate}` : 'bg-white translate-x-0'
          }`}
        >
          {/* Mechanical Grip Ridges */}
          <span className={`w-[1.5px] ${ridgeHeight} bg-[#1B1C1A]/40 rounded-[0.5px]`} />
          <span className={`w-[1.5px] ${ridgeHeight} bg-[#1B1C1A]/40 rounded-[0.5px]`} />
        </div>
      </button>

      {(label || sublabel) && (
        <div className="flex flex-col text-left" onClick={() => !disabled && onChange(!checked)}>
          {label && <span className="text-xs font-bold text-[#1B1C1A] uppercase tracking-wider">{label}</span>}
          {sublabel && <span className="text-[10px] font-mono text-gray-500">{sublabel}</span>}
        </div>
      )}
    </div>
  );
};
