import React, { useState } from 'react';

export interface TooltipProps {
  content: React.ReactNode;
  position?: 'top' | 'bottom' | 'left' | 'right';
  variant?: 'dark' | 'light' | 'yellow' | 'accent';
  children: React.ReactNode;
  className?: string;
}

export const Tooltip: React.FC<TooltipProps> = ({
  content,
  position = 'top',
  variant = 'dark',
  children,
  className = '',
}) => {
  const [visible, setVisible] = useState(false);

  const variantStyles = {
    dark: 'bg-[#1B1C1A] text-white border-[#1B1C1A]',
    light: 'bg-white text-[#1B1C1A] border-[#1B1C1A]',
    yellow: 'bg-[#FEF08A] text-[#1B1C1A] border-[#1B1C1A]',
    accent: 'bg-[#B7102A] text-white border-[#1B1C1A]',
  };

  const positionStyles = {
    top: 'bottom-full left-1/2 -translate-x-1/2 mb-2',
    bottom: 'top-full left-1/2 -translate-x-1/2 mt-2',
    left: 'right-full top-1/2 -translate-y-1/2 mr-2',
    right: 'left-full top-1/2 -translate-y-1/2 ml-2',
  };

  return (
    <div
      className={`relative inline-flex ${className}`}
      onMouseEnter={() => setVisible(true)}
      onMouseLeave={() => setVisible(false)}
      onFocus={() => setVisible(true)}
      onBlur={() => setVisible(false)}
    >
      {children}
      {visible && (
        <div
          className={`absolute z-50 whitespace-nowrap px-2.5 py-1 text-xs font-mono font-bold uppercase tracking-wider border rounded-[2px] shadow-none pointer-events-none animate-pop ${variantStyles[variant]} ${positionStyles[position]}`}
        >
          {content}
        </div>
      )}
    </div>
  );
};
