import React, { useState } from 'react';
import { 
  Copy, Check, ArrowRight, AlertCircle, Info, Plus, Search, ChevronDown, ChevronUp,
  CheckSquare, Layers, Sparkles, Terminal, Shield, Zap, Bell, CheckCircle2, 
  Sliders, Trash2, Settings, Edit3, Filter, Download, RefreshCw, Pin, 
  ExternalLink, Lock, Unlock, Tag, Folder, User, Loader2, Activity, X, 
  Archive, HelpCircle, AlertTriangle, Type, MessageSquare, AlertOctagon,
  Eye, EyeOff, Radio, MoreVertical, MoreHorizontal, Grid, Menu, SlidersHorizontal,
  Calendar, Clock, ChevronLeft, ChevronRight, MessageCircle, Minus, CalendarDays, Share2, ArrowUpDown
} from 'lucide-react';
import { Tooltip } from '../Tooltip';
import { ToggleSwitch } from '../ToggleSwitch';

interface ToastItem {
  id: number;
  type: 'success' | 'warning' | 'error' | 'info';
  title: string;
  message: string;
  time: string;
}

export const ComponentLibrary: React.FC = () => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'inputs' | 'nav' | 'info' | 'containers' | 'tables' | 'buttons' | 'typography' | 'modals' | 'toasts' | 'forms' | 'animations' | 'icons'>('all');
  const [activeSegment, setActiveSegment] = useState<'grid' | 'table' | 'cards'>('grid');
  const [accordionOpen, setAccordionOpen] = useState(false);
  const [isLoadingSim, setIsLoadingSim] = useState(true);

  // Mechanical Toggle Switch Demo States
  const [demoSwitches, setDemoSwitches] = useState({
    yellow: true,
    blue: true,
    green: false,
    red: true,
    dark: false,
  });

  // Data Table Specimen State
  const [tableSearch, setTableSearch] = useState('');
  const [tableSelectedRows, setTableSelectedRows] = useState<string[]>(['SUB-101', 'SUB-103']);
  const [tableSortCol, setTableSortCol] = useState<'id' | 'title' | 'score' | 'status'>('id');
  const [tableSortAsc, setTableSortAsc] = useState(true);
  const [tableDensity, setTableDensity] = useState<'comfortable' | 'compact'>('comfortable');
  const [tableFilterStatus, setTableFilterStatus] = useState<string>('all');
  const [tablePage, setTablePage] = useState(1);

  // Navigational Controls State
  const [isHamburgerOpen, setIsHamburgerOpen] = useState(false);
  const [isDonerOpen, setIsDonerOpen] = useState(false);
  const [isBentoOpen, setIsBentoOpen] = useState(false);
  const [isKebabOpen, setIsKebabOpen] = useState(false);
  const [isMeatballsOpen, setIsMeatballsOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(2);
  const [activeNavTab, setActiveNavTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');

  // Input Controls Extra State
  const [sliderVal, setSliderVal] = useState(65);
  const [stepperVal, setStepperVal] = useState(4);
  const [pickerDate, setPickerDate] = useState('2026-08-15');
  const [pickerTime, setPickerTime] = useState('14:30');

  // Containers Extra State
  const [openAccordion, setOpenAccordion] = useState<number | null>(1);
  const [carouselIndex, setCarouselIndex] = useState(0);

  const carouselItems = [
    { title: 'LAB SPECIFICATION A-1', desc: 'Quantum Mechanics Experiment Matrix', tag: 'PHYSICS', color: 'bg-[#2563EB]' },
    { title: 'ACCREDITATION REPORT', desc: 'Institutional Faculty Compliance Audit', tag: 'AUDIT', color: 'bg-[#059669]' },
    { title: 'SENSORY SYNTHESIZER', desc: 'Tactile Soundwave Signal Generator', tag: 'HARDWARE', color: 'bg-[#B7102A]' },
    { title: 'BAUHAUS GRID MATRIX', desc: 'Constructivist Typographic Standards', tag: 'DESIGN', color: 'bg-[#7C3AED]' },
  ];

  // Typography Testing State
  const [selectedTitleFont, setSelectedTitleFont] = useState<string>('space');
  const [selectedBodyFont, setSelectedBodyFont] = useState<string>('inter');
  const [sampleText, setSampleText] = useState('LIGHTWEIGHT BAUHAUS GRID ARCHITECTURE');
  const [selectedWeight, setSelectedWeight] = useState<string>('font-extrabold');
  const [tracking, setTracking] = useState<string>('tracking-wider');

  // Modals & Overlays State
  const [activeModal, setActiveModal] = useState<'none' | 'window' | 'destructive' | 'drawer'>('none');

  // Toasts State
  const [toasts, setToasts] = useState<ToastItem[]>([
    {
      id: 1,
      type: 'success',
      title: 'ACCREDITATION REPORT PUBLISHED',
      message: 'Course brief exported to Markdown format successfully.',
      time: '12:04:18'
    },
    {
      id: 2,
      type: 'warning',
      title: 'UNSAVED MATRIX CHANGES',
      message: 'Assessment weights exceed 100% threshold.',
      time: '12:05:02'
    }
  ]);

  // Form Controls State
  const [formData, setFormData] = useState({
    courseName: 'CS-402 Advanced Physics Laboratory',
    department: 'STEM / Physical Sciences',
    notifyStudents: true,
    requireApproval: false,
    gradingScale: 'letter',
    notes: 'Primary coursework requires weekly lab reports and peer reviews.'
  });

  const addToast = (type: 'success' | 'warning' | 'error' | 'info') => {
    const newToast: ToastItem = {
      id: Date.now(),
      type,
      title: type === 'success' ? 'SYSTEM ACTION EXECUTED' :
             type === 'warning' ? 'WARN: THRESHOLD EXCEEDED' :
             type === 'error' ? 'CRITICAL ERROR: RECORD LOCKED' : 'SYSTEM NOTIFICATION',
      message: type === 'success' ? 'Record updated in database with 1px hairline stroke.' :
               type === 'warning' ? 'Check parameter bounds before confirming deployment.' :
               type === 'error' ? 'Failed to process request. Database connection timeout.' : 'Background sync process initiated.',
      time: new Date().toLocaleTimeString()
    };
    setToasts(prev => [newToast, ...prev].slice(0, 5));
  };

  const removeToast = (id: number) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const copyCode = (code: string, index: number) => {
    navigator.clipboard.writeText(code);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const claudeCodePrompt = `# DESIGN SYSTEM SPEC: Lightweight Bauhaus / 21st-Century Win98

Use this design system for all UI components, pages, and layouts.

## 1. Core Color Palette
- Canvas Background: \`#FAF9F5\` (Clean, high-contrast off-white)
- Dark Ink / Hairline Borders: \`#1B1C1A\` (Strict 1px border on all interactive elements)
- System Panel Gray: \`#EFEEEA\` (Muted background for headers, sidebars, secondary panels)
- Electric Cobalt: \`#2563EB\` (Primary interactive highlight & focus rings)
- Bauhaus Primary Red: \`#B7102A\` (Destructive actions & key accents)
- Emerald Green: \`#059669\` (Success states & online status)
- Amethyst Purple: \`#7C3AED\` (Special categories & communication modules)

## 2. Structural & Layout Rules
- NO DROP SHADOWS: Set \`box-shadow: none !important;\`. Never use soft blur shadows or ambient drop-shadows.
- 1px Hairline Borders: All cards, containers, buttons, and inputs have \`border border-[#1B1C1A]\`.
- Corner Radius: Strictly \`rounded-[2px]\` (or \`rounded-sm\`). Do NOT use large rounded corners (e.g. \`rounded-xl\` or \`rounded-2xl\` are strictly forbidden).
- Top Accent Strips: Module cards use \`border-t-4 border-t-[color]\` (e.g. Cobalt, Emerald, Red, Purple) over a 1px \`#1B1C1A\` border frame.

## 3. Typography & Hierarchy
- Headings: Bold, uppercase, tight tracking (\`font-bold uppercase tracking-wider text-[#1B1C1A]\`).
- Technical Labels: Monospace font for metadata, dates, or specs (\`font-mono text-[10px] text-gray-600 uppercase\`).
- Primary Text: Crisp sans-serif (\`text-xs\` or \`text-sm\` with high contrast against white or \`#FAF9F5\`).

## 4. Mechanical Loading Animations & Spinners
- Discrete Stepped Spinners: Never use smooth gradient spinners. Use 8-tick stepped rotation: \`animate-stepped-spin\` (\`steps(1, end)\`).
- Stepped Progress Meters: Render progress bars as discrete block segments (\`[■■■■■□□□]\`) or 4-step CSS fills.
- Stepped Pulse Indicators: Use discrete status dots with \`animate-pulse\` or pinging radar dots with 1px hairline rings.
- Hairline Skeleton Loaders: Skeleton placeholders use \`bg-[#EFEEEA] border border-[#1B1C1A] animate-pulse rounded-[2px]\`.

## 5. Iconography & Glyph Rules
- Frame all utility icons (Trash, Settings, Edit, Search, Lock) inside a 1px border box: \`w-8 h-8 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px]\`.
- Action States: Destructive icons (Trash2) use red hover states (\`hover:bg-[#FEE2E2] hover:text-[#B7102A]\`). Settings gears (\`Settings\`) rotate on hover (\`group-hover:rotate-90 duration-200\`).
- Icon Sizing: Micro/Table (\`w-3.5 h-3.5\`), Standard UI (\`w-4 h-4\`), Section Titles (\`w-5 h-5\`). Always set \`strokeWidth={2}\`.

## 6. Bauhaus Tooltip Component
- Hairline Frame & Zero Shadows: 1px border (\`#1B1C1A\`), strictly NO drop-shadows.
- Mechanical Pop: Uses \`animate-pop\` (120ms cubic-bezier transition).
- High-Contrast Variants: Dark (\`#1B1C1A\`), Light (\`#FFFFFF\`), Yellow (\`#FEF08A\`), Bauhaus Red (\`#B7102A\`).
- Position Options: Top, Bottom, Left, Right with \`absolute z-50 pointer-events-none\`.
`;

  const componentsList = [
    {
      category: 'buttons',
      title: 'Tactile Action Buttons & Button States',
      code: `<button className="px-4 py-2 bg-[#1B1C1A] text-white border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px] hover:bg-black active:translate-y-[1px] transition-all duration-100">
  PRIMARY ACTION
</button>

<button className="px-4 py-2 bg-white text-[#1B1C1A] border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px] hover:bg-[#EFEEEA] active:translate-y-[1px] transition-all duration-100">
  SECONDARY ACTION
</button>

<button className="px-4 py-2 bg-[#B7102A] text-white border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px] hover:bg-[#990d23] active:translate-y-[1px] transition-all duration-100">
  BAUHAUS RED ACCENT
</button>`,
      render: (
        <div className="flex flex-wrap items-center gap-3">
          <button className="px-4 py-2 bg-[#1B1C1A] text-white border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px] hover:bg-black active:translate-y-[1px] transition-all duration-100">
            PRIMARY ACTION
          </button>
          <button className="px-4 py-2 bg-white text-[#1B1C1A] border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px] hover:bg-[#EFEEEA] active:translate-y-[1px] transition-all duration-100">
            SECONDARY ACTION
          </button>
          <button className="px-4 py-2 bg-[#B7102A] text-white border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px] hover:bg-[#990d23] active:translate-y-[1px] transition-all duration-100">
            BAUHAUS RED
          </button>
          <button className="px-4 py-2 bg-[#2563EB] text-white border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px] hover:bg-[#1d4ed8] active:translate-y-[1px] transition-all duration-100 flex items-center gap-1.5">
            <span>OPEN MODULE</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button className="w-8 h-8 bg-white border border-[#1B1C1A] flex items-center justify-center text-[#1B1C1A] rounded-[2px] hover:bg-[#EFEEEA] active:translate-y-[1px] transition-all duration-100">
            <Plus className="w-4 h-4" />
          </button>
        </div>
      )
    },
    {
      category: 'buttons',
      title: 'Segmented Toggle Switch & Controls',
      code: `<div className="inline-flex p-0.5 bg-[#EFEEEA] border border-[#1B1C1A] rounded-[2px]">
  <button className="px-3 py-1 bg-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]">
    GRID
  </button>
  <button className="px-3 py-1 text-xs font-bold uppercase text-gray-600 hover:text-[#1B1C1A]">
    TABLE
  </button>
</div>`,
      render: (
        <div className="flex flex-wrap items-center gap-6">
          <div>
            <div className="text-xs font-mono text-gray-500 uppercase mb-1">Interactive Segmented Toggle</div>
            <div className="inline-flex p-0.5 bg-[#EFEEEA] border border-[#1B1C1A] rounded-[2px]">
              <button
                onClick={() => setActiveSegment('grid')}
                className={`px-3 py-1 text-xs font-bold uppercase rounded-[2px] transition-all duration-100 ${
                  activeSegment === 'grid'
                    ? 'bg-white border border-[#1B1C1A] text-[#1B1C1A]'
                    : 'text-gray-600 hover:text-[#1B1C1A]'
                }`}
              >
                GRID VIEW
              </button>
              <button
                onClick={() => setActiveSegment('table')}
                className={`px-3 py-1 text-xs font-bold uppercase rounded-[2px] transition-all duration-100 ${
                  activeSegment === 'table'
                    ? 'bg-white border border-[#1B1C1A] text-[#1B1C1A]'
                    : 'text-gray-600 hover:text-[#1B1C1A]'
                }`}
              >
                TABLE VIEW
              </button>
              <button
                onClick={() => setActiveSegment('cards')}
                className={`px-3 py-1 text-xs font-bold uppercase rounded-[2px] transition-all duration-100 ${
                  activeSegment === 'cards'
                    ? 'bg-white border border-[#1B1C1A] text-[#1B1C1A]'
                    : 'text-gray-600 hover:text-[#1B1C1A]'
                }`}
              >
                CARDS
              </button>
            </div>
          </div>
        </div>
      )
    },
    {
      category: 'tooltips',
      title: 'Bauhaus Tooltips (Hairline Frame, Zero Shadow, Mechanical Pop)',
      code: `<Tooltip content="EXPORT AUDIT LOG" position="top" variant="dark">
  <button className="px-3 py-1.5 bg-[#1B1C1A] text-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]">
    HOVER ME (TOP)
  </button>
</Tooltip>

<Tooltip content="YELLOW SPEC NOTIFICATION" position="bottom" variant="yellow">
  <button className="px-3 py-1.5 bg-[#FEF08A] text-[#1B1C1A] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]">
    HOVER ME (BOTTOM)
  </button>
</Tooltip>`,
      render: (
        <div className="space-y-6">
          <div className="p-4 bg-white border border-[#1B1C1A] rounded-[2px] space-y-4">
            <div className="text-xs font-bold text-[#1B1C1A] uppercase tracking-wider">
              Interactive Position & Color Demonstrations (Hover to trigger 120ms mechanical pop)
            </div>
            <div className="flex flex-wrap items-center justify-around gap-6 py-6 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px]">
              {/* Top Tooltip */}
              <Tooltip content="TOP TOOLTIP: 1PX BORDER / NO SHADOW" position="top" variant="dark">
                <button className="px-4 py-2 bg-white text-[#1B1C1A] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-[#EFEEEA] active:translate-y-[1px] transition-all">
                  HOVER TOP (DARK)
                </button>
              </Tooltip>

              {/* Bottom Tooltip */}
              <Tooltip content="BOTTOM TOOLTIP: BAUHAUS YELLOW" position="bottom" variant="yellow">
                <button className="px-4 py-2 bg-[#FEF08A] text-[#1B1C1A] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-yellow-300 active:translate-y-[1px] transition-all">
                  HOVER BOTTOM (YELLOW)
                </button>
              </Tooltip>

              {/* Left Tooltip */}
              <Tooltip content="LEFT TOOLTIP: LIGHT CANVAS" position="left" variant="light">
                <button className="px-4 py-2 bg-white text-[#1B1C1A] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-[#EFEEEA] active:translate-y-[1px] transition-all">
                  HOVER LEFT (LIGHT)
                </button>
              </Tooltip>

              {/* Right Tooltip */}
              <Tooltip content="RIGHT TOOLTIP: BAUHAUS RED ACCENT" position="right" variant="accent">
                <button className="px-4 py-2 bg-[#B7102A] text-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-[#990d23] active:translate-y-[1px] transition-all">
                  HOVER RIGHT (RED)
                </button>
              </Tooltip>
            </div>
          </div>

          {/* Action Glyphs with Tooltips */}
          <div className="p-4 bg-white border border-[#1B1C1A] rounded-[2px] space-y-3">
            <div className="text-xs font-bold text-[#1B1C1A] uppercase tracking-wider">
              Tooltips integrated with Utility Action Glyphs
            </div>
            <div className="flex items-center gap-3">
              <Tooltip content="PERMANENTLY DELETE RECORD" position="top" variant="accent">
                <button className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#FEE2E2] hover:text-[#B7102A]">
                  <Trash2 className="w-4 h-4" />
                </button>
              </Tooltip>

              <Tooltip content="CONFIGURE SYSTEM PREFERENCES" position="top" variant="dark">
                <button className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#EFEEEA] group">
                  <Settings className="w-4 h-4 group-hover:rotate-90 transition-transform duration-200" />
                </button>
              </Tooltip>

              <Tooltip content="EXPORT AUDIT REPORT (CSV)" position="top" variant="yellow">
                <button className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#D1FAE5] hover:text-[#059669]">
                  <Download className="w-4 h-4" />
                </button>
              </Tooltip>

              <Tooltip content="LOCK SYSTEM PANEL" position="top" variant="dark">
                <button className="w-9 h-9 bg-[#1B1C1A] text-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px]">
                  <Lock className="w-4 h-4" />
                </button>
              </Tooltip>
            </div>
          </div>
        </div>
      )
    },
    {
      category: 'typography',
      title: 'Typography & Typeface Explorer (Dual Title vs. Body Pairings)',
      code: `/* Title Font: font-${selectedTitleFont} | Body Font: font-${selectedBodyFont} */

/* Title / Heading Styling */
<h1 className="font-${selectedTitleFont} text-4xl ${selectedWeight} ${tracking} uppercase text-[#1B1C1A]">
  ${sampleText}
</h1>

/* Body / Paragraph Styling */
<p className="font-${selectedBodyFont} text-sm text-gray-800 leading-relaxed">
  The Lightweight Bauhaus design system pairs structural heading typefaces with high-contrast, legible body fonts on a 1px border grid.
</p>`,
      render: (
        <div className="space-y-8">
          {/* Controls Bar */}
          <div className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1B1C1A] pb-3">
              <div className="flex items-center gap-2">
                <Type className="w-4 h-4 text-[#1B1C1A]" />
                <span className="text-xs font-bold uppercase text-[#1B1C1A] tracking-wider">
                  Interactive Typeface Pairing & Specimen Explorer
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs font-mono">
                <span className="bg-[#1B1C1A] text-white px-2 py-0.5 font-bold uppercase rounded-[1px]">
                  TITLE: {selectedTitleFont.toUpperCase()}
                </span>
                <span className="text-gray-400">+</span>
                <span className="bg-[#2563EB] text-white px-2 py-0.5 font-bold uppercase rounded-[1px]">
                  BODY: {selectedBodyFont.toUpperCase()}
                </span>
              </div>
            </div>

            {/* Curated Pairing Presets */}
            <div>
              <div className="text-xs font-mono text-gray-500 uppercase mb-2 flex items-center justify-between">
                <span>Quick Curated Pairings (One-Click Setup):</span>
                <span className="text-gray-400">Title + Body Combination</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-1.5">
                {[
                  { name: 'Bauhaus', title: 'space', body: 'inter' },
                  { name: 'Avant-Garde', title: 'syne', body: 'jakarta' },
                  { name: 'Editorial Serif', title: 'instrument', body: 'space' },
                  { name: 'Industrial', title: 'oswald', body: 'inter' },
                  { name: 'Geometric', title: 'outfit', body: 'jakarta' },
                  { name: 'Code Grid', title: 'space', body: 'jetbrains' },
                  { name: 'Classic Serif', title: 'playfair', body: 'inter' },
                  { name: 'Dev Mono', title: 'fira', body: 'inter' },
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setSelectedTitleFont(preset.title);
                      setSelectedBodyFont(preset.body);
                    }}
                    className={`p-2 border text-left rounded-[2px] transition-all text-xs ${
                      selectedTitleFont === preset.title && selectedBodyFont === preset.body
                        ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                        : 'bg-[#FAF9F5] text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#EFEEEA]'
                    }`}
                  >
                    <div className="font-bold truncate">{preset.name}</div>
                    <div className="text-xs font-mono opacity-75 truncate">{preset.title} / {preset.body}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Separate Selection: Title Typeface vs Body Typeface */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 pt-3 border-t border-gray-200">
              {/* Title Typeface Picker */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-mono font-bold text-[#1B1C1A] uppercase flex items-center gap-1.5">
                    <span className="w-2 h-2 bg-[#1B1C1A] inline-block"></span>
                    1. Select Title / Heading Typeface:
                  </label>
                  <span className="text-xs font-mono text-gray-500 uppercase">{selectedTitleFont}</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                  {[
                    { id: 'space', name: 'Space Grotesk', class: 'font-space' },
                    { id: 'syne', name: 'Syne', class: 'font-syne' },
                    { id: 'outfit', name: 'Outfit', class: 'font-outfit' },
                    { id: 'oswald', name: 'Oswald', class: 'font-oswald' },
                    { id: 'instrument', name: 'Instrument Serif', class: 'font-instrument' },
                    { id: 'playfair', name: 'Playfair', class: 'font-playfair' },
                    { id: 'inter', name: 'Inter', class: 'font-inter' },
                    { id: 'jakarta', name: 'Jakarta Sans', class: 'font-jakarta' },
                    { id: 'jetbrains', name: 'JetBrains Mono', class: 'font-jetbrains' },
                    { id: 'fira', name: 'Fira Code', class: 'font-fira' },
                  ].map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setSelectedTitleFont(f.id)}
                      className={`p-2 border text-left rounded-[2px] transition-all ${
                        selectedTitleFont === f.id
                          ? 'bg-[#1B1C1A] text-white border-[#1B1C1A] font-bold'
                          : 'bg-[#FAF9F5] text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#EFEEEA]'
                      }`}
                    >
                      <div className={`text-xs truncate ${f.class}`}>{f.name}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Body Typeface Picker */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-mono font-bold text-[#2563EB] uppercase flex items-center gap-1.5">
                    <span className="w-2 h-2 bg-[#2563EB] inline-block"></span>
                    2. Select Body / Content Typeface:
                  </label>
                  <span className="text-xs font-mono text-gray-500 uppercase">{selectedBodyFont}</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                  {[
                    { id: 'inter', name: 'Inter', class: 'font-inter' },
                    { id: 'jakarta', name: 'Jakarta Sans', class: 'font-jakarta' },
                    { id: 'space', name: 'Space Grotesk', class: 'font-space' },
                    { id: 'outfit', name: 'Outfit', class: 'font-outfit' },
                    { id: 'syne', name: 'Syne', class: 'font-syne' },
                    { id: 'playfair', name: 'Playfair', class: 'font-playfair' },
                    { id: 'instrument', name: 'Instrument Serif', class: 'font-instrument' },
                    { id: 'oswald', name: 'Oswald', class: 'font-oswald' },
                    { id: 'jetbrains', name: 'JetBrains Mono', class: 'font-jetbrains' },
                    { id: 'fira', name: 'Fira Code', class: 'font-fira' },
                  ].map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setSelectedBodyFont(f.id)}
                      className={`p-2 border text-left rounded-[2px] transition-all ${
                        selectedBodyFont === f.id
                          ? 'bg-[#2563EB] text-white border-[#1B1C1A] font-bold'
                          : 'bg-[#FAF9F5] text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#EFEEEA]'
                      }`}
                    >
                      <div className={`text-xs truncate ${f.class}`}>{f.name}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Custom Input & Formatting Controls */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-3 border-t border-[#1B1C1A]">
              <div>
                <label className="text-xs font-mono text-gray-600 uppercase block mb-1">Title Text Sample:</label>
                <input
                  type="text"
                  value={sampleText}
                  onChange={(e) => setSampleText(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-1.5 text-xs font-mono rounded-[2px] focus:outline-none focus:ring-1 focus:ring-[#2563EB]"
                />
              </div>

              <div>
                <label className="text-xs font-mono text-gray-600 uppercase block mb-1">Title Weight:</label>
                <div className="flex gap-1">
                  {[
                    { id: 'font-medium', label: 'Med 500' },
                    { id: 'font-bold', label: 'Bold 700' },
                    { id: 'font-extrabold', label: 'XBold 800' },
                  ].map((w) => (
                    <button
                      key={w.id}
                      onClick={() => setSelectedWeight(w.id)}
                      className={`flex-1 py-1.5 text-xs font-mono font-bold uppercase border rounded-[2px] ${
                        selectedWeight === w.id
                          ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                          : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#EFEEEA]'
                      }`}
                    >
                      {w.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-mono text-gray-600 uppercase block mb-1">Title Tracking:</label>
                <div className="flex gap-1">
                  {[
                    { id: 'tracking-normal', label: 'Normal' },
                    { id: 'tracking-wide', label: 'Wide' },
                    { id: 'tracking-widest', label: 'Widest' },
                  ].map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setTracking(t.id)}
                      className={`flex-1 py-1.5 text-xs font-mono font-bold uppercase border rounded-[2px] ${
                        tracking === t.id
                          ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                          : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#EFEEEA]'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Active Typeface Pairing Specimen View */}
          <div className="bg-white border border-[#1B1C1A] p-6 rounded-[2px] space-y-6">
            <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-3">
              <span className="text-xs font-bold uppercase text-[#1B1C1A]">
                ACTIVE PAIRING SPECIMEN — TITLE: <code className="text-[#2563EB] font-mono">{selectedTitleFont}</code> | BODY: <code className="text-[#059669] font-mono">{selectedBodyFont}</code>
              </span>
              <span className="text-xs font-mono text-gray-500">1PX HAIRLINE FRAME / WARM PAPER</span>
            </div>

            {/* Display Title (64px) */}
            <div className="space-y-1">
              <div className="text-xs font-mono text-gray-500 uppercase flex items-center gap-2">
                <span>DISPLAY TITLE (TITLE FONT: {selectedTitleFont.toUpperCase()})</span>
              </div>
              <div className={`font-${selectedTitleFont} ${selectedWeight} ${tracking} text-3xl sm:text-5xl lg:text-6xl text-[#1B1C1A] leading-tight break-words`}>
                {sampleText}
              </div>
            </div>

            {/* Headline Large + Body Paragraph */}
            <div className="space-y-2 pt-4 border-t border-gray-200">
              <div className="text-xs font-mono text-gray-500 uppercase">HEADLINE LARGE + BODY PARAGRAPH HARMONY</div>
              <h2 className={`font-${selectedTitleFont} ${selectedWeight} text-2xl sm:text-3xl text-[#1B1C1A] ${tracking}`}>
                Constructivist Grid & Swiss Precision
              </h2>
              <p className={`font-${selectedBodyFont} text-sm sm:text-base text-gray-800 leading-relaxed max-w-3xl`}>
                This digital design specification pairs early 20th-century Bauhaus constructivism with modern layout hierarchy. By decoupling heading geometry from body reading typography, components achieve strong visual contrast while preserving legibility across dense data tables and technical documentation panels.
              </p>
            </div>

            {/* Headline Medium + Component UI Layout */}
            <div className="pt-4 border-t border-gray-200 space-y-3">
              <div className="text-xs font-mono text-gray-500 uppercase">COMPONENT UI CARD DEMO (PAIRED TOGETHER)</div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-[#FAF9F5] border border-[#1B1C1A] border-t-4 border-t-[#2563EB] p-4 rounded-[2px] space-y-3">
                  <div className="flex items-center justify-between border-b border-gray-200 pb-2">
                    <span className="text-xs font-mono font-bold uppercase text-[#1B1C1A]">MODULE SPECIFICATION</span>
                    <span className="text-xs font-mono text-gray-500 bg-white border border-[#1B1C1A] px-1.5 py-0.5 rounded-[1px]">REV_2.4</span>
                  </div>
                  <h3 className={`font-${selectedTitleFont} font-bold text-lg text-[#1B1C1A] leading-snug`}>
                    Academic Accreditation Metrics
                  </h3>
                  <p className={`font-${selectedBodyFont} text-xs text-gray-700 leading-relaxed`}>
                    Track student progress, institutional quality assurance compliance, and multi-departmental accreditation audits in real time.
                  </p>
                  <div className="pt-1 flex items-center gap-2">
                    <button className={`font-${selectedTitleFont} font-bold text-xs uppercase tracking-wider px-3 py-1.5 bg-[#1B1C1A] text-white border border-[#1B1C1A] rounded-[2px]`}>
                      VIEW AUDIT LOGS
                    </button>
                    <span className={`font-${selectedBodyFont} text-xs text-gray-500`}>Updated 2m ago</span>
                  </div>
                </div>

                <div className="bg-[#FAF9F5] border border-[#1B1C1A] border-t-4 border-t-[#059669] p-4 rounded-[2px] space-y-3">
                  <div className="flex items-center justify-between border-b border-gray-200 pb-2">
                    <span className="text-xs font-mono font-bold uppercase text-[#1B1C1A]">CANVAS POWER TOOL</span>
                    <span className="text-xs font-mono text-emerald-800 bg-emerald-100 border border-[#059669] px-1.5 py-0.5 rounded-[1px]">ACTIVE</span>
                  </div>
                  <h3 className={`font-${selectedTitleFont} font-bold text-lg text-[#1B1C1A] leading-snug`}>
                    Mechanical Progress Engine
                  </h3>
                  <p className={`font-${selectedBodyFont} text-xs text-gray-700 leading-relaxed`}>
                    Stepped loading indicators, hairline skeleton placeholders, and zero drop-shadow container boundaries for high-performance dashboards.
                  </p>
                  <div className="pt-1 flex items-center gap-2">
                    <button className={`font-${selectedTitleFont} font-bold text-xs uppercase tracking-wider px-3 py-1.5 bg-white text-[#1B1C1A] border border-[#1B1C1A] rounded-[2px] hover:bg-[#EFEEEA]`}>
                      CONFIGURE MATRIX
                    </button>
                    <span className={`font-${selectedBodyFont} text-xs text-gray-500`}>100% Client Sync</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Typeface Library Matrix (10 Fonts) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-[#1B1C1A] uppercase tracking-wider">
                Full Available Typeface Catalog (10 Curated Fonts)
              </h3>
              <span className="text-xs font-mono text-gray-500">Click any font to apply as Title or Body</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {[
                { id: 'space', name: 'Space Grotesk', class: 'font-space', cat: 'Constructivist Tech' },
                { id: 'syne', name: 'Syne', class: 'font-syne', cat: 'Avant-Garde Heavy' },
                { id: 'outfit', name: 'Outfit', class: 'font-outfit', cat: 'Geometric Modern' },
                { id: 'oswald', name: 'Oswald', class: 'font-oswald', cat: 'Tall Condensed' },
                { id: 'instrument', name: 'Instrument Serif', class: 'font-instrument', cat: 'Editorial Serif' },
                { id: 'playfair', name: 'Playfair Display', class: 'font-playfair', cat: 'Classic Serif' },
                { id: 'inter', name: 'Inter', class: 'font-inter', cat: 'Swiss Neutral' },
                { id: 'jakarta', name: 'Plus Jakarta', class: 'font-jakarta', cat: 'Humanist Sans' },
                { id: 'jetbrains', name: 'JetBrains Mono', class: 'font-jetbrains', cat: 'Technical Monospace' },
                { id: 'fira', name: 'Fira Code', class: 'font-fira', cat: 'Developer Mono' },
              ].map((tf, i) => (
                <div key={i} className="bg-white border border-[#1B1C1A] p-3 rounded-[2px] space-y-2 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between border-b border-gray-100 pb-1.5 mb-2">
                      <span className="text-xs font-mono font-bold text-[#1B1C1A] uppercase">{tf.name}</span>
                      <span className="text-xs font-mono text-gray-500 bg-[#EFEEEA] px-1 py-0.5 rounded-[1px]">{tf.cat}</span>
                    </div>
                    <div className={`${tf.class} font-bold text-sm text-[#1B1C1A] leading-tight`}>
                      Lightweight Bauhaus v2.4
                    </div>
                    <p className={`${tf.class} text-xs text-gray-600 mt-1 line-clamp-2`}>
                      The quick brown fox jumps over the lazy dog.
                    </p>
                  </div>

                  <div className="flex gap-1 pt-2 border-t border-gray-100">
                    <button
                      onClick={() => setSelectedTitleFont(tf.id)}
                      className={`flex-1 py-1 text-xs font-mono font-bold uppercase border rounded-[2px] ${
                        selectedTitleFont === tf.id
                          ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                          : 'bg-[#FAF9F5] text-gray-700 border-[#1B1C1A] hover:bg-[#EFEEEA]'
                      }`}
                    >
                      Use Title
                    </button>
                    <button
                      onClick={() => setSelectedBodyFont(tf.id)}
                      className={`flex-1 py-1 text-xs font-mono font-bold uppercase border rounded-[2px] ${
                        selectedBodyFont === tf.id
                          ? 'bg-[#2563EB] text-white border-[#1B1C1A]'
                          : 'bg-[#FAF9F5] text-gray-700 border-[#1B1C1A] hover:bg-[#EFEEEA]'
                      }`}
                    >
                      Use Body
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )
    },
    {
      category: 'modals',
      title: 'Modals, Dialogs & Slide-Over Drawers (Bauhaus Window Cards)',
      code: `/* 1. Bauhaus Window Modal */
<div className="bg-white border border-[#1B1C1A] rounded-[2px] w-full max-w-lg overflow-hidden">
  <div className="bg-[#FAF9F5] text-[#1B1C1A] px-3.5 py-2.5 flex items-center justify-between border-b border-[#1B1C1A]">
    <div className="flex items-center gap-2">
      <span className="w-2 h-2 bg-[#2563EB] inline-block"></span>
      <span className="text-xs font-mono font-bold uppercase tracking-wider">EDIT COURSE SPECIFICATION — SYS_042</span>
    </div>
    <button className="w-5 h-5 bg-[#B7102A] text-white border border-[#1B1C1A] flex items-center justify-center font-bold text-xs hover:bg-red-800 rounded-[1px]">✕</button>
  </div>
  <div className="p-5 space-y-4 bg-[#FAF9F5]">
    <p className="text-xs text-gray-800 leading-relaxed font-sans">
      Modify the primary grading rubric and assessment weight matrices for accreditation audit logs.
    </p>
    <div className="flex justify-end gap-2 pt-2 border-t border-gray-200">
      <button className="px-3 py-1.5 bg-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-[#EFEEEA]">CANCEL</button>
      <button className="px-3 py-1.5 bg-[#2563EB] text-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]">SAVE CHANGES</button>
    </div>
  </div>
</div>

/* 2. Destructive Confirmation Dialog */
<div className="bg-white border border-[#1B1C1A] border-t-4 border-t-[#B7102A] rounded-[2px] p-5 space-y-3">
  <div className="flex items-center gap-2 text-[#B7102A]">
    <AlertOctagon className="w-5 h-5" />
    <h3 className="text-xs font-bold uppercase tracking-wider">CONFIRM RECORD DELETION</h3>
  </div>
  <p className="text-xs text-gray-700">Are you sure you want to purge student record #8402? This action cannot be undone.</p>
</div>`,
      render: (
        <div className="space-y-6">
          {/* Modal Control Triggers */}
          <div className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] flex flex-wrap items-center justify-between gap-3">
            <div>
              <h4 className="text-xs font-bold uppercase text-[#1B1C1A]">Interactive Overlay Triggers</h4>
              <p className="text-xs text-gray-600">Click below to toggle live Bauhaus dialog previews or slide-over drawer sheets.</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setActiveModal('window')}
                className={`px-3 py-1.5 border text-xs font-bold uppercase rounded-[2px] transition-all ${
                  activeModal === 'window' ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]' : 'bg-white border-[#1B1C1A] text-[#1B1C1A] hover:bg-[#EFEEEA]'
                }`}
              >
                OPEN WINDOW MODAL
              </button>
              <button
                onClick={() => setActiveModal('destructive')}
                className={`px-3 py-1.5 border text-xs font-bold uppercase rounded-[2px] transition-all ${
                  activeModal === 'destructive' ? 'bg-[#B7102A] text-white border-[#1B1C1A]' : 'bg-white border-[#1B1C1A] text-[#B7102A] hover:bg-red-50'
                }`}
              >
                OPEN DESTRUCTIVE DIALOG
              </button>
              <button
                onClick={() => setActiveModal('drawer')}
                className={`px-3 py-1.5 border text-xs font-bold uppercase rounded-[2px] transition-all ${
                  activeModal === 'drawer' ? 'bg-[#2563EB] text-white border-[#1B1C1A]' : 'bg-white border-[#1B1C1A] text-[#2563EB] hover:bg-blue-50'
                }`}
              >
                TOGGLE SLIDE DRAWER
              </button>
              {activeModal !== 'none' && (
                <button
                  onClick={() => setActiveModal('none')}
                  className="px-2.5 py-1.5 bg-[#EFEEEA] border border-[#1B1C1A] text-xs font-mono font-bold uppercase hover:bg-white"
                >
                  CLOSE ACTIVE
                </button>
              )}
            </div>
          </div>

          {/* Live Preview Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Bauhaus Window Modal Specimen */}
            <div className={`bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden transition-all ${
              activeModal === 'window' ? 'ring-2 ring-[#2563EB]' : ''
            }`}>
              <div className="bg-[#FAF9F5] text-[#1B1C1A] px-3.5 py-2.5 flex items-center justify-between border-b border-[#1B1C1A]">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-[#2563EB] inline-block"></span>
                  <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#1B1C1A]">
                    COURSE SPECIFICATION — CS-402
                  </span>
                </div>
                <button
                  onClick={() => setActiveModal(activeModal === 'window' ? 'none' : 'window')}
                  className="w-5 h-5 bg-[#B7102A] text-white border border-[#1B1C1A] flex items-center justify-center font-bold text-xs hover:bg-red-800 rounded-[1px] transition-colors"
                  title="Close Modal"
                >
                  ✕
                </button>
              </div>

              <div className="p-5 space-y-4 bg-[#FAF9F5]">
                <div className="bg-[#EFEEEA] border border-[#1B1C1A] p-3 rounded-[2px] space-y-1">
                  <span className="text-xs font-mono text-gray-500 uppercase">SYSTEM PARAMETER</span>
                  <div className="text-xs font-bold text-[#1B1C1A]">ACCREDITATION COMPLIANCE LEVEL 4.0</div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono text-gray-600 uppercase block">Revision Note:</label>
                  <input
                    type="text"
                    defaultValue="Updated evaluation rubric following Q3 audit."
                    className="w-full bg-white border border-[#1B1C1A] px-3 py-1.5 text-xs font-sans rounded-[2px] focus:outline-none focus:ring-1 focus:ring-[#2563EB]"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-gray-200">
                  <span className="text-xs font-mono text-gray-500">REV: 2.4.0</span>
                  <div className="flex gap-2">
                    <button className="px-3 py-1.5 bg-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-[#EFEEEA]">
                      DISCARD
                    </button>
                    <button className="px-3 py-1.5 bg-[#2563EB] text-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-blue-700">
                      APPLY CHANGES
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Destructive Warning Dialog Specimen */}
            <div className={`bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden transition-all ${
              activeModal === 'destructive' ? 'ring-2 ring-[#B7102A]' : ''
            }`}>
              <div className="bg-[#FEF2F2] text-[#B7102A] px-3.5 py-2.5 flex items-center justify-between border-b border-[#1B1C1A]">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-[#B7102A] inline-block"></span>
                  <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#B7102A]">
                    SYSTEM CONFIRMATION — PURGE RECORD
                  </span>
                </div>
                <button
                  onClick={() => setActiveModal(activeModal === 'destructive' ? 'none' : 'destructive')}
                  className="w-5 h-5 bg-[#B7102A] text-white border border-[#1B1C1A] flex items-center justify-center font-bold text-xs hover:bg-red-800 rounded-[1px] transition-colors"
                  title="Close Modal"
                >
                  ✕
                </button>
              </div>

              <div className="p-5 space-y-4 bg-[#FAF9F5]">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2 text-[#B7102A]">
                    <AlertOctagon className="w-5 h-5 shrink-0" />
                    <div>
                      <h3 className="text-xs font-bold uppercase tracking-wider text-[#1B1C1A]">PURGE STUDENT RECORD</h3>
                      <span className="text-xs font-mono text-gray-500">ID: #SYS_STU_8402</span>
                    </div>
                  </div>
                  <span className="px-1.5 py-0.5 bg-[#FEE2E2] text-[#B7102A] border border-[#B7102A] text-xs font-mono font-bold uppercase rounded-[1px]">
                    HIGH IMPACT
                  </span>
                </div>

                <p className="text-xs text-gray-700 leading-relaxed bg-white p-3 border border-gray-200 rounded-[2px]">
                  Are you sure you want to permanently purge student record <strong className="text-[#1B1C1A]">#8402 (Alex Mercer)</strong>? All course submissions, grades, and accreditation tokens will be erased.
                </p>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-gray-200">
                  <button 
                    onClick={() => setActiveModal('none')}
                    className="px-3 py-1.5 bg-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-[#EFEEEA]"
                  >
                    CANCEL
                  </button>
                  <button 
                    onClick={() => setActiveModal('none')}
                    className="px-3 py-1.5 bg-[#B7102A] text-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-red-800"
                  >
                    PURGE RECORD
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Slide-over Drawer Inspector Specimen */}
          {activeModal === 'drawer' && (
            <div className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden animate-fadeIn">
              <div className="bg-[#FAF9F5] text-[#1B1C1A] px-3.5 py-2.5 flex items-center justify-between border-b border-[#1B1C1A]">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-[#2563EB]" />
                  <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-[#1B1C1A]">SIDE DRAWER INSPECTOR PANEL</h4>
                </div>
                <button
                  onClick={() => setActiveModal('none')}
                  className="flex items-center gap-1.5 px-2.5 py-1 bg-white hover:bg-[#FEE2E2] text-[#1B1C1A] hover:text-[#B7102A] border border-[#1B1C1A] text-xs font-mono font-bold uppercase rounded-[1px] transition-colors"
                  title="Close Inspector Panel"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>CLOSE PANEL</span>
                </button>
              </div>
              <div className="p-5 space-y-4 bg-[#FAF9F5]">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 bg-white border border-[#1B1C1A] rounded-[2px]">
                    <div className="text-xs font-mono text-gray-500 uppercase">COURSE STATUS</div>
                    <div className="font-bold text-[#059669] mt-1">ACCREDITED_V2.4</div>
                  </div>
                  <div className="p-3 bg-white border border-[#1B1C1A] rounded-[2px]">
                    <div className="text-xs font-mono text-gray-500 uppercase">ENROLLED STUDENTS</div>
                    <div className="font-bold text-[#1B1C1A] mt-1">148 STUDENTS</div>
                  </div>
                  <div className="p-3 bg-white border border-[#1B1C1A] rounded-[2px]">
                    <div className="text-xs font-mono text-gray-500 uppercase">AVERAGE METRIC</div>
                    <div className="font-bold text-[#2563EB] mt-1">88.4 / 100 PTS</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )
    },
    {
      category: 'toasts',
      title: 'Toasts & Notification Banners (Interactive Notification Stack)',
      code: `/* 1. Success Toast */
<div className="bg-[#D1FAE5] text-[#065F46] border border-[#1B1C1A] p-3 rounded-[2px] flex items-start gap-3">
  <CheckCircle2 className="w-4 h-4 text-[#065F46] shrink-0 mt-0.5" />
  <div className="flex-1">
    <div className="text-xs font-bold uppercase">ACCREDITATION REPORT PUBLISHED</div>
    <div className="text-[11px] opacity-90">Course brief exported to Markdown format.</div>
  </div>
  <button className="text-xs opacity-60 hover:opacity-100">✕</button>
</div>

/* 2. Warning Toast */
<div className="bg-[#FEF08A] text-[#1B1C1A] border border-[#1B1C1A] p-3 rounded-[2px] flex items-start gap-3">
  <AlertTriangle className="w-4 h-4 text-[#1B1C1A] shrink-0 mt-0.5" />
  <div className="flex-1">
    <div className="text-xs font-bold uppercase">WARN: THRESHOLD EXCEEDED</div>
    <div className="text-[11px] opacity-90">Assessment weights exceed 100% threshold.</div>
  </div>
</div>`,
      render: (
        <div className="space-y-6">
          {/* Toast Triggers Bar */}
          <div className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] flex flex-wrap items-center justify-between gap-3">
            <div>
              <h4 className="text-xs font-bold uppercase text-[#1B1C1A]">Interactive Toast Generator</h4>
              <p className="text-xs text-gray-600">Click a button to push a real-time toast notification into the stack below.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => addToast('success')}
                className="px-3 py-1.5 bg-[#D1FAE5] text-[#065F46] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-emerald-200"
              >
                + SUCCESS TOAST
              </button>
              <button
                onClick={() => addToast('warning')}
                className="px-3 py-1.5 bg-[#FEF08A] text-[#1B1C1A] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-yellow-300"
              >
                + WARNING TOAST
              </button>
              <button
                onClick={() => addToast('error')}
                className="px-3 py-1.5 bg-[#FEE2E2] text-[#B7102A] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-red-200"
              >
                + ERROR TOAST
              </button>
              <button
                onClick={() => addToast('info')}
                className="px-3 py-1.5 bg-[#EFF6FF] text-[#1E40AF] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-blue-200"
              >
                + INFO TOAST
              </button>
            </div>
          </div>

          {/* Toast Notification Stack Display */}
          <div className="space-y-2 max-w-xl">
            <div className="text-xs font-mono text-gray-500 uppercase flex items-center justify-between">
              <span>ACTIVE TOAST NOTIFICATION STACK ({toasts.length} ITEMS)</span>
              {toasts.length > 0 && (
                <button onClick={() => setToasts([])} className="hover:text-[#B7102A]">
                  CLEAR ALL
                </button>
              )}
            </div>

            {toasts.length === 0 ? (
              <div className="p-4 bg-[#FAF9F5] border border-dashed border-gray-300 text-center text-xs font-mono text-gray-400 rounded-[2px]">
                NO ACTIVE TOAST NOTIFICATIONS IN QUEUE
              </div>
            ) : (
              toasts.map((t) => (
                <div
                  key={t.id}
                  className={`border border-[#1B1C1A] rounded-[2px] p-3 flex items-start justify-between gap-3 animate-fadeIn ${
                    t.type === 'success' ? 'bg-[#D1FAE5] text-[#065F46]' :
                    t.type === 'warning' ? 'bg-[#FEF08A] text-[#1B1C1A]' :
                    t.type === 'error' ? 'bg-[#FEE2E2] text-[#B7102A]' :
                    'bg-[#BFDBFE] text-[#1E40AF]'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    {t.type === 'success' && <CheckCircle2 className="w-4 h-4 text-[#065F46] shrink-0 mt-0.5" />}
                    {t.type === 'warning' && <AlertTriangle className="w-4 h-4 text-[#1B1C1A] shrink-0 mt-0.5" />}
                    {t.type === 'error' && <AlertOctagon className="w-4 h-4 text-[#B7102A] shrink-0 mt-0.5" />}
                    {t.type === 'info' && <Info className="w-4 h-4 text-[#1E40AF] shrink-0 mt-0.5" />}

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold uppercase">{t.title}</span>
                        <span className="text-xs font-mono opacity-60">[{t.time}]</span>
                      </div>
                      <p className="text-xs opacity-80 mt-0.5 leading-snug">{t.message}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => removeToast(t.id)}
                    className="text-xs font-bold opacity-60 hover:opacity-100 p-0.5"
                  >
                    ✕
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )
    },
    {
      category: 'forms',
      title: '1. Input Controls (Inputs, Textarea, Sliders, Steppers, Pickers, Radios, Switches, Dropdowns)',
      code: `/* 1. Range Track Slider */
<input 
  type="range" min="0" max="100" value={sliderVal} 
  onChange={(e) => setSliderVal(Number(e.target.value))}
  className="w-full accent-[#2563EB]"
/>

/* 2. Two-Segment Stepper Control */
<div className="inline-flex border border-[#1B1C1A] rounded-[2px] overflow-hidden">
  <button onClick={() => setStepperVal(v => Math.max(1, v - 1))} className="px-2.5 py-1 bg-white hover:bg-[#EFEEEA] font-mono font-bold">-</button>
  <span className="px-3 py-1 bg-[#FAF9F5] font-mono font-bold border-x border-[#1B1C1A]">{stepperVal}</span>
  <button onClick={() => setStepperVal(v => v + 1)} className="px-2.5 py-1 bg-white hover:bg-[#EFEEEA] font-mono font-bold">+</button>
</div>

/* 3. Date & Time Pickers */
<input type="date" value={pickerDate} className="bg-white border border-[#1B1C1A] px-2.5 py-1.5 text-xs font-mono rounded-[2px]" />
<input type="time" value={pickerTime} className="bg-white border border-[#1B1C1A] px-2.5 py-1.5 text-xs font-mono rounded-[2px]" />`,
      render: (
        <div className="bg-white border border-[#1B1C1A] p-6 rounded-[2px] space-y-6">
          <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-3">
            <div>
              <h4 className="text-xs font-bold uppercase text-[#1B1C1A]">Interactive Input Controls Specification</h4>
              <p className="text-xs text-gray-600">Text inputs, range sliders, increment steppers, calendar date & time pickers, switches, and radio groups.</p>
            </div>
            <span className="text-xs font-mono bg-[#EFEEEA] border border-[#1B1C1A] px-2 py-0.5 font-bold uppercase">
              INPUT MATRIX
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left Column: Text Fields, Sliders, Steppers, Pickers */}
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-mono text-gray-600 uppercase block">Course Module Title (Text Field):</label>
                <input
                  type="text"
                  value={formData.courseName}
                  onChange={(e) => setFormData({ ...formData, courseName: e.target.value })}
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs font-sans rounded-[2px] focus:outline-none focus:ring-1 focus:ring-[#2563EB]"
                />
              </div>

              {/* Slider & Stepper Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px]">
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-mono text-gray-600 uppercase">Range Slider:</label>
                    <span className="text-[10px] font-mono font-bold text-[#2563EB] bg-blue-50 px-1 border border-blue-200">{sliderVal}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={sliderVal}
                    onChange={(e) => setSliderVal(Number(e.target.value))}
                    className="w-full accent-[#2563EB] cursor-pointer"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono text-gray-600 uppercase block">Stepper Control:</label>
                  <div className="inline-flex items-center border border-[#1B1C1A] rounded-[2px] overflow-hidden bg-white">
                    <button
                      onClick={() => setStepperVal(v => Math.max(1, v - 1))}
                      className="px-2.5 py-1 bg-white hover:bg-[#EFEEEA] font-mono font-bold text-xs text-[#1B1C1A] border-r border-[#1B1C1A]"
                      title="Decrement Value"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="px-3 py-1 bg-[#FAF9F5] font-mono font-bold text-xs text-[#1B1C1A] min-w-[36px] text-center">
                      {stepperVal.toString().padStart(2, '0')}
                    </span>
                    <button
                      onClick={() => setStepperVal(v => v + 1)}
                      className="px-2.5 py-1 bg-white hover:bg-[#EFEEEA] font-mono font-bold text-xs text-[#1B1C1A] border-l border-[#1B1C1A]"
                      title="Increment Value"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Date & Time Pickers */}
              <div className="space-y-1">
                <label className="text-xs font-mono text-gray-600 uppercase block">Pickers (Date & Time Selector):</label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center gap-1.5 p-1.5 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px]">
                    <CalendarDays className="w-3.5 h-3.5 text-[#2563EB] shrink-0" />
                    <input
                      type="date"
                      value={pickerDate}
                      onChange={(e) => setPickerDate(e.target.value)}
                      className="w-full bg-transparent text-xs font-mono focus:outline-none"
                    />
                  </div>
                  <div className="flex items-center gap-1.5 p-1.5 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px]">
                    <Clock className="w-3.5 h-3.5 text-[#059669] shrink-0" />
                    <input
                      type="time"
                      value={pickerTime}
                      onChange={(e) => setPickerTime(e.target.value)}
                      className="w-full bg-transparent text-xs font-mono focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono text-gray-600 uppercase block">Evaluation Syllabus Notes (Multi-Line Box):</label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs font-sans rounded-[2px] focus:outline-none focus:ring-1 focus:ring-[#2563EB]"
                />
              </div>
            </div>

            {/* Right Column: Checkboxes, Radios, Switches, Dropdown */}
            <div className="space-y-5 bg-[#FAF9F5] border border-[#1B1C1A] p-4 rounded-[2px]">
              <div className="space-y-1">
                <label className="text-xs font-mono text-gray-600 uppercase block">Dropdown Lists (Select Menu):</label>
                <select
                  value={formData.department}
                  onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                  className="w-full bg-white border border-[#1B1C1A] px-3 py-2 text-xs font-sans rounded-[2px] focus:outline-none focus:ring-1 focus:ring-[#2563EB]"
                >
                  <option>STEM / Physical Sciences</option>
                  <option>Computer Science & AI</option>
                  <option>Humanities & Design Systems</option>
                </select>
              </div>

              <div>
                <span className="text-xs font-mono text-gray-500 uppercase block mb-2">Checkboxes & Binary Switches:</span>
                <div className="space-y-3">
                  <label className="flex items-center gap-2 text-xs font-bold text-[#1B1C1A] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.notifyStudents}
                      onChange={(e) => setFormData({ ...formData, notifyStudents: e.target.checked })}
                      className="w-4 h-4 accent-[#1B1C1A] border border-[#1B1C1A] rounded-[0px]"
                    />
                    <span>NOTIFY ENROLLED STUDENTS ON SPEC UPDATE</span>
                  </label>

                  <div className="flex items-center justify-between pt-2 border-t border-gray-200">
                    <span className="text-xs font-bold text-[#1B1C1A] uppercase">REQUIRE FACULTY APPROVAL</span>
                    <ToggleSwitch
                      checked={formData.requireApproval}
                      onChange={(val) => setFormData({ ...formData, requireApproval: val })}
                      variant="yellow"
                      size="md"
                    />
                  </div>
                </div>
              </div>

              <div>
                <span className="text-xs font-mono text-gray-500 uppercase block mb-2">Grading Metric Radio Group:</span>
                <div className="space-y-2">
                  {[
                    { id: 'letter', label: 'STANDARD LETTER GRADING (A-F)' },
                    { id: 'passfall', label: 'BINARY PASS / FAIL MATRIX' },
                    { id: 'numeric', label: 'NUMERIC SCORE (0-100 PTS)' },
                  ].map((r) => (
                    <label key={r.id} className="flex items-center gap-2 text-xs font-sans text-gray-800 cursor-pointer">
                      <input
                        type="radio"
                        name="gradingScale"
                        checked={formData.gradingScale === r.id}
                        onChange={() => setFormData({ ...formData, gradingScale: r.id })}
                        className="w-4 h-4 accent-[#2563EB]"
                      />
                      <span className="font-bold">{r.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      category: 'forms',
      title: '1B. Mechanical Tactile Binary Switches (Bauhaus Hardware Toggle)',
      code: `import { ToggleSwitch } from '../ToggleSwitch';

/* 1. Standard Ochre Yellow Mechanical Toggle */
<ToggleSwitch
  checked={isEnabled}
  onChange={setIsEnabled}
  variant="yellow"
  size="md"
  label="ENABLE FACULTY SYLLABUS LOCK"
  sublabel="Enforces 1px high-contrast structural validation"
/>

/* 2. Color Variants (Blue, Green, Red, Dark Charcoal) */
<ToggleSwitch checked={val} onChange={setVal} variant="blue" size="sm" />
<ToggleSwitch checked={val} onChange={setVal} variant="green" size="md" />
<ToggleSwitch checked={val} onChange={setVal} variant="red" size="lg" />

/* 3. Disabled Hardware State */
<ToggleSwitch checked={true} onChange={() => {}} disabled={true} label="READ-ONLY SECURITY SYSTEM" />`,
      render: (
        <div className="bg-white border border-[#1B1C1A] p-6 rounded-[2px] space-y-6">
          <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-3">
            <div>
              <h4 className="text-xs font-bold uppercase text-[#1B1C1A]">Mechanical Binary Hardware Toggle Matrix</h4>
              <p className="text-xs text-gray-600">Precision 1px bordered toggle switch with embedded ON/OFF track labels, tactile slider grip ridges, and spring transitions.</p>
            </div>
            <span className="text-xs font-mono bg-[#EFEEEA] border border-[#1B1C1A] px-2 py-0.5 font-bold uppercase text-[#1B1C1A]">
              HARDWARE SPEC
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left: Interactive Color Variants with Labels */}
            <div className="bg-[#FAF9F5] border border-[#1B1C1A] p-4 rounded-[2px] space-y-4">
              <span className="text-xs font-mono text-gray-500 uppercase block border-b border-gray-200 pb-2">
                1. Interactive Theme Variants:
              </span>

              <div className="space-y-3.5">
                <ToggleSwitch
                  checked={demoSwitches.yellow}
                  onChange={(val) => setDemoSwitches({ ...demoSwitches, yellow: val })}
                  variant="yellow"
                  size="md"
                  label="OCHRE YELLOW (DEFAULT)"
                  sublabel="Classically paired with dark slate #1B1C1A track"
                />

                <ToggleSwitch
                  checked={demoSwitches.blue}
                  onChange={(val) => setDemoSwitches({ ...demoSwitches, blue: val })}
                  variant="blue"
                  size="md"
                  label="COBALT BLUE VARIANT"
                  sublabel="Active state highlights with #2563EB"
                />

                <ToggleSwitch
                  checked={demoSwitches.green}
                  onChange={(val) => setDemoSwitches({ ...demoSwitches, green: val })}
                  variant="green"
                  size="md"
                  label="EMERALD GREEN VARIANT"
                  sublabel="Active state highlights with #059669"
                />

                <ToggleSwitch
                  checked={demoSwitches.red}
                  onChange={(val) => setDemoSwitches({ ...demoSwitches, red: val })}
                  variant="red"
                  size="md"
                  label="BAUHAUS RED VARIANT"
                  sublabel="Active state highlights with #B7102A"
                />
              </div>
            </div>

            {/* Right: Sizing Matrix & Disabled States */}
            <div className="bg-[#FAF9F5] border border-[#1B1C1A] p-4 rounded-[2px] space-y-4">
              <span className="text-xs font-mono text-gray-500 uppercase block border-b border-gray-200 pb-2">
                2. Mechanical Sizing & Physical States:
              </span>

              <div className="space-y-4">
                <div className="flex items-center justify-between bg-white p-2.5 border border-[#1B1C1A] rounded-[2px]">
                  <div>
                    <div className="text-xs font-bold uppercase text-[#1B1C1A]">Compact Size (sm)</div>
                    <div className="text-[10px] font-mono text-gray-500">Compact track format</div>
                  </div>
                  <ToggleSwitch
                    checked={demoSwitches.yellow}
                    onChange={(val) => setDemoSwitches({ ...demoSwitches, yellow: val })}
                    size="sm"
                    variant="yellow"
                  />
                </div>

                <div className="flex items-center justify-between bg-white p-2.5 border border-[#1B1C1A] rounded-[2px]">
                  <div>
                    <div className="text-xs font-bold uppercase text-[#1B1C1A]">Standard Size (md)</div>
                    <div className="text-[10px] font-mono text-gray-500">Standard track format</div>
                  </div>
                  <ToggleSwitch
                    checked={demoSwitches.blue}
                    onChange={(val) => setDemoSwitches({ ...demoSwitches, blue: val })}
                    size="md"
                    variant="blue"
                  />
                </div>

                <div className="flex items-center justify-between bg-white p-2.5 border border-[#1B1C1A] rounded-[2px]">
                  <div>
                    <div className="text-xs font-bold uppercase text-[#1B1C1A]">Expanded Size (lg)</div>
                    <div className="text-[10px] font-mono text-gray-500">Large track format</div>
                  </div>
                  <ToggleSwitch
                    checked={demoSwitches.red}
                    onChange={(val) => setDemoSwitches({ ...demoSwitches, red: val })}
                    size="lg"
                    variant="red"
                  />
                </div>

                <div className="flex items-center justify-between bg-white p-2.5 border border-[#1B1C1A] rounded-[2px] opacity-75">
                  <div>
                    <div className="text-xs font-bold uppercase text-gray-700">Disabled Locks</div>
                    <div className="text-[10px] font-mono text-gray-500">Locked hardware state</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <ToggleSwitch checked={false} onChange={() => {}} disabled={true} size="sm" />
                    <ToggleSwitch checked={true} onChange={() => {}} disabled={true} size="sm" variant="yellow" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      category: 'nav',
      title: '2. Navigational Components (Navbar, Special Icon Menus, Breadcrumbs, Pagination, Sidebar, Tabs & Search)',
      code: `/* 1. Breadcrumbs */
<nav className="flex items-center gap-1.5 text-xs font-mono text-gray-600">
  <span className="hover:text-[#2563EB] cursor-pointer">HOME</span>
  <span>/</span>
  <span className="hover:text-[#2563EB] cursor-pointer">SPECS</span>
  <span>/</span>
  <span className="font-bold text-[#1B1C1A]">PHYSICS_402</span>
</nav>

/* 2. Pagination Controls */
<div className="flex items-center gap-1">
  <button className="px-2.5 py-1 bg-white border border-[#1B1C1A] text-xs font-mono font-bold">PREV</button>
  <button className="px-2.5 py-1 bg-[#1B1C1A] text-white text-xs font-mono font-bold">1</button>
  <button className="px-2.5 py-1 bg-white border border-[#1B1C1A] text-xs font-mono font-bold">NEXT</button>
</div>`,
      render: (
        <div className="space-y-6">
          {/* Main Navbar Preview */}
          <div className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden">
            <div className="bg-[#1B1C1A] text-white px-4 py-2 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="px-2 py-0.5 bg-[#B7102A] text-white text-xs font-mono font-bold uppercase tracking-wider">
                  BAUHAUS_OS
                </span>
                <span className="text-xs font-mono text-gray-300 hidden sm:inline">v2.4 SYSTEM CONSOLE</span>
              </div>

              {/* Special Navigation Menus Row */}
              <div className="flex items-center gap-2">
                {/* Search Bar */}
                <div className="hidden md:flex items-center gap-1 bg-white/10 px-2 py-1 rounded-[2px] border border-white/20">
                  <Search className="w-3.5 h-3.5 text-gray-300" />
                  <input
                    type="text"
                    placeholder="Search matrix..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-transparent text-xs text-white placeholder-gray-400 focus:outline-none w-28"
                  />
                  {searchQuery && (
                    <button onClick={() => setSearchQuery('')} className="text-xs text-gray-400 hover:text-white">✕</button>
                  )}
                </div>

                {/* Hamburger Menu Icon (3 horizontal lines) */}
                <div className="relative">
                  <button
                    onClick={() => setIsHamburgerOpen(!isHamburgerOpen)}
                    className={`p-1.5 border rounded-[1px] transition-colors ${
                      isHamburgerOpen ? 'bg-[#2563EB] text-white border-white' : 'bg-white/10 border-white/30 text-white hover:bg-white/20'
                    }`}
                    title="Hamburger Menu (Nav Drawer)"
                  >
                    <Menu className="w-4 h-4" />
                  </button>
                  {isHamburgerOpen && (
                    <div className="absolute right-0 top-full mt-1 w-48 bg-white text-[#1B1C1A] border border-[#1B1C1A] shadow-lg rounded-[2px] p-2 z-20 space-y-1 font-mono text-xs">
                      <div className="font-bold border-b border-gray-200 pb-1 text-[10px] text-gray-500 uppercase">HAMBURGER MENU</div>
                      <a href="#overview" className="block p-1.5 hover:bg-[#EFEEEA] font-bold">1. DASHBOARD OVERVIEW</a>
                      <a href="#courses" className="block p-1.5 hover:bg-[#EFEEEA] font-bold">2. ACCREDITED COURSES</a>
                      <a href="#audit" className="block p-1.5 hover:bg-[#EFEEEA] font-bold">3. AUDIT LOGS</a>
                      <a href="#settings" className="block p-1.5 hover:bg-[#EFEEEA] font-bold">4. SYSTEM SETTINGS</a>
                    </div>
                  )}
                </div>

                {/* Döner Menu Icon (3 lines decreasing length - Filters) */}
                <div className="relative">
                  <button
                    onClick={() => setIsDonerOpen(!isDonerOpen)}
                    className={`p-1.5 border rounded-[1px] transition-colors ${
                      isDonerOpen ? 'bg-[#059669] text-white border-white' : 'bg-white/10 border-white/30 text-white hover:bg-white/20'
                    }`}
                    title="Döner Menu (Filter Criteria)"
                  >
                    <SlidersHorizontal className="w-4 h-4" />
                  </button>
                  {isDonerOpen && (
                    <div className="absolute right-0 top-full mt-1 w-52 bg-white text-[#1B1C1A] border border-[#1B1C1A] shadow-lg rounded-[2px] p-2 z-20 space-y-2 font-mono text-xs">
                      <div className="font-bold border-b border-gray-200 pb-1 text-[10px] text-gray-500 uppercase">DÖNER FILTER MENU</div>
                      <label className="flex items-center gap-2 cursor-pointer text-xs">
                        <input type="checkbox" defaultChecked className="accent-[#059669]" />
                        <span>Show Active Courses</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer text-xs">
                        <input type="checkbox" defaultChecked className="accent-[#059669]" />
                        <span>STEM Department Only</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer text-xs">
                        <input type="checkbox" className="accent-[#059669]" />
                        <span>Include Archived Specs</span>
                      </label>
                    </div>
                  )}
                </div>

                {/* Bento Menu Icon (3x3 grid) */}
                <div className="relative">
                  <button
                    onClick={() => setIsBentoOpen(!isBentoOpen)}
                    className={`p-1.5 border rounded-[1px] transition-colors ${
                      isBentoOpen ? 'bg-[#B7102A] text-white border-white' : 'bg-white/10 border-white/30 text-white hover:bg-white/20'
                    }`}
                    title="Bento Menu (Apps Grid)"
                  >
                    <Grid className="w-4 h-4" />
                  </button>
                  {isBentoOpen && (
                    <div className="absolute right-0 top-full mt-1 w-56 bg-white text-[#1B1C1A] border border-[#1B1C1A] shadow-lg rounded-[2px] p-3 z-20 font-mono text-xs space-y-2">
                      <div className="font-bold border-b border-gray-200 pb-1 text-[10px] text-gray-500 uppercase">BENTO APPS LAUNCHER</div>
                      <div className="grid grid-cols-3 gap-2 text-center">
                        <button className="p-2 bg-[#FAF9F5] border border-[#1B1C1A] hover:bg-[#2563EB] hover:text-white rounded-[2px] text-[10px] font-bold">
                          SYLLABUS
                        </button>
                        <button className="p-2 bg-[#FAF9F5] border border-[#1B1C1A] hover:bg-[#059669] hover:text-white rounded-[2px] text-[10px] font-bold">
                          GRADES
                        </button>
                        <button className="p-2 bg-[#FAF9F5] border border-[#1B1C1A] hover:bg-[#B7102A] hover:text-white rounded-[2px] text-[10px] font-bold">
                          AUDIT
                        </button>
                        <button className="p-2 bg-[#FAF9F5] border border-[#1B1C1A] hover:bg-[#7C3AED] hover:text-white rounded-[2px] text-[10px] font-bold">
                          CHAT
                        </button>
                        <button className="p-2 bg-[#FAF9F5] border border-[#1B1C1A] hover:bg-[#D97706] hover:text-white rounded-[2px] text-[10px] font-bold">
                          LABS
                        </button>
                        <button className="p-2 bg-[#FAF9F5] border border-[#1B1C1A] hover:bg-black hover:text-white rounded-[2px] text-[10px] font-bold">
                          SPECS
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Kebab Menu Icon (3 vertical dots) */}
                <div className="relative">
                  <button
                    onClick={() => setIsKebabOpen(!isKebabOpen)}
                    className={`p-1.5 border rounded-[1px] transition-colors ${
                      isKebabOpen ? 'bg-white text-[#1B1C1A] border-white' : 'bg-white/10 border-white/30 text-white hover:bg-white/20'
                    }`}
                    title="Kebab Menu (Vertical Dots)"
                  >
                    <MoreVertical className="w-4 h-4" />
                  </button>
                  {isKebabOpen && (
                    <div className="absolute right-0 top-full mt-1 w-40 bg-white text-[#1B1C1A] border border-[#1B1C1A] shadow-lg rounded-[2px] p-1.5 z-20 space-y-1 font-mono text-xs">
                      <button className="w-full text-left px-2 py-1 hover:bg-[#EFEEEA] font-bold">EDIT RECORD</button>
                      <button className="w-full text-left px-2 py-1 hover:bg-[#EFEEEA] font-bold">DUPLICATE SPEC</button>
                      <button className="w-full text-left px-2 py-1 hover:bg-[#FEE2E2] text-[#B7102A] font-bold">DELETE ITEM</button>
                    </div>
                  )}
                </div>

                {/* Meatballs Menu Icon (3 horizontal dots) */}
                <div className="relative">
                  <button
                    onClick={() => setIsMeatballsOpen(!isMeatballsOpen)}
                    className={`p-1.5 border rounded-[1px] transition-colors ${
                      isMeatballsOpen ? 'bg-white text-[#1B1C1A] border-white' : 'bg-white/10 border-white/30 text-white hover:bg-white/20'
                    }`}
                    title="Meatballs Menu (Horizontal Dots)"
                  >
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                  {isMeatballsOpen && (
                    <div className="absolute right-0 top-full mt-1 w-44 bg-white text-[#1B1C1A] border border-[#1B1C1A] shadow-lg rounded-[2px] p-1.5 z-20 space-y-1 font-mono text-xs">
                      <button className="w-full text-left px-2 py-1 hover:bg-[#EFEEEA] font-bold">SHARE MODULE</button>
                      <button className="w-full text-left px-2 py-1 hover:bg-[#EFEEEA] font-bold">EXPORT TO PDF</button>
                      <button className="w-full text-left px-2 py-1 hover:bg-[#EFEEEA] font-bold">COPY DIRECT LINK</button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Sub-Navbar Tabs Bar & Breadcrumbs */}
            <div className="bg-[#EFEEEA] px-4 py-2 border-t border-[#1B1C1A] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
              {/* Breadcrumbs */}
              <div className="flex items-center gap-1.5 text-gray-600">
                <span className="hover:text-[#2563EB] cursor-pointer">HOME</span>
                <span className="text-gray-400">/</span>
                <span className="hover:text-[#2563EB] cursor-pointer">ACADEMIC_SPECS</span>
                <span className="text-gray-400">/</span>
                <span className="font-bold text-[#1B1C1A]">PHYSICS_402</span>
              </div>

              {/* Tabs Bar Switcher */}
              <div className="flex items-center gap-1 bg-white p-0.5 border border-[#1B1C1A] rounded-[2px]">
                {['overview', 'syllabus', 'students', 'audit'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveNavTab(tab)}
                    className={`px-2.5 py-1 text-[11px] font-bold uppercase rounded-[1px] transition-colors ${
                      activeNavTab === tab
                        ? 'bg-[#1B1C1A] text-white'
                        : 'text-gray-600 hover:text-[#1B1C1A] hover:bg-[#EFEEEA]'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar & Pagination Showcase Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Sidebar Column Specimen */}
            <div className="bg-white border border-[#1B1C1A] rounded-[2px] p-3 space-y-2">
              <div className="text-[10px] font-mono font-bold text-gray-500 uppercase px-2">VERTICAL SIDEBAR NAVIGATION</div>
              <div className="space-y-1 font-mono text-xs">
                <a href="#c1" className="flex items-center justify-between p-2 bg-[#1B1C1A] text-white rounded-[1px] font-bold">
                  <div className="flex items-center gap-2">
                    <Layers className="w-3.5 h-3.5" />
                    <span>Active Briefs</span>
                  </div>
                  <span className="px-1.5 py-0.5 bg-[#2563EB] text-white text-[10px] font-bold rounded-[1px]">12</span>
                </a>
                <a href="#c2" className="flex items-center justify-between p-2 hover:bg-[#EFEEEA] text-[#1B1C1A] rounded-[1px] font-bold">
                  <div className="flex items-center gap-2">
                    <User className="w-3.5 h-3.5 text-gray-500" />
                    <span>Faculty Roster</span>
                  </div>
                  <span className="px-1.5 py-0.5 bg-gray-200 text-[#1B1C1A] text-[10px] font-bold rounded-[1px]">4</span>
                </a>
                <a href="#c3" className="flex items-center justify-between p-2 hover:bg-[#EFEEEA] text-[#1B1C1A] rounded-[1px] font-bold">
                  <div className="flex items-center gap-2">
                    <Archive className="w-3.5 h-3.5 text-gray-500" />
                    <span>Archived Logs</span>
                  </div>
                  <span className="px-1.5 py-0.5 bg-gray-200 text-[#1B1C1A] text-[10px] font-bold rounded-[1px]">88</span>
                </a>
              </div>
            </div>

            {/* Pagination Controls & Search Bar Column */}
            <div className="md:col-span-2 bg-white border border-[#1B1C1A] rounded-[2px] p-4 space-y-4">
              <div className="flex items-center justify-between border-b border-gray-200 pb-2">
                <span className="text-xs font-mono font-bold uppercase text-[#1B1C1A]">PAGINATION & SEARCH COMPONENTS</span>
                <span className="text-xs font-mono text-gray-500">PAGE {currentPage} OF 10</span>
              </div>

              {/* Dedicated Search Field */}
              <div className="relative">
                <Search className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Dedicated Search Field with Icon..."
                  className="w-full bg-[#FAF9F5] border border-[#1B1C1A] pl-9 pr-3 py-2 text-xs font-mono rounded-[2px] focus:outline-none focus:ring-1 focus:ring-[#2563EB]"
                />
              </div>

              {/* Numbered Pagination Row */}
              <div className="flex items-center justify-between pt-2 border-t border-gray-200">
                <button
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-1.5 bg-white border border-[#1B1C1A] text-xs font-mono font-bold rounded-[2px] hover:bg-[#EFEEEA] disabled:opacity-40"
                >
                  ← PREV
                </button>

                <div className="flex items-center gap-1 font-mono text-xs">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button
                      key={num}
                      onClick={() => setCurrentPage(num)}
                      className={`w-7 h-7 flex items-center justify-center font-bold border rounded-[2px] transition-colors ${
                        currentPage === num
                          ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                          : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#EFEEEA]'
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                  <span className="px-1 text-gray-400">...</span>
                  <button
                    onClick={() => setCurrentPage(10)}
                    className="w-7 h-7 flex items-center justify-center font-bold border border-[#1B1C1A] bg-white text-[#1B1C1A] hover:bg-[#EFEEEA] rounded-[2px]"
                  >
                    10
                  </button>
                </div>

                <button
                  onClick={() => setCurrentPage(p => Math.min(10, p + 1))}
                  disabled={currentPage === 10}
                  className="px-3 py-1.5 bg-white border border-[#1B1C1A] text-xs font-mono font-bold rounded-[2px] hover:bg-[#EFEEEA] disabled:opacity-40"
                >
                  NEXT →
                </button>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      category: 'containers',
      title: '4. Container Components (Cards, Accordions, Modals/Dialogs & Carousels)',
      code: `/* 1. Accordions (Expandable FAQ/Details) */
<div className="border border-[#1B1C1A] rounded-[2px]">
  <button onClick={() => setOpenAccordion(openAccordion === 1 ? null : 1)} className="w-full p-3 flex justify-between">
    <span>ACCORDION HEADER</span>
    <ChevronDown className={openAccordion === 1 ? 'rotate-180' : ''} />
  </button>
  {openAccordion === 1 && <div className="p-3 border-t">ACCORDION CONTENT</div>}
</div>

/* 2. Interactive Carousel Controls */
<div className="flex justify-between">
  <button onClick={() => setCarouselIndex(i => Math.max(0, i - 1))}>PREV</button>
  <button onClick={() => setCarouselIndex(i => Math.min(items.length - 1, i + 1))}>NEXT</button>
</div>`,
      render: (
        <div className="space-y-6">
          {/* Accordions Specimen */}
          <div className="bg-white border border-[#1B1C1A] p-5 rounded-[2px] space-y-3">
            <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-2">
              <h4 className="text-xs font-bold uppercase text-[#1B1C1A]">Interactive Accordions (Expandable Details)</h4>
              <span className="text-xs font-mono text-gray-500">TOGGLE PANELS BELOW</span>
            </div>

            <div className="space-y-2">
              {[
                { id: 1, title: 'WHAT ARE THE BAUHAUS BORDER RULES?', content: 'All interactive containers require strict 1px hairline dark borders (#1B1C1A), 2px corner radii, zero drop-shadow glow, and warm paper background canvas (#FAF9F5).' },
                { id: 2, title: 'HOW DO MODULE TOP ACCENT STRIPS WORK?', content: 'Module cards use a 4px solid top border strip in primary colors (#2563EB electric blue, #059669 emerald green, or #B7102A red) to designate category importance.' },
                { id: 3, title: 'ARE MODALS AND CAROUSELS RESPONSIVE?', content: 'Yes, all container modals, side drawers, and swipable carousels auto-scale fluidly across mobile touch screens and ultra-wide desktop displays.' }
              ].map((acc) => (
                <div key={acc.id} className="border border-[#1B1C1A] rounded-[2px] overflow-hidden bg-[#FAF9F5]">
                  <button
                    onClick={() => setOpenAccordion(openAccordion === acc.id ? null : acc.id)}
                    className="w-full p-3 flex items-center justify-between text-left text-xs font-mono font-bold text-[#1B1C1A] hover:bg-[#EFEEEA] transition-colors"
                  >
                    <span>{acc.id}. {acc.title}</span>
                    <ChevronDown className={`w-4 h-4 text-[#2563EB] transition-transform duration-200 ${openAccordion === acc.id ? 'rotate-180' : ''}`} />
                  </button>
                  {openAccordion === acc.id && (
                    <div className="p-3 bg-white border-t border-[#1B1C1A] text-xs text-gray-700 leading-relaxed font-sans animate-fadeIn">
                      {acc.content}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Interactive Carousel Specimen */}
          <div className="bg-white border border-[#1B1C1A] p-5 rounded-[2px] space-y-4">
            <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-2">
              <div>
                <h4 className="text-xs font-bold uppercase text-[#1B1C1A]">Swipable Horizontal Gallery Carousel</h4>
                <p className="text-xs text-gray-600">Click controls or indicator dots to cycle through container cards.</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-[#2563EB]">CARD {carouselIndex + 1} / {carouselItems.length}</span>
                <div className="flex gap-1">
                  <button
                    onClick={() => setCarouselIndex(i => Math.max(0, i - 1))}
                    disabled={carouselIndex === 0}
                    className="p-1 bg-white border border-[#1B1C1A] hover:bg-[#EFEEEA] disabled:opacity-30 rounded-[1px]"
                    title="Previous Slide"
                  >
                    <ChevronLeft className="w-4 h-4 text-[#1B1C1A]" />
                  </button>
                  <button
                    onClick={() => setCarouselIndex(i => Math.min(carouselItems.length - 1, i + 1))}
                    disabled={carouselIndex === carouselItems.length - 1}
                    className="p-1 bg-white border border-[#1B1C1A] hover:bg-[#EFEEEA] disabled:opacity-30 rounded-[1px]"
                    title="Next Slide"
                  >
                    <ChevronRight className="w-4 h-4 text-[#1B1C1A]" />
                  </button>
                </div>
              </div>
            </div>

            {/* Carousel Active Slide Card */}
            <div className="bg-[#FAF9F5] border border-[#1B1C1A] border-t-4 border-t-[#2563EB] p-6 rounded-[2px] transition-all duration-300">
              <div className="flex items-center justify-between mb-3">
                <span className={`px-2 py-0.5 ${carouselItems[carouselIndex].color} text-white text-xs font-mono font-bold uppercase rounded-[1px]`}>
                  {carouselItems[carouselIndex].tag}
                </span>
                <span className="text-xs font-mono text-gray-500">CAROUSEL ITEM SLIDE #{carouselIndex + 1}</span>
              </div>
              <h3 className="text-xl font-black text-[#1B1C1A] uppercase tracking-tight">
                {carouselItems[carouselIndex].title}
              </h3>
              <p className="text-xs text-gray-700 mt-2 leading-relaxed">
                {carouselItems[carouselIndex].desc}. Built with zero drop-shadow 1px hairline border containers and tactile control feedback.
              </p>
            </div>

            {/* Carousel Dot Indicators */}
            <div className="flex items-center justify-center gap-2 pt-1">
              {carouselItems.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCarouselIndex(idx)}
                  className={`w-3 h-3 border border-[#1B1C1A] rounded-[1px] transition-colors ${
                    carouselIndex === idx ? 'bg-[#2563EB]' : 'bg-white hover:bg-[#EFEEEA]'
                  }`}
                  title={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      )
    },
    {
      category: 'info',
      title: '3. Informational Components (Badges, Feeds, Comments, Tooltips & Status Indicators)',
      code: `/* 1. Icon Notification Badges */
<div className="relative inline-block">
  <Bell className="w-5 h-5 text-[#1B1C1A]" />
  <span className="absolute -top-1 -right-1 bg-[#B7102A] text-white text-[9px] font-bold px-1 rounded-full">3</span>
</div>

/* 2. Feeds (Chronological Activity Stream) */
<div className="space-y-2 border-l-2 border-[#1B1C1A] pl-3">
  <div className="text-xs font-mono"><strong className="text-[#2563EB]">12:04 PM</strong> — Course brief updated</div>
</div>

/* 3. Chronological Comments Thread */
<div className="p-3 bg-white border border-[#1B1C1A] rounded-[2px] space-y-1">
  <div className="text-xs font-bold text-[#1B1C1A]">Prof. E. Vance <span className="text-gray-400 font-normal">2h ago</span></div>
  <p className="text-xs text-gray-700">Approved syllabus revision #8402.</p>
</div>`,
      render: (
        <div className="space-y-6">
          {/* Icon Badges Row */}
          <div className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] space-y-3">
            <div className="text-xs font-mono font-bold text-[#1B1C1A] uppercase">Icon Notification Badges & Counters</div>
            <div className="flex items-center gap-6">
              {/* Bell Notification Badge */}
              <div className="relative">
                <button className="p-2.5 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] hover:bg-[#EFEEEA]">
                  <Bell className="w-5 h-5 text-[#1B1C1A]" />
                </button>
                <span className="absolute -top-1.5 -right-1.5 bg-[#B7102A] text-white text-[10px] font-mono font-bold w-5 h-5 flex items-center justify-center rounded-full border border-white">
                  3
                </span>
              </div>

              {/* Message Badge */}
              <div className="relative">
                <button className="p-2.5 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] hover:bg-[#EFEEEA]">
                  <MessageSquare className="w-5 h-5 text-[#1B1C1A]" />
                </button>
                <span className="absolute -top-1.5 -right-1.5 bg-[#2563EB] text-white text-[10px] font-mono font-bold w-5 h-5 flex items-center justify-center rounded-full border border-white">
                  12
                </span>
              </div>

              {/* Activity Shield Badge */}
              <div className="relative">
                <button className="p-2.5 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] hover:bg-[#EFEEEA]">
                  <Shield className="w-5 h-5 text-[#059669]" />
                </button>
                <span className="absolute -top-1.5 -right-1.5 bg-[#059669] text-white text-[10px] font-mono font-bold px-1 py-0.2 rounded-[1px] border border-white">
                  OK
                </span>
              </div>
            </div>
          </div>

          {/* Feeds & Comments Dual Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Feeds: Chronological Activity Stream */}
            <div className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] space-y-3">
              <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-2">
                <h4 className="text-xs font-bold uppercase text-[#1B1C1A]">Chronological Activity Feed Stream</h4>
                <span className="text-[10px] font-mono text-gray-500">LIVE EVENTS</span>
              </div>

              <div className="space-y-3 pl-2 border-l-2 border-[#1B1C1A]">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2 text-xs font-mono">
                    <span className="px-1 bg-[#BFDBFE] text-[#1E40AF] font-bold text-[10px]">SYNC</span>
                    <span className="text-gray-500">12:04:18 PM</span>
                  </div>
                  <p className="text-xs font-bold text-[#1B1C1A]">Course Brief CS-402 exported to Markdown</p>
                </div>

                <div className="space-y-0.5">
                  <div className="flex items-center gap-2 text-xs font-mono">
                    <span className="px-1 bg-[#D1FAE5] text-[#065F46] font-bold text-[10px]">VERIFIED</span>
                    <span className="text-gray-500">11:42:00 AM</span>
                  </div>
                  <p className="text-xs font-bold text-[#1B1C1A]">Accreditation audit token issued (#8402)</p>
                </div>

                <div className="space-y-0.5">
                  <div className="flex items-center gap-2 text-xs font-mono">
                    <span className="px-1 bg-[#FEE2E2] text-[#B7102A] font-bold text-[10px]">WARN</span>
                    <span className="text-gray-500">10:15:30 AM</span>
                  </div>
                  <p className="text-xs font-bold text-[#1B1C1A]">Grade threshold exceeded in Lab 3 evaluation</p>
                </div>
              </div>
            </div>

            {/* Comments: Chronological User Feedback Thread */}
            <div className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] space-y-3">
              <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-2">
                <h4 className="text-xs font-bold uppercase text-[#1B1C1A]">Comments & Feedback Thread</h4>
                <span className="text-[10px] font-mono text-gray-500">2 COMMENTS</span>
              </div>

              <div className="space-y-3">
                <div className="p-3 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] space-y-1">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <div className="flex items-center gap-1.5 font-bold text-[#1B1C1A]">
                      <span className="w-5 h-5 bg-[#2563EB] text-white flex items-center justify-center text-[10px] rounded-full">EV</span>
                      <span>Prof. E. Vance</span>
                    </div>
                    <span className="text-gray-400">2 hours ago</span>
                  </div>
                  <p className="text-xs text-gray-700 leading-relaxed font-sans">
                    "Please double check the weight allocation on Assignment 2 before finalizing the accreditation export."
                  </p>
                </div>

                <div className="p-3 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] space-y-1">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <div className="flex items-center gap-1.5 font-bold text-[#1B1C1A]">
                      <span className="w-5 h-5 bg-[#059669] text-white flex items-center justify-center text-[10px] rounded-full">AM</span>
                      <span>Alex Mercer</span>
                    </div>
                    <span className="text-gray-400">45 mins ago</span>
                  </div>
                  <p className="text-xs text-gray-700 leading-relaxed font-sans">
                    "Lab reports updated to reflect 25% course credit. All peer reviews completed."
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      category: 'animations',
      title: 'Stepped Mechanical Loading Animations & Progress Meters',
      code: `/* 1. Discrete 8-Tick Mechanical Spinner */
<Loader2 className="w-5 h-5 text-[#2563EB] animate-stepped-spin" />

/* 2. Stepped Progress Meter (Segment Block) */
<div className="w-full bg-[#EFEEEA] border border-[#1B1C1A] h-5 rounded-[2px] p-0.5 flex gap-0.5">
  <div className="h-full w-1/4 bg-[#2563EB]" />
  <div className="h-full w-1/4 bg-[#2563EB]" />
  <div className="h-full w-1/4 bg-gray-300 animate-pulse" />
</div>`,
      render: (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* 8-Tick Stepped Spinner */}
            <div className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase text-[#1B1C1A]">8-Tick Mechanical Spinner</span>
                <span className="text-xs font-mono text-gray-500">DISCRETE STEPS(1)</span>
              </div>
              <div className="flex items-center gap-3 pt-1">
                <div className="w-9 h-9 bg-[#EFEEEA] border border-[#1B1C1A] flex items-center justify-center rounded-[2px]">
                  <Loader2 className="w-5 h-5 text-[#2563EB] animate-stepped-spin" />
                </div>
                <div className="w-9 h-9 bg-[#1B1C1A] border border-[#1B1C1A] flex items-center justify-center rounded-[2px]">
                  <RefreshCw className="w-5 h-5 text-[#FEF08A] animate-stepped-spin" />
                </div>
                <div className="w-9 h-9 bg-[#B7102A] border border-[#1B1C1A] flex items-center justify-center rounded-[2px]">
                  <Settings className="w-5 h-5 text-white animate-stepped-spin" />
                </div>
                <span className="text-xs font-mono text-gray-600">Simulating hardware gear rotation</span>
              </div>
            </div>

            {/* Segmented Stepped Progress Bar */}
            <div className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase text-[#1B1C1A]">Stepped Segment Progress Bar</span>
                <span className="text-xs font-mono font-bold text-[#059669]">75% COMPLETED</span>
              </div>
              <div className="w-full bg-[#EFEEEA] border border-[#1B1C1A] h-5 rounded-[2px] p-0.5 flex gap-0.5">
                <div className="h-full w-1/4 bg-[#2563EB]" />
                <div className="h-full w-1/4 bg-[#2563EB]" />
                <div className="h-full w-1/4 bg-[#2563EB]" />
                <div className="h-full w-1/4 bg-gray-300 animate-pulse" />
              </div>
              <div className="text-xs font-mono text-gray-500 flex justify-between pt-0.5">
                <span>SEGMENT 03/04</span>
                <span>BAUHAUS GRID METRIC</span>
              </div>
            </div>
          </div>

          {/* Stepped Status Dots & Accordion */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white border border-[#1B1C1A] p-3 rounded-[2px] flex items-center gap-3">
              <span className="w-3 h-3 rounded-full bg-[#059669] border border-[#1B1C1A] animate-pulse shrink-0" />
              <div>
                <div className="text-xs font-bold uppercase text-[#1B1C1A]">SYSTEM ONLINE</div>
                <div className="text-xs font-mono text-gray-500">Continuous pulse dot</div>
              </div>
            </div>

            <div className="bg-white border border-[#1B1C1A] p-3 rounded-[2px] flex items-center gap-3">
              <span className="w-3 h-3 rounded-full bg-[#B7102A] border border-[#1B1C1A] animate-ping shrink-0" />
              <div>
                <div className="text-xs font-bold uppercase text-[#1B1C1A]">ALERT BEACON</div>
                <div className="text-xs font-mono text-gray-500">Acoustic beacon pulse</div>
              </div>
            </div>

            <div className="bg-white border border-[#1B1C1A] p-3 rounded-[2px] flex items-center gap-3">
              <span className="w-3 h-3 rounded-full bg-[#2563EB] border border-[#1B1C1A] shrink-0" />
              <div>
                <div className="text-xs font-bold uppercase text-[#1B1C1A]">STANDBY MODE</div>
                <div className="text-xs font-mono text-gray-500">Solid state light</div>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      category: 'icons',
      title: 'Utility Glyphs, Trash & Settings Actions',
      code: `/* Trash Action Button */
<button className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#FEE2E2] hover:text-[#B7102A]">
  <Trash2 className="w-4 h-4" />
</button>

/* Settings Gear Button */
<button className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#EFEEEA] group">
  <Settings className="w-4 h-4 group-hover:rotate-90 transition-transform duration-200" />
</button>`,
      render: (
        <div className="space-y-6">
          {/* Action Glyphs Row */}
          <div>
            <div className="text-xs font-mono text-gray-500 uppercase mb-2">Interactive Action Glyphs (1px Hairline Frames)</div>
            <div className="flex flex-wrap items-center gap-3">
              {/* Trash */}
              <button title="Delete Item" className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#FEE2E2] hover:text-[#B7102A] active:translate-y-[1px] transition-all">
                <Trash2 className="w-4 h-4" />
              </button>

              {/* Settings */}
              <button title="Settings" className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#EFEEEA] active:translate-y-[1px] transition-all group">
                <Settings className="w-4 h-4 group-hover:rotate-90 transition-transform duration-200" />
              </button>

              {/* Edit */}
              <button title="Edit" className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#DBEAFE] hover:text-[#2563EB] active:translate-y-[1px] transition-all">
                <Edit3 className="w-4 h-4" />
              </button>

              {/* Filter */}
              <button title="Filter" className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#EFEEEA] active:translate-y-[1px] transition-all">
                <Filter className="w-4 h-4" />
              </button>

              {/* Download */}
              <button title="Export Data" className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#D1FAE5] hover:text-[#059669] active:translate-y-[1px] transition-all">
                <Download className="w-4 h-4" />
              </button>

              {/* Refresh */}
              <button title="Refresh" className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#EFEEEA] active:translate-y-[1px] transition-all group">
                <RefreshCw className="w-4 h-4 group-hover:rotate-180 transition-transform duration-300" />
              </button>

              {/* Lock / Unlock */}
              <button title="Lock Panel" className="w-9 h-9 bg-[#1B1C1A] text-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] hover:bg-black active:translate-y-[1px] transition-all">
                <Lock className="w-4 h-4" />
              </button>

              {/* External Link */}
              <button title="External Link" className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#EFEEEA] active:translate-y-[1px] transition-all">
                <ExternalLink className="w-4 h-4" />
              </button>

              {/* Pin */}
              <button title="Pin Item" className="w-9 h-9 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px] text-[#1B1C1A] hover:bg-[#FEF08A] active:translate-y-[1px] transition-all">
                <Pin className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Icon Badge Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-2.5 bg-white border border-[#1B1C1A] rounded-[2px] flex items-center gap-2.5">
              <div className="w-7 h-7 bg-[#FEE2E2] border border-[#1B1C1A] flex items-center justify-center rounded-[2px] shrink-0">
                <Trash2 className="w-3.5 h-3.5 text-[#B7102A]" />
              </div>
              <div>
                <div className="text-xs font-bold text-[#1B1C1A]">DELETE ITEM</div>
                <div className="text-xs font-mono text-gray-500">Destructive glyph</div>
              </div>
            </div>

            <div className="p-2.5 bg-white border border-[#1B1C1A] rounded-[2px] flex items-center gap-2.5">
              <div className="w-7 h-7 bg-[#EFEEEA] border border-[#1B1C1A] flex items-center justify-center rounded-[2px] shrink-0">
                <Settings className="w-3.5 h-3.5 text-[#1B1C1A]" />
              </div>
              <div>
                <div className="text-xs font-bold text-[#1B1C1A]">SETTINGS GEAR</div>
                <div className="text-xs font-mono text-gray-500">System config</div>
              </div>
            </div>

            <div className="p-2.5 bg-white border border-[#1B1C1A] rounded-[2px] flex items-center gap-2.5">
              <div className="w-7 h-7 bg-[#DBEAFE] border border-[#1B1C1A] flex items-center justify-center rounded-[2px] shrink-0">
                <Tag className="w-3.5 h-3.5 text-[#2563EB]" />
              </div>
              <div>
                <div className="text-xs font-bold text-[#1B1C1A]">TAG CATEGORY</div>
                <div className="text-xs font-mono text-gray-500">Metadata taxonomy</div>
              </div>
            </div>

            <div className="p-2.5 bg-white border border-[#1B1C1A] rounded-[2px] flex items-center gap-2.5">
              <div className="w-7 h-7 bg-[#F3E8FF] border border-[#1B1C1A] flex items-center justify-center rounded-[2px] shrink-0">
                <Folder className="w-3.5 h-3.5 text-[#7C3AED]" />
              </div>
              <div>
                <div className="text-xs font-bold text-[#1B1C1A]">FILE DIRECTORY</div>
                <div className="text-xs font-mono text-gray-500">Archive folder</div>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      category: 'all',
      title: 'Module Cards with 4px Top Accent Borders',
      code: `<div className="bg-white border border-[#1B1C1A] border-t-4 border-t-[#2563eb] p-4 rounded-[2px]">
  <h3 className="text-sm font-bold text-[#1B1C1A] uppercase">Assignments</h3>
  <p className="text-xs text-gray-600 mt-1">1px frame, zero shadow, top accent color.</p>
</div>`,
      render: (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white border border-[#1B1C1A] border-t-4 border-t-[#2563eb] p-4 rounded-[2px]">
            <h3 className="text-sm font-bold text-[#1B1C1A] uppercase">Assignments</h3>
            <p className="text-xs text-gray-600 mt-1">Blue module top accent strip.</p>
          </div>

          <div className="bg-white border border-[#1B1C1A] border-t-4 border-t-[#059669] p-4 rounded-[2px]">
            <h3 className="text-sm font-bold text-[#1B1C1A] uppercase">Grading</h3>
            <p className="text-xs text-gray-600 mt-1">Green module top accent strip.</p>
          </div>

          <div className="bg-white border border-[#1B1C1A] border-t-4 border-t-[#7c3aed] p-4 rounded-[2px]">
            <h3 className="text-sm font-bold text-[#1B1C1A] uppercase">Communication</h3>
            <p className="text-xs text-gray-600 mt-1">Purple module top accent strip.</p>
          </div>
        </div>
      )
    },
    {
      category: 'tables',
      title: '5. Data Table Format (Bauhaus Windows 98 Grid Data Table)',
      code: `/* Lightweight Bauhaus Data Table Format Specs:
 - Container: 1px border (#1B1C1A), bg-white, rounded-[2px], shadow-none
 - Toolbar Header: bg-[#EFEEEA] with search, filters, density toggles & action buttons
 - Column Headers: bg-[#FAF9F5], 1px right dividers (#E3E2DF), uppercase tracking-wider text
 - Rows: Hover bg-[#FAF9F5], 1px bottom dividers (#E3E2DF), 4px domain accent indicators
 - Status Cells: High-contrast 1px border badges with explicit status fills
 - Footer Pagination: bg-[#EFEEEA] with stepped pagination buttons [◄ PREV] [1] [2] [NEXT ►]
*/
<div className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden shadow-none">
  {/* Header Controls */}
  <div className="bg-[#EFEEEA] border-b border-[#1B1C1A] p-3 flex flex-wrap items-center justify-between gap-2 font-mono text-xs">
    <div className="flex items-center gap-2">
      <div className="relative">
        <Search className="w-3.5 h-3.5 text-gray-500 absolute left-2.5 top-2" />
        <input type="text" placeholder="SEARCH RECORDS..." className="bg-white border border-[#1B1C1A] pl-8 pr-2 py-1 text-xs outline-none focus:ring-1 focus:ring-[#2563EB]" />
      </div>
      <span className="text-gray-400">|</span>
      <span className="font-bold text-[#1B1C1A] uppercase">5 RECORDS TOTAL</span>
    </div>
    <div className="flex items-center gap-2">
      <button className="px-2.5 py-1 bg-white border border-[#1B1C1A] font-bold uppercase hover:bg-[#FAF9F5]">FILTER</button>
      <button className="px-2.5 py-1 bg-[#1B1C1A] text-white font-bold uppercase hover:bg-black">+ NEW ROW</button>
    </div>
  </div>

  {/* Structured Data Grid */}
  <div className="overflow-x-auto">
    <table className="w-full text-left font-mono text-xs border-collapse">
      <thead className="bg-[#FAF9F5] border-b border-[#1B1C1A]">
        <tr>
          <th className="py-2.5 px-3 border-r border-[#E3E2DF] font-bold uppercase">RECORD ID</th>
          <th className="py-2.5 px-3 border-r border-[#E3E2DF] font-bold uppercase">ASSIGNMENT TITLE</th>
          <th className="py-2.5 px-3 border-r border-[#E3E2DF] font-bold uppercase">STUDENT</th>
          <th className="py-2.5 px-3 border-r border-[#E3E2DF] font-bold uppercase text-right">SCORE</th>
          <th className="py-2.5 px-3 border-r border-[#E3E2DF] font-bold uppercase">STATUS</th>
          <th className="py-2.5 px-3 font-bold uppercase text-center">ACTIONS</th>
        </tr>
      </thead>
      <tbody>
        <tr className="border-b border-[#E3E2DF] hover:bg-[#FAF9F5]">
          <td className="py-2.5 px-3 border-r border-[#E3E2DF] font-bold text-[#2563EB]">
            <span className="inline-block w-1.5 h-3 bg-[#2563EB] mr-1.5 align-middle"></span>
            SUB-101
          </td>
          <td className="py-2.5 px-3 border-r border-[#E3E2DF] font-medium text-[#1B1C1A]">Constructivist Composition Analysis</td>
          <td className="py-2.5 px-3 border-r border-[#E3E2DF]">Lukas Webber</td>
          <td className="py-2.5 px-3 border-r border-[#E3E2DF] text-right font-bold">98 / 100</td>
          <td className="py-2.5 px-3 border-r border-[#E3E2DF]">
            <span className="px-2 py-0.5 bg-[#CCFBF1] text-[#0F766E] border border-[#1B1C1A] text-[10px] font-bold uppercase rounded-[1px]">Graded</span>
          </td>
          <td className="py-2.5 px-3 text-center">
            <button className="px-2 py-0.5 bg-white border border-[#1B1C1A] text-[10px] font-bold uppercase hover:bg-[#EFEEEA]">EDIT</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>`,
      render: (
        <div className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden shadow-none space-y-0">
          {/* Top Table Control Bar */}
          <div className="bg-[#EFEEEA] border-b border-[#1B1C1A] p-3 flex flex-wrap items-center justify-between gap-3 font-mono text-xs">
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-gray-500 absolute left-2.5 top-2" />
                <input
                  type="text"
                  value={tableSearch}
                  onChange={(e) => setTableSearch(e.target.value)}
                  placeholder="FILTER BY TITLE OR ID..."
                  className="bg-white border border-[#1B1C1A] pl-8 pr-3 py-1 text-xs font-mono rounded-[2px] outline-none focus:ring-1 focus:ring-[#2563EB] w-48 sm:w-64"
                />
              </div>

              {/* Status Filter Dropdown Pill */}
              <div className="flex items-center gap-1 bg-white border border-[#1B1C1A] px-2 py-1 rounded-[2px]">
                <Filter className="w-3 h-3 text-gray-600" />
                <select
                  value={tableFilterStatus}
                  onChange={(e) => setTableFilterStatus(e.target.value)}
                  className="bg-transparent text-xs font-mono font-bold text-[#1B1C1A] outline-none cursor-pointer uppercase"
                >
                  <option value="all">ALL STATUSES</option>
                  <option value="Graded">GRADED</option>
                  <option value="In Review">IN REVIEW</option>
                  <option value="Pending">PENDING</option>
                </select>
              </div>

              {/* Density Toggle */}
              <button
                onClick={() => setTableDensity(tableDensity === 'comfortable' ? 'compact' : 'comfortable')}
                className="px-2.5 py-1 bg-white border border-[#1B1C1A] text-xs font-mono font-bold uppercase rounded-[2px] hover:bg-[#FAF9F5] flex items-center gap-1"
                title="Toggle Compact / Comfortable Density"
              >
                <SlidersHorizontal className="w-3 h-3 text-[#1B1C1A]" />
                <span>{tableDensity.toUpperCase()} DENSITY</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-gray-600 bg-white border border-[#1B1C1A] px-2 py-1 rounded-[2px]">
                {tableSelectedRows.length} SELECTED
              </span>
              <button className="px-3 py-1 bg-[#1B1C1A] text-white border border-[#1B1C1A] text-xs font-mono font-bold uppercase rounded-[2px] hover:bg-black transition-colors flex items-center gap-1">
                <Plus className="w-3.5 h-3.5" />
                <span>NEW RECORD</span>
              </button>
            </div>
          </div>

          {/* Interactive Data Table Grid */}
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs border-collapse">
              <thead className="bg-[#FAF9F5] border-b border-[#1B1C1A]">
                <tr>
                  <th className="py-2.5 px-3 border-r border-[#E3E2DF] w-10 text-center">
                    <input
                      type="checkbox"
                      checked={tableSelectedRows.length === 5}
                      onChange={() => {
                        if (tableSelectedRows.length === 5) setTableSelectedRows([]);
                        else setTableSelectedRows(['SUB-101', 'SUB-102', 'SUB-103', 'SUB-104', 'SUB-105']);
                      }}
                      className="accent-[#B7102A] cursor-pointer rounded-[0px]"
                    />
                  </th>
                  <th
                    onClick={() => {
                      if (tableSortCol === 'id') setTableSortAsc(!tableSortAsc);
                      else { setTableSortCol('id'); setTableSortAsc(true); }
                    }}
                    className="py-2.5 px-3 border-r border-[#E3E2DF] font-bold text-[#1B1C1A] uppercase tracking-wider cursor-pointer hover:bg-[#EFEEEA] transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span>RECORD ID</span>
                      <ArrowUpDown className="w-3 h-3 text-gray-500" />
                    </div>
                  </th>
                  <th
                    onClick={() => {
                      if (tableSortCol === 'title') setTableSortAsc(!tableSortAsc);
                      else { setTableSortCol('title'); setTableSortAsc(true); }
                    }}
                    className="py-2.5 px-3 border-r border-[#E3E2DF] font-bold text-[#1B1C1A] uppercase tracking-wider cursor-pointer hover:bg-[#EFEEEA] transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span>ASSIGNMENT TITLE</span>
                      <ArrowUpDown className="w-3 h-3 text-gray-500" />
                    </div>
                  </th>
                  <th className="py-2.5 px-3 border-r border-[#E3E2DF] font-bold text-[#1B1C1A] uppercase tracking-wider">
                    STUDENT NAME
                  </th>
                  <th
                    onClick={() => {
                      if (tableSortCol === 'score') setTableSortAsc(!tableSortAsc);
                      else { setTableSortCol('score'); setTableSortAsc(true); }
                    }}
                    className="py-2.5 px-3 border-r border-[#E3E2DF] font-bold text-[#1B1C1A] uppercase tracking-wider text-right cursor-pointer hover:bg-[#EFEEEA] transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>SCORE</span>
                      <ArrowUpDown className="w-3 h-3 text-gray-500" />
                    </div>
                  </th>
                  <th className="py-2.5 px-3 border-r border-[#E3E2DF] font-bold text-[#1B1C1A] uppercase tracking-wider">
                    STATUS & MODULE
                  </th>
                  <th className="py-2.5 px-3 font-bold text-[#1B1C1A] uppercase tracking-wider text-center w-24">
                    ACTIONS
                  </th>
                </tr>
              </thead>
              <tbody>
                {[
                  { id: 'SUB-101', title: 'Constructivist Composition Analysis', student: 'Lukas Webber', score: 98, status: 'Graded', category: 'Assignments', color: '#2563EB' },
                  { id: 'SUB-102', title: 'Bauhaus Spatial Geometry Project', student: 'Elena Rostova', score: 92, status: 'Graded', category: 'Assignments', color: '#2563EB' },
                  { id: 'SUB-103', title: 'Asymmetric Grid & Type Systems', student: 'Marcus Vance', score: 85, status: 'In Review', category: 'Grading', color: '#059669' },
                  { id: 'SUB-104', title: 'Primary Color Contrast Study', student: 'Sophia Chen', score: 78, status: 'Pending', category: 'Setup', color: '#334155' },
                  { id: 'SUB-105', title: 'Modular Windows 98 Form Spec', student: 'David Thorne', score: 95, status: 'Graded', category: 'Content', color: '#0D9488' }
                ]
                  .filter(row => {
                    if (tableFilterStatus !== 'all' && row.status !== tableFilterStatus) return false;
                    if (tableSearch && !row.title.toLowerCase().includes(tableSearch.toLowerCase()) && !row.id.toLowerCase().includes(tableSearch.toLowerCase())) return false;
                    return true;
                  })
                  .map((row) => {
                    const isSelected = tableSelectedRows.includes(row.id);
                    const pyClass = tableDensity === 'compact' ? 'py-1.5' : 'py-3';
                    return (
                      <tr
                        key={row.id}
                        className={`border-b border-[#E3E2DF] last:border-b-0 transition-colors ${
                          isSelected ? 'bg-[#FEF08A]/30' : 'hover:bg-[#FAF9F5]'
                        }`}
                      >
                        <td className={`${pyClass} px-3 border-r border-[#E3E2DF] text-center`}>
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => {
                              if (isSelected) setTableSelectedRows(tableSelectedRows.filter(id => id !== row.id));
                              else setTableSelectedRows([...tableSelectedRows, row.id]);
                            }}
                            className="accent-[#B7102A] cursor-pointer rounded-[0px]"
                          />
                        </td>
                        <td className={`${pyClass} px-3 border-r border-[#E3E2DF] font-bold text-[#2563EB]`}>
                          <span
                            className="inline-block w-1.5 h-3.5 mr-2 align-middle"
                            style={{ backgroundColor: row.color }}
                          ></span>
                          {row.id}
                        </td>
                        <td className={`${pyClass} px-3 border-r border-[#E3E2DF] font-medium text-[#1B1C1A]`}>
                          <div>{row.title}</div>
                          <div className="text-[10px] text-gray-500 uppercase">{row.category} Module</div>
                        </td>
                        <td className={`${pyClass} px-3 border-r border-[#E3E2DF] text-gray-700`}>
                          {row.student}
                        </td>
                        <td className={`${pyClass} px-3 border-r border-[#E3E2DF] text-right font-bold font-mono text-[#1B1C1A]`}>
                          {row.score} / 100
                        </td>
                        <td className={`${pyClass} px-3 border-r border-[#E3E2DF]`}>
                          {row.status === 'Graded' && (
                            <span className="px-2 py-0.5 bg-[#CCFBF1] text-[#0F766E] border border-[#1B1C1A] text-[10px] font-bold uppercase rounded-[1px]">
                              GRADED
                            </span>
                          )}
                          {row.status === 'In Review' && (
                            <span className="px-2 py-0.5 bg-[#FEF08A] text-[#7A5500] border border-[#1B1C1A] text-[10px] font-bold uppercase rounded-[1px]">
                              IN REVIEW
                            </span>
                          )}
                          {row.status === 'Pending' && (
                            <span className="px-2 py-0.5 bg-[#EFEEEA] text-gray-700 border border-[#1B1C1A] text-[10px] font-bold uppercase rounded-[1px]">
                              PENDING
                            </span>
                          )}
                        </td>
                        <td className={`${pyClass} px-3 text-center`}>
                          <div className="flex items-center justify-center gap-1">
                            <button
                              title="Edit Record"
                              className="px-2 py-0.5 bg-white border border-[#1B1C1A] text-[10px] font-bold uppercase hover:bg-[#1B1C1A] hover:text-white transition-colors"
                            >
                              EDIT
                            </button>
                            <button
                              title="More Options"
                              className="p-1 bg-white border border-[#1B1C1A] text-[#1B1C1A] hover:bg-[#EFEEEA]"
                            >
                              <MoreHorizontal className="w-3 h-3" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>

          {/* Table Stepped Pagination Footer */}
          <div className="bg-[#EFEEEA] border-t border-[#1B1C1A] p-3 flex flex-wrap items-center justify-between gap-3 font-mono text-xs">
            <div className="flex items-center gap-2">
              <span className="font-bold text-[#1B1C1A] uppercase">SHOWING 1-5 OF 24 RECORDS</span>
              <span className="text-gray-400">|</span>
              <span className="text-gray-600">PAGE 1 OF 5</span>
            </div>

            <div className="flex items-center gap-1">
              <button
                disabled={tablePage === 1}
                onClick={() => setTablePage(Math.max(1, tablePage - 1))}
                className="px-2.5 py-1 bg-white border border-[#1B1C1A] font-bold uppercase hover:bg-[#FAF9F5] disabled:opacity-50 disabled:cursor-not-allowed rounded-[2px]"
              >
                ◄ PREV
              </button>
              <button
                onClick={() => setTablePage(1)}
                className={`px-3 py-1 border border-[#1B1C1A] font-bold rounded-[2px] ${
                  tablePage === 1 ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
                }`}
              >
                1
              </button>
              <button
                onClick={() => setTablePage(2)}
                className={`px-3 py-1 border border-[#1B1C1A] font-bold rounded-[2px] ${
                  tablePage === 2 ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
                }`}
              >
                2
              </button>
              <button
                onClick={() => setTablePage(3)}
                className={`px-3 py-1 border border-[#1B1C1A] font-bold rounded-[2px] ${
                  tablePage === 3 ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
                }`}
              >
                3
              </button>
              <button
                disabled={tablePage === 5}
                onClick={() => setTablePage(Math.min(5, tablePage + 1))}
                className="px-2.5 py-1 bg-white border border-[#1B1C1A] font-bold uppercase hover:bg-[#FAF9F5] disabled:opacity-50 disabled:cursor-not-allowed rounded-[2px]"
              >
                NEXT ►
              </button>
            </div>
          </div>
        </div>
      )
    },
    {
      category: 'all',
      title: 'Badges & Status Tags',
      code: `<span className="px-2.5 py-1 bg-[#BFDBFE] text-[#1E40AF] border border-[#1B1C1A] text-[10px] font-bold uppercase rounded-[2px]">
  ADVANCED PHYSICS
</span>`,
      render: (
        <div className="flex flex-wrap items-center gap-3">
          <span className="px-2.5 py-1 bg-[#BFDBFE] text-[#1E40AF] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]">
            ADVANCED PHYSICS
          </span>
          <span className="px-2.5 py-1 bg-[#FEF08A] text-[#7A5500] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]">
            INTRO TO BAUHAUS
          </span>
          <span className="px-2.5 py-1 bg-[#CCFBF1] text-[#0F766E] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]">
            PUBLISHED
          </span>
          <span className="px-2.5 py-1 bg-[#FEE2E2] text-[#B7102A] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]">
            ! NEEDS REVIEW
          </span>
        </div>
      )
    }
  ];

  const filteredComponents = componentsList.filter(item => {
    if (activeTab === 'all') return true;
    if (activeTab === 'inputs') return item.category === 'inputs' || item.category === 'forms' || item.category === 'buttons';
    if (activeTab === 'nav') return item.category === 'nav' || item.category === 'navigation';
    if (activeTab === 'info') return item.category === 'info' || item.category === 'toasts' || item.category === 'tooltips' || item.category === 'animations' || item.category === 'icons';
    if (activeTab === 'containers') return item.category === 'containers' || item.category === 'modals' || item.category === 'tables';
    if (activeTab === 'tables') return item.category === 'tables';
    return item.category === activeTab;
  });

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-[#1B1C1A] pb-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl sm:text-4xl font-black text-[#1B1C1A] tracking-tight uppercase">
              Component Sandbox
            </h1>
            <p className="text-xs text-gray-600 mt-1">
              Full UI component taxonomy: Input Controls, Navigational Components, Informational Feeds/Comments, Containers, and Data Tables in 1px Bauhaus design.
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="inline-flex p-1 bg-[#EFEEEA] border border-[#1B1C1A] rounded-[2px] flex-wrap gap-1">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all ${
                activeTab === 'all' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
              }`}
            >
              ALL
            </button>
            <button
              onClick={() => setActiveTab('inputs')}
              className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all ${
                activeTab === 'inputs' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
              }`}
            >
              1. INPUT CONTROLS
            </button>
            <button
              onClick={() => setActiveTab('nav')}
              className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all ${
                activeTab === 'nav' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
              }`}
            >
              2. NAVIGATION
            </button>
            <button
              onClick={() => setActiveTab('info')}
              className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all ${
                activeTab === 'info' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
              }`}
            >
              3. INFORMATIONAL
            </button>
            <button
              onClick={() => setActiveTab('containers')}
              className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all ${
                activeTab === 'containers' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
              }`}
            >
              4. CONTAINERS
            </button>
            <button
              onClick={() => setActiveTab('tables')}
              className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all ${
                activeTab === 'tables' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
              }`}
            >
              5. DATA TABLES
            </button>
            <button
              onClick={() => setActiveTab('buttons')}
              className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all ${
                activeTab === 'buttons' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
              }`}
            >
              BUTTONS
            </button>
            <button
              onClick={() => setActiveTab('typography')}
              className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all flex items-center gap-1 ${
                activeTab === 'typography' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
              }`}
            >
              <Type className="w-3.5 h-3.5" />
              <span>TYPOGRAPHY</span>
            </button>
            <button
              onClick={() => setActiveTab('modals')}
              className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all ${
                activeTab === 'modals' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
              }`}
            >
              MODALS
            </button>
            <button
              onClick={() => setActiveTab('toasts')}
              className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all ${
                activeTab === 'toasts' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
              }`}
            >
              TOASTS
            </button>
          </div>
        </div>
      </div>

      {/* Components List */}
      <div className="space-y-6">
        {filteredComponents.map((comp, idx) => (
          <div
            key={idx}
            className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden"
          >
            {/* Header */}
            <div className="bg-[#EFEEEA] border-b border-[#1B1C1A] px-4 py-2.5 flex items-center justify-between">
              <h3 className="text-xs font-bold text-[#1B1C1A] uppercase tracking-wider">
                {comp.title}
              </h3>
              <button
                onClick={() => copyCode(comp.code, idx)}
                className="flex items-center gap-1 text-xs font-bold uppercase px-2 py-1 bg-white border border-[#1B1C1A] rounded-[2px] hover:bg-[#FAF9F5]"
              >
                {copiedIndex === idx ? (
                  <>
                    <Check className="w-3 h-3 text-[#059669]" />
                    <span>COPIED</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3 text-gray-500" />
                    <span>COPY CODE</span>
                  </>
                )}
              </button>
            </div>

            {/* Live Render Area */}
            <div className="p-6 bg-[#FAF9F5] border-b border-[#1B1C1A]">
              {comp.render}
            </div>

            {/* Code Snippet Box */}
            <pre className="p-4 bg-[#1B1C1A] text-white font-mono text-xs overflow-x-auto leading-relaxed">
              <code>{comp.code}</code>
            </pre>
          </div>
        ))}
      </div>
    </div>
  );
};

