import React, { useState } from 'react';
import { COLOR_TOKENS, TYPOGRAPHY_TOKENS, DESIGN_PRINCIPLES, BORDER_SPECIFICATIONS, SYSTEM_META } from '../../data/designBriefData';
import { Copy, Check, ShieldAlert, Sparkles, Box, Layout, Layers, ShieldCheck } from 'lucide-react';

export const DesignBriefOverview: React.FC = () => {
  const [copiedHex, setCopiedHex] = useState<string | null>(null);

  const copyToClipboard = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 2000);
  };

  return (
    <div className="space-y-10 animate-fadeIn">
      {/* Hero Header */}
      <div className="bg-[#FAF9F5] border-2 border-[#1B1C1A] p-6 sm:p-8 rounded-[2px] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#B7102A]/10 border-l border-b border-[#1B1C1A] pointer-events-none hidden sm:block" />

        <div className="inline-block px-2.5 py-1 bg-[#1B1C1A] text-white text-xs font-mono font-bold tracking-widest uppercase mb-4">
          OFFICIAL SYSTEM DESIGN BRIEF // {SYSTEM_META.version}
        </div>

        <h1 className="text-4xl sm:text-6xl font-black text-[#1B1C1A] tracking-tight uppercase leading-none">
          {SYSTEM_META.title}
        </h1>

        <p className="text-sm sm:text-base font-bold text-[#B7102A] mt-2 font-mono uppercase tracking-wide">
          {SYSTEM_META.subtitle}
        </p>

        <p className="text-xs sm:text-sm text-gray-700 leading-relaxed mt-4 max-w-3xl">
          {SYSTEM_META.description}
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-[#1B1C1A]">
          <div>
            <div className="text-xs font-mono text-gray-500 uppercase">ARCHETYPE</div>
            <div className="text-xs font-bold text-[#1B1C1A]">B4 Crisp Grid</div>
          </div>
          <div>
            <div className="text-xs font-mono text-gray-500 uppercase">BORDER RULE</div>
            <div className="text-xs font-bold text-[#1B1C1A]">1px Solid #1B1C1A</div>
          </div>
          <div>
            <div className="text-xs font-mono text-gray-500 uppercase">SHADOW RULE</div>
            <div className="text-xs font-bold text-[#B7102A]">STRICTLY NONE</div>
          </div>
          <div>
            <div className="text-xs font-mono text-gray-500 uppercase">TYPOGRAPHY</div>
            <div className="text-xs font-bold text-[#1B1C1A]">Inter (Tracked Caps)</div>
          </div>
        </div>
      </div>

      {/* 5 Core Principles Cards */}
      <div>
        <div className="flex items-center gap-2 mb-4 border-b border-[#1B1C1A] pb-2">
          <Sparkles className="w-5 h-5 text-[#B7102A]" />
          <h2 className="text-xl font-extrabold text-[#1B1C1A] uppercase tracking-tight">
            I. Core Architectural Principles
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {DESIGN_PRINCIPLES.map((principle) => (
            <div
              key={principle.number}
              className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] flex flex-col justify-between"
            >
              <div>
                <span className="text-2xl font-black text-[#B7102A] font-mono block mb-2">
                  {principle.number}
                </span>
                <h3 className="text-sm font-bold text-[#1B1C1A] mb-2 uppercase leading-tight">
                  {principle.title}
                </h3>
                <p className="text-xs text-gray-600 leading-relaxed font-normal">
                  {principle.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Border & Geometry Deep Dive (Windows 98 x Bauhaus comparison) */}
      <div className="bg-white border border-[#1B1C1A] p-6 rounded-[2px] space-y-6">
        <div className="flex items-center gap-2 border-b border-[#1B1C1A] pb-3">
          <Layers className="w-5 h-5 text-[#2563EB]" />
          <h2 className="text-xl font-extrabold text-[#1B1C1A] uppercase tracking-tight">
            II. Border & Geometry Specification (Windows 98 Bauhaus Model)
          </h2>
        </div>

        <p className="text-xs text-gray-700 leading-relaxed max-w-4xl">
          Unlike modern SaaS apps that rely on diffuse drop shadows and soft gradients to imply surface depth, the <b>Lightweight Bauhaus</b> system uses crisp 1px solid boundaries (`#1B1C1A`), 0px-2px squared corners, and bold color accents along top/left boundaries.
        </p>

        {/* Visual Live Comparison: Anti-Pattern (Shadows) vs Compliant (Bauhaus Squared) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          {/* Forbidden Pattern */}
          <div className="border border-red-300 bg-red-50/50 p-5 rounded-lg space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-red-600 uppercase font-mono">
              <ShieldAlert className="w-4 h-4" />
              <span>❌ BANNED AI-SLOP PATTERN (DIFFUSE SHADOWS & ROUNDED SOFTNESS)</span>
            </div>
            <div className="bg-white p-4 rounded-xl shadow-xl border border-gray-200">
              <div className="h-2 w-16 bg-blue-500 rounded-full mb-2" />
              <div className="text-sm font-semibold text-gray-800">Soft Floating Card</div>
              <div className="text-xs text-gray-400 mt-1">
                Uses box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 12px rounded corners. Banned in this design system.
              </div>
            </div>
          </div>

          {/* Compliant Bauhaus Squared */}
          <div className="border-2 border-[#1B1C1A] bg-[#FAF9F5] p-5 rounded-[2px] space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-[#059669] uppercase font-mono">
              <ShieldCheck className="w-4 h-4" />
              <span>✓ APPROVED COMPLIANT BAUHAUS SQUARED (1PX BORDER, ZERO SHADOW)</span>
            </div>
            <div className="bg-white border border-[#1B1C1A] border-t-4 border-t-[#2563eb] p-4 rounded-[2px] shadow-none">
              <div className="text-sm font-bold text-[#1B1C1A] uppercase tracking-tight">
                Squared Grid Container
              </div>
              <div className="text-xs text-gray-600 mt-1 leading-relaxed">
                1px stroke `#1B1C1A`, 4px solid top strip, box-shadow: NONE, 2px corner radius.
              </div>
            </div>
          </div>
        </div>

        {/* Spec Table */}
        <div className="border border-[#1B1C1A] rounded-[2px] overflow-hidden text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#EFEEEA] border-b border-[#1B1C1A] font-bold text-[#1B1C1A] uppercase">
                <th className="py-2.5 px-4 border-r border-[#1B1C1A]">ELEMENT TYPE</th>
                <th className="py-2.5 px-4 border-r border-[#1B1C1A]">BORDER SPECIFICATION</th>
                <th className="py-2.5 px-4">CORNER RADIUS RULE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E3E2DF] font-mono">
              <tr>
                <td className="py-2.5 px-4 font-bold border-r border-[#1B1C1A]">Outer Cards & Panels</td>
                <td className="py-2.5 px-4 border-r border-[#1B1C1A]">1px solid #1B1C1A + Optional 4px Accent Bar</td>
                <td className="py-2.5 px-4">2px (rounded-sm) or 0px squared</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-bold border-r border-[#1B1C1A]">Form Controls & Inputs</td>
                <td className="py-2.5 px-4 border-r border-[#1B1C1A]">1px solid #1B1C1A (Focus: 1px ring #2563EB)</td>
                <td className="py-2.5 px-4">2px squared inset</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-bold border-r border-[#1B1C1A]">Data Tables & Grids</td>
                <td className="py-2.5 px-4 border-r border-[#1B1C1A]">1px solid #1B1C1A internal horizontal & vertical dividers</td>
                <td className="py-2.5 px-4">0px sharp right angles</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-bold border-r border-[#1B1C1A]">Badges & Pill Tags</td>
                <td className="py-2.5 px-4 border-r border-[#1B1C1A]">1px solid #1B1C1A with filled background</td>
                <td className="py-2.5 px-4">2px max (no rounded-full pills)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* III. Color Tokens System */}
      <div>
        <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-2 mb-4">
          <div className="flex items-center gap-2">
            <Box className="w-5 h-5 text-[#7C3AED]" />
            <h2 className="text-xl font-extrabold text-[#1B1C1A] uppercase tracking-tight">
              III. Color Tokens & Palette Strategy
            </h2>
          </div>
          <span className="text-xs font-mono text-gray-500 font-bold">CLICK HEX TO COPY</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {COLOR_TOKENS.map((token) => (
            <div
              key={token.name}
              onClick={() => copyToClipboard(token.hex)}
              className="bg-white border border-[#1B1C1A] p-3 rounded-[2px] cursor-pointer hover:bg-[#FAF9F5] transition-all group relative"
            >
              <div
                className="w-full h-16 border border-[#1B1C1A] rounded-[2px] mb-3 flex items-end p-2 transition-transform group-hover:scale-[0.98]"
                style={{ backgroundColor: token.hex }}
              >
                <span className="text-xs font-mono font-bold px-1.5 py-0.5 bg-white/90 text-[#1B1C1A] border border-[#1B1C1A]">
                  {token.hex}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#1B1C1A] uppercase">{token.name}</span>
                {copiedHex === token.hex ? (
                  <Check className="w-3.5 h-3.5 text-[#059669]" />
                ) : (
                  <Copy className="w-3.5 h-3.5 text-gray-400 group-hover:text-black" />
                )}
              </div>

              <p className="text-xs text-gray-500 mt-1 leading-snug">{token.role}</p>
            </div>
          ))}
        </div>
      </div>

      {/* IV. Typography System */}
      <div className="bg-white border border-[#1B1C1A] p-6 rounded-[2px] space-y-6">
        <div className="flex items-center gap-2 border-b border-[#1B1C1A] pb-3">
          <Layout className="w-5 h-5 text-[#EA580C]" />
          <h2 className="text-xl font-extrabold text-[#1B1C1A] uppercase tracking-tight">
            IV. Typography System & Mathematical Hierarchy
          </h2>
        </div>

        <div className="space-y-4 font-sans">
          {TYPOGRAPHY_TOKENS.map((typo) => (
            <div
              key={typo.name}
              className="p-4 border border-[#1B1C1A] rounded-[2px] bg-[#FAF9F5] flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div>
                <span className="text-xs font-mono font-bold text-gray-500 uppercase tracking-widest block mb-1">
                  {typo.name} // {typo.fontSize}
                </span>
                <div
                  className="text-[#1B1C1A]"
                  style={{
                    fontSize: typo.fontSize.split(' ')[0],
                    fontWeight: typo.fontWeight.startsWith('800') ? 800 : typo.fontWeight.startsWith('700') ? 700 : 500,
                    lineHeight: typo.lineHeight,
                    letterSpacing: typo.letterSpacing || 'normal'
                  }}
                >
                  BAUHAUS GRID TYPE SPEC
                </div>
              </div>

              <div className="text-right text-xs font-mono text-gray-600 shrink-0 border-t md:border-t-0 md:border-l border-[#1B1C1A] pt-2 md:pt-0 md:pl-4">
                <div>Weight: {typo.fontWeight}</div>
                <div>Usage: {typo.usage}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
