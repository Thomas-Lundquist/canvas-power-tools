import React, { useState } from 'react';
import { Copy, Check, Download, Terminal, FileText, Code2, Palette, Sparkles } from 'lucide-react';

export const DesignSpecDocument: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'claude' | 'figma' | 'css' | 'spec'>('claude');
  const [copiedFormat, setCopiedFormat] = useState<string | null>(null);

  const claudeCodePrompt = `# CLAUDE CODE & AI AGENT GUIDELINES: LIGHTWEIGHT BAUHAUS DESIGN SYSTEM (v2.4.0)

## 1. Zero Shadow & Flat Surface Rules
- STRICTLY BAN all drop-shadows (\`shadow-*\`), glow filters, blur backdrops, ambient radial gradients, or glassmorphism.
- All containers, cards, dialogs, popups, and inputs sit flat on a 1px border grid (\`border-[#1B1C1A]\` or \`border-[#4A4E69]\`).
- Corner Radii: Restrict all elements to \`rounded-[0px]\`, \`rounded-[1px]\`, or \`rounded-[2px]\`. Never use soft \`rounded-xl\` or \`rounded-2xl\`.

## 2. Windows 98 Grid & 4px Top Accent Rules
- Canvas Background: Warm paper off-white (\`bg-[#FAF9F5]\`).
- Secondary Container Fill: Inset silver/warm gray (\`bg-[#EFEEEA]\`).
- Interior Input Fill: Crisp pure white (\`bg-white\`).
- Top-Accent Color Strips: Use a 4px solid top border (\`border-t-4 border-t-[color]\`) to denote functional domain context:
  * Assignments / Core: \`border-t-[#2563EB]\` (Cobalt Blue)
  * Grading / Analytics: \`border-t-[#059669]\` (Emerald Green)
  * Announcements / Comms: \`border-t-[#7C3AED]\` (Purple)
  * Student Records: \`border-t-[#EA580C]\` (Orange)
  * Content Modules: \`border-t-[#0D9488]\` (Teal)
  * Setup / System: \`border-t-[#334155]\` (Dark Slate)
  * Primary Red / Alerts: \`border-t-[#B7102A]\` (Bauhaus Red)

## 3. Color Token Mapping
- Foundation: Canvas Paper \`#FAF9F5\`, Container Inset \`#EFEEEA\`, Surface White \`#FFFFFF\`, Stroke Dark Slate \`#1B1C1A\`.
- Primary Triad: Red \`#B7102A\`, Blue \`#485F84\` / \`#2563EB\`, Ochre Yellow \`#7A5500\` / \`#FEF08A\`.
- Accents: Blue \`#2563EB\`, Green \`#059669\`, Purple \`#7C3AED\`, Orange \`#EA580C\`, Teal \`#0D9488\`, Dark Slate \`#334155\`.
- Subdued Grid Stroke: \`#E3E2DF\` for interior table dividers.

## 4. Typography Hierarchy & Button Labels
- Font Family: Inter / System Sans paired with Monospace (\`font-mono\`) for metadata, codes, and specs.
- Action Buttons & Badges: Uppercase bold with tracked letter-spacing (\`uppercase font-bold tracking-wider text-xs\`).
- Metadata Tags: Monospace font for dates, IDs, or specs (\`font-mono text-xs text-gray-600 uppercase\`).
- Paragraph Body: \`text-xs\` or \`text-sm\` with crisp line-height 1.5 against white or \`#FAF9F5\`.

## 5. Comprehensive UI Component Taxonomy

### A. Input Controls & Form Primitives
- Standard Input Field: \`bg-white border border-[#1B1C1A] text-xs font-mono p-2 focus:ring-1 focus:ring-[#2563EB] outline-none rounded-[2px]\`.
- Custom Range Slider: Inset track (\`bg-[#EFEEEA] border border-[#1B1C1A]\`) with 0px squared thumb (\`accent-[#B7102A]\`).
- Increment/Decrement Stepper: 1px border button group \`[-] [ VALUE ] [+]\` with monospace numerical feedback.
- Date/Time Picker: Win98 inset field with calendar glyph button trigger.
- Custom Dropdown Selector: Inset select input with monospace options and down-arrow glyph indicator.
- Mechanical Tactile Switch: Precision 1px bordered toggle switch (\`ToggleSwitch\`) with embedded ON/OFF monospace track labels, tactile dual-line slider grip ridges, 1px border geometry, and multi-color variants (Ochre Yellow \`#FEF08A\`, Cobalt Blue \`#2563EB\`, Emerald Green \`#059669\`, Bauhaus Red \`#B7102A\`).

### B. Navigational Components
- Main Header Navbar: 1px border sticky navbar with brand indicator square (\`w-4 h-4 bg-[#B7102A] border border-[#1B1C1A]\`).
- Hamburger & Döner Filter Menu: 1px boxed menu triggers with expandable list popups.
- Bento App Grid: 2D bento grid cards with 1px dark borders and hover color state.
- Navigation Menus (Kebab 3-dot & Meatballs horizontal): Dropdown action popovers with 1px border and hover highlighted items (\`hover:bg-[#EFEEEA]\`).
- Breadcrumbs & Pagination: Monospace path indicators (\`HOME / MODULES / GRADING\`) and stepped page counters \`[1] [2] [3]\`.
- Sub-Navbar Tabs: Monospace tabs with active dark state (\`bg-[#1B1C1A] text-white\`).

### C. Informational Feeds & Feedback
- Icon Notification Badges: Micro counters (\`bg-[#B7102A] text-white text-[10px] font-bold px-1.5 py-0.5 rounded-[1px]\`).
- Chronological Activity Feed: Timeline with 1px vertical guide line and status dot milestones.
- Comments & Feedback Thread: Threaded comment blocks with author metadata tag, timestamp, and action buttons.
- Tooltip System: 1px border popovers with 4 color variants (Dark, Light, Yellow, Bauhaus Red) and 120ms cubic-bezier transition.
- Status Indicators: Stepped dots (Green Published, Yellow Pending, Red Alert, Gray Archived).

### D. Containers & Overlays
- Windows 98 Modal Window: Header titlebar \`#1B1C1A\` or \`#EFEEEA\` with close control button \`[✕]\` (omit unused minimize/maximize controls) and yellow status indicator.
- Destructive Warning Dialog: 4px Bauhaus Red top border (\`border-t-4 border-t-[#B7102A]\`) with alert octagon glyph.
- Slide-Over Inspector Drawer: Mechanical right/left anchored drawer with 4px Cobalt accent border (\`border-l-4 border-l-[#2563EB]\`).
- Accordion Collapsible Panels: 1px border expandable headers with \`[+]\` / \`[-]\` toggle states.

### E. Data Tables & Grid Layouts
- Grid Frame Container: Outer 1px border (\`#1B1C1A\`), \`bg-white\`, \`rounded-[2px]\`, zero drop-shadows.
- Header Control Toolbar: Inset background (\`bg-[#EFEEEA]\`) with monospace search input, status filter dropdown, density switcher (compact/comfortable), and bulk row selection metrics.
- Column Headers: Inset header row (\`bg-[#FAF9F5]\`), uppercase monospace tracking-wider text, 1px right dividers (\`#E3E2DF\`), and sortable column indicators (\`▲\`/\`▼\`).
- Rows & Cells: Crisp 1px bottom dividers (\`#E3E2DF\`), hover highlight (\`#FAF9F5\`), 4px domain category color indicator strip, high-contrast status badge pills, right-aligned monospace scores, and structured row action buttons.
- Stepped Pagination Footer: Inset footer (\`bg-[#EFEEEA]\`), record count readout (\`SHOWING 1-5 OF 24\`), and boxed stepped pagination controls \`[◄ PREV] [1] [2] [3] [NEXT ►]\`.

## 6. Mechanical Animations & Stepped Spinners
- Stepped Spinner: 8-tick stepped rotation (\`animate-stepped-spin\` using \`steps(8, end)\`). Never use smooth fluid gradient spinners.
- Stepped Progress Meters: Render progress bars as discrete block segments (\`[■■■■■□□□]\`) or 4-step CSS fills.
- Stepped Pulse Indicators: Discrete status dots with \`animate-pulse\` or pinging radar dots with 1px hairline rings.
- Skeleton Loaders: Flat placeholder blocks (\`bg-[#EFEEEA] border border-[#1B1C1A] animate-pulse rounded-[2px]\`).

## 7. Iconography & Glyph Rules
- Frame all utility icons inside a 1px border box: \`w-8 h-8 bg-white border border-[#1B1C1A] flex items-center justify-center rounded-[2px]\`.
- Action States: Destructive icons use red hover state (\`hover:bg-[#FEE2E2] hover:text-[#B7102A]\`). Settings gears rotate on hover (\`group-hover:rotate-90 duration-200\`).
- Icon Sizing: Micro/Table (\`w-3.5 h-3.5\`), Standard UI (\`w-4 h-4\`), Section Titles (\`w-5 h-5\`). Always set \`strokeWidth={2}\`.

## 8. Toast & Notification Banner System
- Top-Accent Banners: 1px border frame with 4px top color bar: Success (\`#059669\`), Warning (\`#FEF08A\` yellow fill), Destructive (\`#B7102A\`), Info (\`#2563EB\`).
- Dismissible Controls: Top-right \`[✕]\` button with instant unmount transition.
`;

  const figmaTokensJson = `{
  "$schema": "https://tokens.studio/schema/tokens.json",
  "name": "Lightweight Bauhaus Design System Tokens",
  "version": "2.4.0",
  "color": {
    "surface": {
      "canvas": { "$value": "#FAF9F5", "$type": "color", "description": "Primary paper background canvas" },
      "container": { "$value": "#EFEEEA", "$type": "color", "description": "Section header and inset panel fill" },
      "low": { "$value": "#F4F4F0", "$type": "color", "description": "Subtle contrast container" },
      "card": { "$value": "#FFFFFF", "$type": "color", "description": "Interior surface card background" }
    },
    "stroke": {
      "dark": { "$value": "#1B1C1A", "$type": "color", "description": "Primary structural border stroke & dark text" },
      "subtle": { "$value": "#E3E2DF", "$type": "color", "description": "Subtle table and grid dividers" }
    },
    "primary": {
      "red": { "$value": "#B7102A", "$type": "color", "description": "Bauhaus Primary Red for high-priority alerts" },
      "blue": { "$value": "#485F84", "$type": "color", "description": "Primary interactive blue" },
      "yellow": { "$value": "#7A5500", "$type": "color", "description": "Ochre yellow highlight" },
      "yellowFill": { "$value": "#FEF08A", "$type": "color", "description": "Light yellow badge fill" }
    },
    "moduleAccent": {
      "assignments": { "$value": "#2563EB", "$type": "color", "description": "Assignments module top accent" },
      "grading": { "$value": "#059669", "$type": "color", "description": "Grading module top accent" },
      "communication": { "$value": "#7C3AED", "$type": "color", "description": "Communication module top accent" },
      "people": { "$value": "#EA580C", "$type": "color", "description": "People module top accent" },
      "content": { "$value": "#0D9488", "$type": "color", "description": "Content module top accent" },
      "setup": { "$value": "#334155", "$type": "color", "description": "Setup module top accent" }
    }
  },
  "borderWidth": {
    "hairline": { "$value": "1px", "$type": "borderWidth" },
    "medium": { "$value": "2px", "$type": "borderWidth" },
    "accentTop": { "$value": "4px", "$type": "borderWidth" }
  },
  "borderRadius": {
    "none": { "$value": "0px", "$type": "borderRadius" },
    "sm": { "$value": "1px", "$type": "borderRadius" },
    "default": { "$value": "2px", "$type": "borderRadius" }
  },
  "typography": {
    "displayTitle": {
      "fontFamily": { "$value": "Inter, sans-serif", "$type": "fontFamilies" },
      "fontSize": { "$value": "64px", "$type": "fontSizes" },
      "fontWeight": { "$value": "800", "$type": "fontWeights" },
      "lineHeight": { "$value": "1.1", "$type": "lineHeights" },
      "letterSpacing": { "$value": "-0.02em", "$type": "letterSpacing" }
    },
    "headlineLarge": {
      "fontFamily": { "$value": "Inter, sans-serif", "$type": "fontFamilies" },
      "fontSize": { "$value": "32px", "$type": "fontSizes" },
      "fontWeight": { "$value": "700", "$type": "fontWeights" },
      "lineHeight": { "$value": "1.2", "$type": "lineHeights" }
    },
    "headlineMedium": {
      "fontFamily": { "$value": "Inter, sans-serif", "$type": "fontFamilies" },
      "fontSize": { "$value": "20px", "$type": "fontSizes" },
      "fontWeight": { "$value": "600", "$type": "fontWeights" },
      "lineHeight": { "$value": "1.4", "$type": "lineHeights" }
    },
    "bodyRegular": {
      "fontFamily": { "$value": "Inter, sans-serif", "$type": "fontFamilies" },
      "fontSize": { "$value": "16px", "$type": "fontSizes" },
      "fontWeight": { "$value": "400", "$type": "fontWeights" },
      "lineHeight": { "$value": "1.5", "$type": "lineHeights" }
    },
    "labelButton": {
      "fontFamily": { "$value": "Inter, sans-serif", "$type": "fontFamilies" },
      "fontSize": { "$value": "12px", "$type": "fontSizes" },
      "fontWeight": { "$value": "700", "$type": "fontWeights" },
      "letterSpacing": { "$value": "0.05em", "$type": "letterSpacing" },
      "textTransform": { "$value": "uppercase", "$type": "textCase" }
    },
    "labelMono": {
      "fontFamily": { "$value": "JetBrains Mono, monospace", "$type": "fontFamilies" },
      "fontSize": { "$value": "11px", "$type": "fontSizes" },
      "fontWeight": { "$value": "500", "$type": "fontWeights" }
    }
  },
  "spacing": {
    "xs": { "$value": "4px", "$type": "spacing" },
    "sm": { "$value": "8px", "$type": "spacing" },
    "md": { "$value": "16px", "$type": "spacing" },
    "lg": { "$value": "24px", "$type": "spacing" },
    "xl": { "$value": "32px", "$type": "spacing" }
  },
  "elevation": {
    "flat": {
      "boxShadow": { "$value": "none", "$type": "boxShadow" }
    }
  }
}`;

  const cssTailwindSpec = `/* ========================================================
   LIGHTWEIGHT BAUHAUS DESIGN SYSTEM - CSS CUSTOM PROPERTIES
   ======================================================== */
:root {
  /* Surface Fills */
  --color-surface-canvas: #FAF9F5;
  --color-surface-container: #EFEEEA;
  --color-surface-low: #F4F4F0;
  --color-surface-card: #FFFFFF;

  /* Strokes & Typography */
  --color-stroke-dark: #1B1C1A;
  --color-stroke-subtle: #E3E2DF;

  /* Primary Triad */
  --color-primary-red: #B7102A;
  --color-primary-blue: #485F84;
  --color-primary-yellow: #7A5500;
  --color-yellow-fill: #FEF08A;

  /* Module Accent Strips */
  --color-accent-assignments: #2563EB;
  --color-accent-grading: #059669;
  --color-accent-comms: #7C3AED;
  --color-accent-people: #EA580C;
  --color-accent-content: #0D9488;
  --color-accent-setup: #334155;

  /* Geometry & Borders */
  --border-width-grid: 1px;
  --border-width-accent: 4px;
  --border-radius-bauhaus: 2px;
  --box-shadow-strict: none;
}

/* ========================================================
   TAILWIND CSS EXTENSION CONFIGURATION (tailwind.config.js)
   ======================================================== */
module.exports = {
  theme: {
    extend: {
      colors: {
        canvas: '#FAF9F5',
        inset: '#EFEEEA',
        stroke: '#1B1C1A',
        bauhausRed: '#B7102A',
        bauhausBlue: '#2563EB',
        bauhausGreen: '#059669',
        bauhausPurple: '#7C3AED',
        bauhausOrange: '#EA580C',
        bauhausTeal: '#0D9488',
        bauhausYellow: '#FEF08A',
      },
      borderRadius: {
        DEFAULT: '2px',
        sm: '1px',
        none: '0px',
      },
      borderWidth: {
        DEFAULT: '1px',
        4: '4px',
      },
      boxShadow: {
        none: 'none',
      },
      keyframes: {
        steppedSpin: {
          '0%': { transform: 'rotate(0deg)' },
          '100%': { transform: 'rotate(360deg)' },
        },
        pop: {
          '0%': { transform: 'scale(0.95)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        }
      },
      animation: {
        'stepped-spin': 'steppedSpin 1s steps(8, end) infinite',
        'pop': 'pop 120ms cubic-bezier(0, 0, 0.2, 1)',
      }
    }
  }
};`;

  const markdownSpec = `# DESIGN BRIEF: LIGHTWEIGHT BAUHAUS (21ST-CENTURY WINDOWS 98 GRID)
**System Version:** v2.4.0  
**Target Platform:** Canvas Power Tools / AI Studio  
**Design Archetype:** B4 Crisp Grid Functionalism  

---

## 1. EXECUTIVE DESIGN PHILOSOPHY
The Lightweight Bauhaus design system merges early 20th-century Constructivism and Swiss typography with 1990s desktop operating system window layout structures. 

Key Architectural Rules:
- **Zero Shadows:** All cards, containers, buttons, and popups sit on a single flat surface. Soft drop-shadows and ambient gradients are strictly banned.
- **Crisp Structural Frames:** Containers use 1px solid \`#1B1C1A\` (or \`#4A4E69\`) borders.
- **Top-Accent Categorization:** Modules feature a 4px solid color band along top or left boundaries to denote domain context.
- **Squared Geometry:** Corner radii are restricted to 0px–2px (\`rounded-[2px]\`).
- **Warm Canvas:** High-contrast typography set against a \`#FAF9F5\` warm off-white canvas.

---

## 2. COLOR PALETTE SYSTEM

### Foundation Tokens
- **Surface Canvas:** \`#FAF9F5\` (Primary paper background)
- **Surface Container:** \`#EFEEEA\` (Secondary header and sidebar fill)
- **Surface Card / Input:** \`#FFFFFF\` (Interior contrast container)
- **On-Surface Stroke:** \`#1B1C1A\` (Primary typography and border stroke)

### Primary Bauhaus Triad
- **Primary Red:** \`#B7102A\` (High priority, alerts, callouts)
- **Primary Blue:** \`#485F84\` / \`#2563EB\` (Main actions, focus rings)
- **Primary Ochre Yellow:** \`#7A5500\` / \`#FEF08A\` (Highlights, warnings)

### Module Category Accents
- **Assignments:** \`#2563EB\` (Blue)
- **Grading:** \`#059669\` (Green)
- **Communication:** \`#7C3AED\` (Purple)
- **People / Students:** \`#EA580C\` (Orange)
- **Content:** \`#0D9488\` (Teal)
- **Setup:** \`#334155\` (Dark Slate)

---

## 3. TYPOGRAPHY HIERARCHY
- **Display Title:** 64px / 4rem | ExtraBold (800) | Uppercase Tracked
- **Headline Large:** 32px / 2rem | Bold (700) | Uppercase Tracked
- **Headline Medium:** 20px / 1.25rem | SemiBold (600)
- **Body Regular:** 16px / 1rem | Regular (400) | Line-height 1.5
- **Action Button Label:** 12px | Bold (700) | Tracked Out Uppercase
- **Metadata Tag:** 11px / 10px | Medium (500) | Font Mono

---

## 4. COMPONENT TAXONOMY
1. **Input Controls:** Range sliders, steppers, date pickers, dropdown selects, binary mechanical switches.
2. **Navigational Components:** Header navbar, bento grid cards, kebab 3-dot popovers, meatballs horizontal menus, breadcrumbs, page counters.
3. **Informational Feeds:** Notification counter badges, activity timeline feeds, comment threads, 4-color tooltip popovers.
4. **Containers & Overlays:** Win98 titlebar modals, destructive warning dialogs, slide-over inspector drawers, accordions.
`;

  const getActiveContent = () => {
    switch (activeTab) {
      case 'claude':
        return { content: claudeCodePrompt, filename: 'AGENTS.md', type: 'text/markdown' };
      case 'figma':
        return { content: figmaTokensJson, filename: 'figma-tokens.json', type: 'application/json' };
      case 'css':
        return { content: cssTailwindSpec, filename: 'tokens.css', type: 'text/css' };
      case 'spec':
        return { content: markdownSpec, filename: 'Lightweight_Bauhaus_Design_Brief.md', type: 'text/markdown' };
    }
  };

  const copyToClipboard = () => {
    const { content } = getActiveContent();
    navigator.clipboard.writeText(content);
    setCopiedFormat(activeTab);
    setTimeout(() => setCopiedFormat(null), 2000);
  };

  const downloadFile = () => {
    const { content, filename, type } = getActiveContent();
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#1B1C1A] pb-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-black text-[#1B1C1A] tracking-tight uppercase">
            Export Center for Figma & Claude Code
          </h1>
          <p className="text-xs text-gray-600 mt-1">
            Zero-loss spec handoff: Export structured Figma Design Tokens (JSON), Claude Code / AI Agent Prompt Guidelines (AGENTS.md), CSS/Tailwind rules, and Markdown Brief.
          </p>
        </div>

        {/* Global Format Selector Buttons */}
        <div className="inline-flex p-1 bg-[#EFEEEA] border border-[#1B1C1A] rounded-[2px] flex-wrap gap-1">
          <button
            onClick={() => setActiveTab('claude')}
            className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all flex items-center gap-1.5 ${
              activeTab === 'claude' ? 'bg-[#1B1C1A] text-[#FEF08A]' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-[#FEF08A]" />
            <span>1. CLAUDE CODE (AGENTS.MD)</span>
          </button>

          <button
            onClick={() => setActiveTab('figma')}
            className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all flex items-center gap-1.5 ${
              activeTab === 'figma' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
          >
            <Palette className="w-3.5 h-3.5 text-[#2563EB]" />
            <span>2. FIGMA TOKENS (JSON)</span>
          </button>

          <button
            onClick={() => setActiveTab('css')}
            className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all flex items-center gap-1.5 ${
              activeTab === 'css' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
          >
            <Code2 className="w-3.5 h-3.5 text-[#059669]" />
            <span>3. CSS & TAILWIND</span>
          </button>

          <button
            onClick={() => setActiveTab('spec')}
            className={`px-3 py-1.5 text-xs font-mono font-bold uppercase rounded-[2px] transition-all flex items-center gap-1.5 ${
              activeTab === 'spec' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-[#B7102A]" />
            <span>4. MARKDOWN SPEC</span>
          </button>
        </div>
      </div>

      {/* Action Controls Banner */}
      <div className="bg-[#EFEEEA] border border-[#1B1C1A] p-4 rounded-[2px] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#B7102A]" />
          <span className="text-xs font-mono font-bold uppercase text-[#1B1C1A]">
            TARGET EXPORT: {getActiveContent().filename} ({activeTab.toUpperCase()} FORMAT)
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={copyToClipboard}
            className="px-4 py-2 bg-white border border-[#1B1C1A] text-xs font-mono font-bold uppercase rounded-[2px] hover:bg-[#1B1C1A] hover:text-white transition-colors flex items-center gap-1.5"
          >
            {copiedFormat === activeTab ? (
              <>
                <Check className="w-4 h-4 text-[#059669]" />
                <span>COPIED TO CLIPBOARD!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>COPY FORMAT TO CLIPBOARD</span>
              </>
            )}
          </button>

          <button
            onClick={downloadFile}
            className="px-4 py-2 bg-[#1B1C1A] text-white border border-[#1B1C1A] text-xs font-mono font-bold uppercase rounded-[2px] hover:bg-black transition-colors flex items-center gap-1.5"
          >
            <Download className="w-4 h-4 text-[#FEF08A]" />
            <span>DOWNLOAD {getActiveContent().filename}</span>
          </button>
        </div>
      </div>

      {/* Code Viewer Stage */}
      <div className="bg-[#1B1C1A] text-white border border-[#1B1C1A] rounded-[2px] overflow-hidden">
        <div className="bg-black/40 border-b border-gray-800 px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-2 font-mono text-xs text-gray-400 uppercase">
            <Code2 className="w-4 h-4 text-[#FEF08A]" />
            <span>RAW CODE SPECIFICATION // ALL ITEMS INCLUDED</span>
          </div>
          <span className="text-[10px] font-mono text-[#059669] bg-emerald-950/80 px-2 py-0.5 border border-[#059669] rounded-[2px]">
            SYNTAX READY
          </span>
        </div>

        <pre className="p-6 font-mono text-xs text-gray-200 overflow-x-auto leading-relaxed max-h-[600px] overflow-y-auto">
          <code>{getActiveContent().content}</code>
        </pre>
      </div>
    </div>
  );
};

