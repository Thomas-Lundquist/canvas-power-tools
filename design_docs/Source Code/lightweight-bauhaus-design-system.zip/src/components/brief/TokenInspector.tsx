import React, { useState } from 'react';
import { SystemThemeConfig } from '../../types';
import { Sliders, RefreshCw, Eye, Layers } from 'lucide-react';

export const TokenInspector: React.FC = () => {
  const [config, setConfig] = useState<SystemThemeConfig>({
    strokeWidth: '1px',
    borderColor: '#1B1C1A',
    borderRadius: '2px',
    bgCanvas: '#FAF9F5',
    primaryAccent: '#B7102A'
  });

  const resetConfig = () => {
    setConfig({
      strokeWidth: '1px',
      borderColor: '#1B1C1A',
      borderRadius: '2px',
      bgCanvas: '#FAF9F5',
      primaryAccent: '#B7102A'
    });
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1B1C1A] pb-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-black text-[#1B1C1A] tracking-tight uppercase">
            Token Tweaker & Live Inspector
          </h1>
          <p className="text-xs text-gray-600 mt-1">
            Test custom border stroke weights, corner radii, and canvas background tones in real-time.
          </p>
        </div>

        <button
          onClick={resetConfig}
          className="px-3 py-1.5 bg-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-[#EFEEEA] flex items-center gap-1.5"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>RESET TO DEFAULT SPEC</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Parameter Controls */}
        <div className="lg:col-span-4 bg-white border border-[#1B1C1A] rounded-[2px] p-5 space-y-5">
          <div className="flex items-center gap-2 border-b border-[#1B1C1A] pb-3">
            <Sliders className="w-4 h-4 text-[#B7102A]" />
            <h3 className="text-xs font-bold text-[#1B1C1A] uppercase tracking-wider">
              Token Parameters
            </h3>
          </div>

          {/* Stroke Width */}
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-2">
              BORDER STROKE WEIGHT
            </label>
            <div className="grid grid-cols-3 gap-2 text-xs font-bold">
              {(['1px', '2px', '3px'] as const).map((w) => (
                <button
                  key={w}
                  onClick={() => setConfig({ ...config, strokeWidth: w })}
                  className={`py-1.5 border border-[#1B1C1A] rounded-[2px] uppercase ${
                    config.strokeWidth === w ? 'bg-[#1B1C1A] text-white' : 'bg-[#FAF9F5] text-[#1B1C1A]'
                  }`}
                >
                  {w}
                </button>
              ))}
            </div>
          </div>

          {/* Corner Radius */}
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-2">
              CORNER RADIUS
            </label>
            <div className="grid grid-cols-4 gap-2 text-xs font-bold">
              {(['0px', '2px', '4px', '8px'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setConfig({ ...config, borderRadius: r })}
                  className={`py-1.5 border border-[#1B1C1A] rounded-[2px] uppercase ${
                    config.borderRadius === r ? 'bg-[#1B1C1A] text-white' : 'bg-[#FAF9F5] text-[#1B1C1A]'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* Canvas Background Tint */}
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-2">
              CANVAS BACKGROUND TINT
            </label>
            <div className="space-y-2 text-xs font-medium">
              {[
                { hex: '#FAF9F5', label: 'Warm Off-White (#FAF9F5)' },
                { hex: '#F4F4F0', label: 'Cool Plaster (#F4F4F0)' },
                { hex: '#FFFFFF', label: 'Pure White (#FFFFFF)' }
              ].map((c) => (
                <label key={c.hex} className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="radio"
                    name="bgCanvas"
                    checked={config.bgCanvas === c.hex}
                    onChange={() => setConfig({ ...config, bgCanvas: c.hex })}
                    className="accent-[#B7102A]"
                  />
                  <span>{c.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Primary Accent Color */}
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-2">
              PRIMARY ACCENT COLOR
            </label>
            <div className="flex gap-2">
              {['#B7102A', '#2563EB', '#059669', '#7C3AED', '#EA580C'].map((hex) => (
                <button
                  key={hex}
                  onClick={() => setConfig({ ...config, primaryAccent: hex })}
                  className="w-8 h-8 rounded-[2px] border border-[#1B1C1A] flex items-center justify-center"
                  style={{ backgroundColor: hex }}
                >
                  {config.primaryAccent === hex && <span className="text-white text-xs font-bold">✓</span>}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Live Render Stage */}
        <div className="lg:col-span-8 bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-3">
            <h3 className="text-xs font-bold text-[#1B1C1A] uppercase tracking-wider flex items-center gap-2">
              <Eye className="w-4 h-4 text-[#2563EB]" />
              <span>Live Test Stage</span>
            </h3>
            <span className="text-xs font-mono text-gray-500">
              STYLES APPLY DYNAMICALLY BELOW
            </span>
          </div>

          {/* Dynamic Stage Canvas */}
          <div
            className="p-8 border border-[#1B1C1A] rounded-[2px] space-y-6 transition-colors"
            style={{ backgroundColor: config.bgCanvas }}
          >
            {/* Dynamic Card */}
            <div
              className="bg-white p-6"
              style={{
                borderWidth: config.strokeWidth,
                borderColor: config.borderColor,
                borderStyle: 'solid',
                borderRadius: config.borderRadius,
                borderTopWidth: '4px',
                borderTopColor: config.primaryAccent
              }}
            >
              <div className="text-xs font-mono font-bold uppercase tracking-widest text-gray-500 mb-2">
                TEST MODULE CARD
              </div>
              <h2 className="text-2xl font-black text-[#1B1C1A] uppercase">
                Interactive Token Preview
              </h2>
              <p className="text-xs text-gray-600 mt-2 leading-relaxed">
                Notice how the stroke width ({config.strokeWidth}), border radius ({config.borderRadius}), and accent color ({config.primaryAccent}) modify the visual density while maintaining strict 2D flat geometry without drop-shadows.
              </p>

              <div className="mt-6 pt-4 flex gap-3 border-t border-[#1B1C1A]">
                <button
                  style={{
                    borderWidth: config.strokeWidth,
                    borderColor: config.borderColor,
                    borderRadius: config.borderRadius,
                    backgroundColor: config.primaryAccent
                  }}
                  className="px-4 py-2 text-white text-xs font-bold uppercase tracking-wider"
                >
                  PRIMARY ACTION
                </button>

                <button
                  style={{
                    borderWidth: config.strokeWidth,
                    borderColor: config.borderColor,
                    borderRadius: config.borderRadius,
                    backgroundColor: '#FFFFFF',
                    color: '#1B1C1A'
                  }}
                  className="px-4 py-2 text-xs font-bold uppercase tracking-wider"
                >
                  SECONDARY ACTION
                </button>
              </div>
            </div>

            {/* Code Output Box */}
            <div className="bg-[#1B1C1A] text-white p-4 rounded-[2px] font-mono text-xs space-y-1">
              <div className="text-gray-400 uppercase">// GENERATED TAILWIND & CSS CONFIG</div>
              <div>border-width: {config.strokeWidth};</div>
              <div>border-color: {config.borderColor};</div>
              <div>border-radius: {config.borderRadius};</div>
              <div>box-shadow: none;</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
