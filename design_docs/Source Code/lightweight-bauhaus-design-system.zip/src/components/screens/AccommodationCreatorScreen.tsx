import React, { useState } from 'react';
import {
  ShieldCheck,
  Plus,
  Check,
  Clock,
  Users,
  FileText,
  Sparkles,
  ArrowRight,
  Search,
  CheckSquare,
  Lock,
  RotateCcw,
  Sliders,
  Calendar
} from 'lucide-react';
import { ScreenModule } from '../../types';

interface AccommodationCreatorScreenProps {
  onNavigateScreen?: (screen: ScreenModule) => void;
}

interface StudentOption {
  id: string;
  name: string;
  email: string;
  section: string;
  selected: boolean;
}

interface AssignmentOption {
  id: string;
  title: string;
  type: 'quiz' | 'assignment' | 'exam';
  originalDueDate: string;
  originalTimeLimitMinutes: number;
  selected: boolean;
}

export const AccommodationCreatorScreen: React.FC<AccommodationCreatorScreenProps> = ({
  onNavigateScreen
}) => {
  // Roster state
  const [students, setStudents] = useState<StudentOption[]>([
    { id: 'st-1', name: 'Jane Smith', email: 'jsmith@university.edu', section: 'Section 01', selected: true },
    { id: 'st-2', name: 'Marcus Johnson', email: 'mjohnson@university.edu', section: 'Section 01', selected: false },
    { id: 'st-3', name: 'Alex Rivera', email: 'arivera@university.edu', section: 'Section 02', selected: false },
    { id: 'st-4', name: 'Sarah Chen', email: 'schen@university.edu', section: 'Section 02', selected: false },
    { id: 'st-5', name: 'David Miller', email: 'dmiller@university.edu', section: 'Section 01', selected: false }
  ]);

  const [studentSearch, setStudentSearch] = useState('');

  // Assignments state
  const [assignments, setAssignments] = useState<AssignmentOption[]>([
    { id: 'asn-1', title: 'Quiz 1: Cell Structure & Organelles', type: 'quiz', originalDueDate: '2026-07-28', originalTimeLimitMinutes: 60, selected: true },
    { id: 'asn-2', title: 'Lab Report 2: Enzyme Kinetics', type: 'assignment', originalDueDate: '2026-08-01', originalTimeLimitMinutes: 0, selected: true },
    { id: 'asn-3', title: 'Midterm Exam: Molecular Biology', type: 'exam', originalDueDate: '2026-08-10', originalTimeLimitMinutes: 90, selected: false },
    { id: 'asn-4', title: 'Quiz 2: Genetics & DNA Replication', type: 'quiz', originalDueDate: '2026-08-18', originalTimeLimitMinutes: 45, selected: false }
  ]);

  // Accommodation parameters
  const [timeMultiplier, setTimeMultiplier] = useState<number>(1.5); // 1.5x time
  const [daysExtension, setDaysExtension] = useState<number>(3); // +3 days
  const [syncLockDate, setSyncLockDate] = useState<boolean>(true);
  const [extraAttempts, setExtraAttempts] = useState<number>(1);
  const [createdSuccess, setCreatedSuccess] = useState<boolean>(false);

  // Toggle student selection
  const toggleStudent = (id: string) => {
    setStudents(prev =>
      prev.map(s => (s.id === id ? { ...s, selected: !s.selected } : s))
    );
  };

  // Select all students
  const toggleAllStudents = (select: boolean) => {
    setStudents(prev => prev.map(s => ({ ...s, selected: select })));
  };

  // Toggle assignment selection
  const toggleAssignment = (id: string) => {
    setAssignments(prev =>
      prev.map(a => (a.id === id ? { ...a, selected: !a.selected } : a))
    );
  };

  // Select all assignments
  const toggleAllAssignments = (select: boolean) => {
    setAssignments(prev => prev.map(a => ({ ...a, selected: select })));
  };

  // Presets handler
  const applyPreset = (preset: 'standard' | 'double' | 'dates-only') => {
    if (preset === 'standard') {
      setTimeMultiplier(1.5);
      setDaysExtension(3);
      setExtraAttempts(1);
    } else if (preset === 'double') {
      setTimeMultiplier(2.0);
      setDaysExtension(5);
      setExtraAttempts(2);
    } else if (preset === 'dates-only') {
      setTimeMultiplier(1.0);
      setDaysExtension(2);
      setExtraAttempts(0);
    }
  };

  // Calculation helpers
  const getExtendedDate = (origDateStr: string, days: number): string => {
    try {
      const d = new Date(origDateStr);
      d.setDate(d.getDate() + days);
      return d.toISOString().split('T')[0];
    } catch {
      return origDateStr;
    }
  };

  const selectedStudents = students.filter(s => s.selected);
  const selectedAssignmentsList = assignments.filter(a => a.selected);

  const totalCalculatedOverrides = selectedStudents.length * selectedAssignmentsList.length;

  const handleCreateAccommodations = () => {
    setCreatedSuccess(true);
    setTimeout(() => {
      setCreatedSuccess(false);
      if (onNavigateScreen) {
        onNavigateScreen('accommodations');
      }
    }, 2000);
  };

  const filteredStudents = students.filter(
    s =>
      s.name.toLowerCase().includes(studentSearch.toLowerCase()) ||
      s.email.toLowerCase().includes(studentSearch.toLowerCase()) ||
      s.section.toLowerCase().includes(studentSearch.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Title & Header Bar */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            ACCOMMODATION CREATOR TOOL
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Build and deploy date extensions & quiz extra-time rules for individual students in Canvas.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onNavigateScreen && (
            <button
              onClick={() => onNavigateScreen('accommodations')}
              className="px-3 py-2 bg-white border border-[#1B1C1A] hover:bg-gray-100 font-mono font-bold text-xs uppercase rounded-[2px] transition-all"
            >
              VIEW ACTIVE OVERRIDES
            </button>
          )}

          <button
            onClick={handleCreateAccommodations}
            disabled={totalCalculatedOverrides === 0}
            className={`px-4 py-2 border border-[#1B1C1A] font-mono font-bold text-xs uppercase rounded-[2px] transition-all flex items-center gap-2 shadow-xs ${
              createdSuccess
                ? 'bg-[#FEF08A] text-[#1B1C1A]'
                : totalCalculatedOverrides === 0
                ? 'bg-gray-200 text-gray-500 cursor-not-allowed border-gray-300'
                : 'bg-[#EA580C] text-white hover:bg-orange-700'
            }`}
          >
            {createdSuccess ? (
              <>
                <Check className="w-4 h-4 text-[#1B1C1A]" />
                <span>CREATED & SYNCED TO CANVAS!</span>
              </>
            ) : (
              <>
                <Plus className="w-4 h-4" />
                <span>SYNC {totalCalculatedOverrides} ACCOMMODATION OVERRIDES</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* FERPA Compliance Banner */}
      <div className="p-3 bg-[#FEF08A]/40 border-2 border-[#1B1C1A] rounded-[2px] font-mono text-xs flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-[#7A5500] shrink-0 mt-0.5" />
        <div>
          <strong className="text-[#1B1C1A] uppercase font-black">
            FERPA PRIVACY SAFEGUARD & COMPLIANCE ARCHITECTURE:
          </strong>
          <p className="text-gray-800 text-[11px] mt-0.5 leading-relaxed">
            This tool processes operational math parameters (dates, minutes, multipliers) directly against Canvas LMS API REST endpoints. Zero medical records, disability categories, or reasons are saved or transmitted.
          </p>
        </div>
      </div>

      {/* Quick Preset Selector */}
      <div className="bg-[#FAF9F5] border border-[#1B1C1A] p-4 rounded-[2px] font-mono space-y-3">
        <div className="flex items-center justify-between border-b border-gray-300 pb-2">
          <span className="font-extrabold text-xs uppercase text-[#1B1C1A] flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-[#EA580C]" />
            <span>ACCOMMODATION PRESET BLUEPRINTS</span>
          </span>
          <span className="text-[10px] text-gray-500">CLICK TO PRE-FILL PARAMETERS</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            onClick={() => applyPreset('standard')}
            className="p-2.5 bg-white border border-[#1B1C1A] hover:border-[#EA580C] hover:bg-orange-50 text-left rounded-[2px] transition-all group"
          >
            <strong className="text-xs font-bold text-[#1B1C1A] block uppercase group-hover:text-[#EA580C]">
              1.5x TIME + 3 DAYS
            </strong>
            <span className="text-[10px] text-gray-500 block mt-0.5">
              Standard accommodation: 50% extra quiz time & +3 day assignment deadline shift.
            </span>
          </button>

          <button
            onClick={() => applyPreset('double')}
            className="p-2.5 bg-white border border-[#1B1C1A] hover:border-[#EA580C] hover:bg-orange-50 text-left rounded-[2px] transition-all group"
          >
            <strong className="text-xs font-bold text-[#1B1C1A] block uppercase group-hover:text-[#EA580C]">
              2.0x DOUBLE TIME + 5 DAYS
            </strong>
            <span className="text-[10px] text-gray-500 block mt-0.5">
              Extended accommodation: 100% extra quiz time & +5 day extended window.
            </span>
          </button>

          <button
            onClick={() => applyPreset('dates-only')}
            className="p-2.5 bg-white border border-[#1B1C1A] hover:border-[#EA580C] hover:bg-orange-50 text-left rounded-[2px] transition-all group"
          >
            <strong className="text-xs font-bold text-[#1B1C1A] block uppercase group-hover:text-[#EA580C]">
              FLEXIBLE 48-HR EXTENSION
            </strong>
            <span className="text-[10px] text-gray-500 block mt-0.5">
              Date-focused: +2 days extension with standard quiz time limit.
            </span>
          </button>
        </div>
      </div>

      {/* 2-Column Grid: Left (Students & Assignments) | Right (Rules & Live Preview) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: Student Roster & Assignment Scope (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Step 1: Select Student(s) */}
          <div className="bg-white border-2 border-[#1B1C1A] rounded-[2px] p-4 font-mono text-xs space-y-3">
            <div className="flex items-center justify-between border-b border-gray-200 pb-2">
              <span className="font-bold uppercase text-[#1B1C1A] flex items-center gap-1.5">
                <Users className="w-4 h-4 text-[#EA580C]" />
                <span>1. SELECT STUDENT(S) ({selectedStudents.length} SELECTED)</span>
              </span>

              <div className="flex items-center gap-2 text-[10px]">
                <button
                  onClick={() => toggleAllStudents(true)}
                  className="text-[#EA580C] hover:underline font-bold"
                >
                  SELECT ALL
                </button>
                <span>|</span>
                <button
                  onClick={() => toggleAllStudents(false)}
                  className="text-gray-500 hover:underline font-bold"
                >
                  CLEAR
                </button>
              </div>
            </div>

            {/* Student Search Bar */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={studentSearch}
                onChange={e => setStudentSearch(e.target.value)}
                placeholder="Search students by name, email, or section..."
                className="w-full bg-[#FAF9F5] border border-[#1B1C1A] pl-8 pr-3 py-1.5 text-xs font-mono rounded-[1px] outline-none focus:border-[#EA580C]"
              />
            </div>

            {/* Student Checklist */}
            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {filteredStudents.map(student => (
                <div
                  key={student.id}
                  onClick={() => toggleStudent(student.id)}
                  className={`p-2 border rounded-[2px] cursor-pointer transition-all flex items-center justify-between ${
                    student.selected
                      ? 'bg-orange-50 border-[#EA580C] font-bold text-[#1B1C1A]'
                      : 'bg-white border-gray-200 text-gray-700 hover:border-gray-400'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={student.selected}
                      onChange={() => {}} // handled by parent div click
                      className="accent-[#EA580C] w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <span className="block">{student.name}</span>
                      <span className="text-[10px] text-gray-500 font-normal">{student.email}</span>
                    </div>
                  </div>

                  <span className="text-[10px] px-1.5 py-0.5 bg-gray-100 border border-gray-300 rounded-[1px]">
                    {student.section}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Step 2: Target Scope (Assignments & Quizzes) */}
          <div className="bg-white border-2 border-[#1B1C1A] rounded-[2px] p-4 font-mono text-xs space-y-3">
            <div className="flex items-center justify-between border-b border-gray-200 pb-2">
              <span className="font-bold uppercase text-[#1B1C1A] flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-[#EA580C]" />
                <span>2. SELECT TARGET ASSIGNMENTS ({selectedAssignmentsList.length} SELECTED)</span>
              </span>

              <div className="flex items-center gap-2 text-[10px]">
                <button
                  onClick={() => toggleAllAssignments(true)}
                  className="text-[#EA580C] hover:underline font-bold"
                >
                  SELECT ALL
                </button>
                <span>|</span>
                <button
                  onClick={() => toggleAllAssignments(false)}
                  className="text-gray-500 hover:underline font-bold"
                >
                  CLEAR
                </button>
              </div>
            </div>

            {/* Assignments Checklist */}
            <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
              {assignments.map(asn => (
                <div
                  key={asn.id}
                  onClick={() => toggleAssignment(asn.id)}
                  className={`p-2.5 border rounded-[2px] cursor-pointer transition-all flex items-center justify-between ${
                    asn.selected
                      ? 'bg-orange-50 border-[#EA580C] font-bold text-[#1B1C1A]'
                      : 'bg-white border-gray-200 text-gray-700 hover:border-gray-400'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      checked={asn.selected}
                      onChange={() => {}}
                      className="accent-[#EA580C] w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <span className="block">{asn.title}</span>
                      <span className="text-[10px] text-gray-500 font-normal">
                        Due: {asn.originalDueDate} {asn.originalTimeLimitMinutes > 0 ? `• Time Limit: ${asn.originalTimeLimitMinutes} mins` : ''}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded-[1px] border ${
                      asn.type === 'quiz'
                        ? 'bg-purple-50 text-purple-800 border-purple-200'
                        : asn.type === 'exam'
                        ? 'bg-red-50 text-red-800 border-red-200'
                        : 'bg-blue-50 text-blue-800 border-blue-200'
                    }`}
                  >
                    {asn.type}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Rule Configuration & Live Calculated Preview (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Step 3: Configure Accommodation Parameters */}
          <div className="bg-white border-2 border-[#1B1C1A] rounded-[2px] p-4 font-mono text-xs space-y-4">
            <div className="border-b border-gray-200 pb-2">
              <span className="font-bold uppercase text-[#1B1C1A] flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-[#EA580C]" />
                <span>3. ACCOMMODATION RULE CONFIG</span>
              </span>
            </div>

            {/* Quiz Extra Time Multiplier */}
            <div className="space-y-2">
              <label className="font-bold text-gray-700 block uppercase text-[11px]">
                Quiz Time Limit Multiplier:
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { label: '1.0x (Standard)', val: 1.0 },
                  { label: '1.25x (+25%)', val: 1.25 },
                  { label: '1.5x (+50%)', val: 1.5 },
                  { label: '2.0x (Double)', val: 2.0 }
                ].map(item => (
                  <button
                    key={item.val}
                    onClick={() => setTimeMultiplier(item.val)}
                    className={`p-1.5 text-[10px] font-bold uppercase border rounded-[1px] transition-all text-center ${
                      timeMultiplier === item.val
                        ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                        : 'bg-[#FAF9F5] text-gray-700 border-gray-300 hover:border-[#1B1C1A]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Date Extension Days Offset */}
            <div className="space-y-2">
              <label className="font-bold text-gray-700 block uppercase text-[11px]">
                Due Date Extension Offset (+Days):
              </label>
              <div className="flex items-center gap-2">
                {[2, 3, 5, 7].map(days => (
                  <button
                    key={days}
                    onClick={() => setDaysExtension(days)}
                    className={`flex-1 py-1 text-xs font-bold border rounded-[1px] transition-all ${
                      daysExtension === days
                        ? 'bg-[#EA580C] text-white border-[#EA580C]'
                        : 'bg-[#FAF9F5] text-gray-700 border-gray-300 hover:border-[#1B1C1A]'
                    }`}
                  >
                    +{days} Days
                  </button>
                ))}
              </div>
            </div>

            {/* Additional Options */}
            <div className="pt-2 border-t border-gray-100 space-y-2 text-[11px]">
              <label className="flex items-center gap-2 cursor-pointer text-gray-800">
                <input
                  type="checkbox"
                  checked={syncLockDate}
                  onChange={e => setSyncLockDate(e.target.checked)}
                  className="accent-[#EA580C] w-4 h-4 cursor-pointer"
                />
                <span className="font-bold">Sync Until/Lock Dates with Extended Due Date</span>
              </label>

              <div className="flex items-center justify-between pt-1">
                <span className="text-gray-700 font-bold">Extra Attempts (New Quizzes):</span>
                <select
                  value={extraAttempts}
                  onChange={e => setExtraAttempts(Number(e.target.value))}
                  className="bg-[#FAF9F5] border border-[#1B1C1A] px-2 py-0.5 rounded-[1px] font-bold text-xs outline-none"
                >
                  <option value={0}>Standard (0 extra)</option>
                  <option value={1}>+1 Extra Attempt</option>
                  <option value={2}>+2 Extra Attempts</option>
                  <option value={3}>Unlimited Attempts</option>
                </select>
              </div>
            </div>
          </div>

          {/* Live Calculated Impact Preview */}
          <div className="bg-[#FAF9F5] border-2 border-[#1B1C1A] rounded-[2px] p-4 font-mono text-xs space-y-3">
            <div className="flex items-center justify-between border-b border-gray-300 pb-2">
              <span className="font-bold uppercase text-[#1B1C1A] flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-[#EA580C]" />
                <span>LIVE CALCULATED PREVIEW</span>
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 bg-[#EA580C] text-white rounded-[1px]">
                {totalCalculatedOverrides} OVERRIDES
              </span>
            </div>

            {totalCalculatedOverrides === 0 ? (
              <p className="text-gray-500 italic text-[11px] py-4 text-center">
                Please select at least 1 student and 1 assignment to preview override math.
              </p>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {selectedStudents.map(student =>
                  selectedAssignmentsList.map(asn => {
                    const newDueDate = getExtendedDate(asn.originalDueDate, daysExtension);
                    const newTimeLimit = Math.round(asn.originalTimeLimitMinutes * timeMultiplier);

                    return (
                      <div
                        key={`${student.id}-${asn.id}`}
                        className="p-2.5 bg-white border border-[#1B1C1A] rounded-[2px] space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <strong className="text-[#1B1C1A] uppercase">{student.name}</strong>
                          <span className="text-[10px] text-gray-500">{asn.type.toUpperCase()}</span>
                        </div>
                        <p className="text-gray-600 text-[11px] truncate">{asn.title}</p>

                        <div className="pt-1.5 border-t border-gray-100 flex flex-wrap items-center justify-between text-[10px] gap-2">
                          <div>
                            <span className="text-gray-400">DUE: </span>
                            <span className="line-through text-gray-500 mr-1">{asn.originalDueDate}</span>
                            <span className="font-bold text-[#EA580C]">{newDueDate} (+{daysExtension}d)</span>
                          </div>

                          {asn.originalTimeLimitMinutes > 0 && (
                            <div>
                              <span className="text-gray-400">TIME: </span>
                              <span className="line-through text-gray-500 mr-1">{asn.originalTimeLimitMinutes}m</span>
                              <span className="font-bold text-purple-700">{newTimeLimit}m ({timeMultiplier}x)</span>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            )}

            {/* Bottom Final Action Button */}
            <div className="pt-2">
              <button
                onClick={handleCreateAccommodations}
                disabled={totalCalculatedOverrides === 0}
                className={`w-full py-2.5 border border-[#1B1C1A] font-mono font-bold text-xs uppercase rounded-[2px] transition-all flex items-center justify-center gap-2 ${
                  createdSuccess
                    ? 'bg-[#FEF08A] text-[#1B1C1A]'
                    : totalCalculatedOverrides === 0
                    ? 'bg-gray-200 text-gray-500 cursor-not-allowed border-gray-300'
                    : 'bg-[#EA580C] text-white hover:bg-orange-700'
                }`}
              >
                {createdSuccess ? (
                  <>
                    <Check className="w-4 h-4 text-[#1B1C1A]" />
                    <span>OVERRIDES CREATED & SYNCED TO CANVAS!</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    <span>CREATE {totalCalculatedOverrides} ACCOMMODATIONS</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
