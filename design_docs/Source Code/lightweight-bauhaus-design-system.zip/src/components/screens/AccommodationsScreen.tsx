import React, { useState } from 'react';
import {
  ShieldCheck,
  Plus,
  Check,
  Calendar,
  Users,
  AlertCircle,
  HelpCircle,
  Clock,
  Sparkles
} from 'lucide-react';
import { ScreenModule } from '../../types';

interface OverrideItem {
  id: string;
  studentName: string;
  assignmentName: string;
  origDate: string;
  overrideDate: string;
  daysExtended: number;
}

interface AccommodationsScreenProps {
  onNavigateScreen?: (screen: ScreenModule) => void;
}

export const AccommodationsScreen: React.FC<AccommodationsScreenProps> = ({ onNavigateScreen }) => {
  const [overrides, setOverrides] = useState<OverrideItem[]>([
    { id: 'ov-1', studentName: 'Jane Smith', assignmentName: 'Quiz 1: Cell Biology', origDate: '2026-07-25', overrideDate: '2026-07-28', daysExtended: 3 },
    { id: 'ov-2', studentName: 'Jane Smith', assignmentName: 'Lab Report 2', origDate: '2026-08-01', overrideDate: '2026-08-04', daysExtended: 3 },
    { id: 'ov-3', studentName: 'Marcus Johnson', assignmentName: 'Midterm Essay Draft', origDate: '2026-08-10', overrideDate: '2026-08-15', daysExtended: 5 }
  ]);

  const [applied, setApplied] = useState(false);

  const handleApplyOverrides = () => {
    setApplied(true);
    setTimeout(() => setApplied(false), 2500);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            ACCOMMODATION OVERRIDE MANAGER
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Apply per-student date overrides across multiple assignments in one flow. Zero disability data stored.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onNavigateScreen && (
            <button
              onClick={() => onNavigateScreen('accommodation-creator')}
              className="px-4 py-2 bg-[#EA580C] hover:bg-orange-700 text-white font-mono font-bold text-xs uppercase rounded-[2px] transition-all flex items-center gap-2 shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>CREATE ACCOMMODATION</span>
            </button>
          )}

          <button
            onClick={handleApplyOverrides}
            className={`px-4 py-2 border border-[#1B1C1A] font-mono font-bold text-xs uppercase rounded-[2px] transition-all flex items-center gap-2 ${
              applied ? 'bg-[#FEF08A] text-[#1B1C1A]' : 'bg-white text-[#1B1C1A] hover:bg-gray-100'
            }`}
          >
            {applied ? (
              <>
                <Check className="w-4 h-4 text-[#1B1C1A]" />
                <span>OVERRIDDEN IN CANVAS!</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4 text-[#EA580C]" />
                <span>APPLY ALL OVERRIDES</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* FERPA Security Banner */}
      <div className="p-3 bg-[#FEF08A]/30 border border-[#1B1C1A] rounded-[2px] font-mono text-xs flex items-start gap-2.5">
        <ShieldCheck className="w-4 h-4 text-[#7A5500] shrink-0 mt-0.5" />
        <div>
          <strong className="text-[#1B1C1A] uppercase">FERPA ALIGNMENT & PRIVACY SAFEGUARD:</strong>
          <p className="text-gray-700 text-[11px] mt-0.5">
            This extension stores no medical categories, disability classifications, or reasons. It handles only date mathematical outputs directly in Canvas API.
          </p>
        </div>
      </div>

      {/* Accommodation Creator Promo Banner */}
      <div className="bg-[#FAF9F5] border-2 border-[#1B1C1A] p-4 rounded-[2px] font-mono flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#EA580C] text-white rounded-[2px]">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <strong className="text-sm font-bold uppercase text-[#1B1C1A]">
              ACCOMMODATION CREATOR TOOL
            </strong>
            <p className="text-xs text-gray-600 mt-0.5">
              Need to add new extra-time multipliers or multi-assignment date extensions for specific students?
            </p>
          </div>
        </div>

        {onNavigateScreen && (
          <button
            onClick={() => onNavigateScreen('accommodation-creator')}
            className="px-3.5 py-2 bg-[#1B1C1A] hover:bg-gray-800 text-white font-mono font-bold text-xs uppercase rounded-[2px] transition-all flex items-center gap-2"
          >
            <span>LAUNCH CREATOR TOOL</span>
            <Plus className="w-4 h-4 text-[#FEF08A]" />
          </button>
        )}
      </div>

      {/* Active Overrides Table */}
      <div className="bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-4 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-gray-200 pb-2">
          <h3 className="font-bold uppercase text-gray-500">
            ACTIVE STUDENT OVERRIDES ({overrides.length})
          </h3>
          <span className="text-[10px] text-gray-400">SYNCED WITH CANVAS REST API</span>
        </div>

        <div className="space-y-2">
          {overrides.map((ov) => (
            <div key={ov.id} className="p-3 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] flex flex-wrap items-center justify-between gap-4">
              <div>
                <span className="font-bold text-[#1B1C1A] text-sm">{ov.studentName}</span>
                <p className="text-gray-600 mt-0.5">{ov.assignmentName}</p>
              </div>

              <div className="flex items-center gap-4">
                <span className="text-gray-500">ORIGINAL: {ov.origDate}</span>
                <span className="px-2 py-0.5 bg-orange-100 text-orange-900 border border-orange-300 font-bold">
                  OVERRIDE: {ov.overrideDate} (+{ov.daysExtended} days)
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
