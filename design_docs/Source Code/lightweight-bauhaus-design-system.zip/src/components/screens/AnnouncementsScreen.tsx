import React, { useState } from 'react';
import {
  Bold,
  Italic,
  Link,
  List,
  Image as ImageIcon,
  Paperclip,
  Info,
  HelpCircle,
  Send,
  Eye,
  Save,
  Clock,
  Glasses
} from 'lucide-react';

export const AnnouncementsScreen: React.FC = () => {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [selectedSections, setSelectedSections] = useState<string[]>(['sec-1']);
  const [deliveryMode, setDeliveryMode] = useState<'immediate' | 'scheduled'>('immediate');
  const [scheduleDate, setScheduleDate] = useState('');
  const [scheduleTime, setScheduleTime] = useState('');
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [sentNotice, setSentNotice] = useState(false);

  const sections = [
    { id: 'sec-1', label: 'Biology 101 — Fall 2026 (Section A)' },
    { id: 'sec-2', label: 'Biology 101 — Spring 2027 (Waitlist)' },
    { id: 'sec-3', label: 'Biology Lab — Section 04' }
  ];

  const toggleSection = (id: string) => {
    if (selectedSections.includes(id)) {
      setSelectedSections(selectedSections.filter((s) => s !== id));
    } else {
      setSelectedSections([...selectedSections, id]);
    }
  };

  const handleSelectAll = () => {
    if (selectedSections.length === sections.length) {
      setSelectedSections([]);
    } else {
      setSelectedSections(sections.map((s) => s.id));
    }
  };

  const handleSend = () => {
    setSentNotice(true);
    setTimeout(() => setSentNotice(false), 4000);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header Banner */}
      <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#1B1C1A] pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-[#7C3AED] uppercase tracking-wider mb-1">
            <Glasses className="w-4 h-4" />
            <span>BIOLOGY 101 — PRINCIPLES OF LIFE</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-[#1B1C1A] tracking-tight uppercase">
            Announcements
          </h1>
        </div>

        <button className="flex items-center gap-1.5 px-3 py-1.5 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] text-xs font-bold text-[#1B1C1A] hover:bg-[#EFEEEA] transition-colors">
          <HelpCircle className="w-4 h-4" />
          <span>Support</span>
        </button>
      </div>

      {sentNotice && (
        <div className="bg-[#059669] text-white p-3 border border-[#1B1C1A] text-xs font-bold rounded-[2px] flex items-center justify-between">
          <span>ANNOUNCEMENT SENT SUCCESSFULLY TO SELECTED SECTIONS</span>
          <button onClick={() => setSentNotice(false)} className="underline">Dismiss</button>
        </div>
      )}

      {/* Main Grid: Left Sidebar Options + Right Composition Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Recipient Selection & Global Notice */}
        <div className="lg:col-span-4 space-y-4">
          {/* Recipient Selection Card */}
          <div className="bg-white border border-[#1B1C1A] rounded-[2px] p-4 relative">
            <div className="absolute -top-2.5 left-3 bg-[#7C3AED] text-white text-xs font-mono font-bold px-2 py-0.5 uppercase tracking-wider border border-[#1B1C1A]">
              RECIPIENT SELECTION
            </div>

            <h3 className="text-xs font-bold text-[#1B1C1A] uppercase tracking-wider mt-2 mb-3">
              Select Course Sections
            </h3>

            <div className="space-y-2.5">
              {sections.map((sec) => {
                const isChecked = selectedSections.includes(sec.id);
                return (
                  <label
                    key={sec.id}
                    onClick={() => toggleSection(sec.id)}
                    className="flex items-center gap-2.5 cursor-pointer text-xs font-medium text-[#1B1C1A] select-none"
                  >
                    <div
                      className={`w-4 h-4 border border-[#1B1C1A] rounded-[2px] flex items-center justify-center transition-colors ${
                        isChecked ? 'bg-[#7C3AED] text-white' : 'bg-white'
                      }`}
                    >
                      {isChecked && <span className="text-xs font-bold">✓</span>}
                    </div>
                    <span>{sec.label}</span>
                  </label>
                );
              })}
            </div>

            <div className="border-t border-[#E3E2DF] mt-4 pt-3">
              <button
                onClick={handleSelectAll}
                className="text-xs font-bold text-[#7C3AED] hover:underline uppercase tracking-wider"
              >
                SELECT ALL ACTIVE SECTIONS
              </button>
            </div>
          </div>

          {/* Global Notification Banner */}
          <div className="bg-[#E9D5FF]/40 border border-[#7C3AED] p-4 rounded-[2px] flex items-start gap-3">
            <Info className="w-5 h-5 text-[#7C3AED] shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold text-[#7C3AED]">Global Notification</h4>
              <p className="text-xs text-[#1B1C1A] mt-1 leading-relaxed">
                This announcement will be emailed immediately to all students if &apos;Send Now&apos; is selected.
              </p>
            </div>
          </div>
        </div>

        {/* Right Column: Message Composition & Delivery Options */}
        <div className="lg:col-span-8 bg-white border border-[#1B1C1A] rounded-[2px] p-5 space-y-5">
          {/* Subject Line */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#1B1C1A] mb-1.5">
              SUBJECT LINE
            </label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="e.g. Important: Midterm Review Session Rescheduled"
              className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs font-medium rounded-[2px] focus:outline-none focus:ring-1 focus:ring-[#7C3AED]"
            />
          </div>

          {/* Message Body & WYSIWYG Bar */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#1B1C1A] mb-1.5">
              MESSAGE BODY
            </label>

            {/* Formatting Toolbar */}
            <div className="bg-[#FAF9F5] border border-[#1B1C1A] border-b-0 px-2 py-1.5 flex items-center gap-1 rounded-t-[2px]">
              <button className="p-1 hover:bg-[#EFEEEA] border border-transparent hover:border-[#1B1C1A] rounded-[2px]">
                <Bold className="w-3.5 h-3.5 text-[#1B1C1A]" />
              </button>
              <button className="p-1 hover:bg-[#EFEEEA] border border-transparent hover:border-[#1B1C1A] rounded-[2px]">
                <Italic className="w-3.5 h-3.5 text-[#1B1C1A]" />
              </button>
              <button className="p-1 hover:bg-[#EFEEEA] border border-transparent hover:border-[#1B1C1A] rounded-[2px]">
                <Link className="w-3.5 h-3.5 text-[#1B1C1A]" />
              </button>
              <button className="p-1 hover:bg-[#EFEEEA] border border-transparent hover:border-[#1B1C1A] rounded-[2px]">
                <List className="w-3.5 h-3.5 text-[#1B1C1A]" />
              </button>
              <div className="h-3 w-[1px] bg-[#1B1C1A] mx-1" />
              <button className="p-1 hover:bg-[#EFEEEA] border border-transparent hover:border-[#1B1C1A] rounded-[2px]">
                <ImageIcon className="w-3.5 h-3.5 text-[#1B1C1A]" />
              </button>
              <button className="p-1 hover:bg-[#EFEEEA] border border-transparent hover:border-[#1B1C1A] rounded-[2px]">
                <Paperclip className="w-3.5 h-3.5 text-[#1B1C1A]" />
              </button>
            </div>

            {/* Textarea */}
            <textarea
              rows={8}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your announcement here..."
              className="w-full bg-white border border-[#1B1C1A] p-3 text-xs font-normal rounded-b-[2px] focus:outline-none focus:ring-1 focus:ring-[#7C3AED]"
            />
          </div>

          {/* Delivery Schedule Section */}
          <div className="border border-[#1B1C1A] p-4 rounded-[2px] bg-[#FAF9F5] grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#1B1C1A] mb-2">
                DELIVERY SCHEDULE
              </label>

              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
                  <input
                    type="radio"
                    name="delivery"
                    checked={deliveryMode === 'immediate'}
                    onChange={() => setDeliveryMode('immediate')}
                    className="accent-[#7C3AED]"
                  />
                  <span>Send immediately</span>
                </label>

                <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
                  <input
                    type="radio"
                    name="delivery"
                    checked={deliveryMode === 'scheduled'}
                    onChange={() => setDeliveryMode('scheduled')}
                    className="accent-[#7C3AED]"
                  />
                  <span>Schedule for later</span>
                </label>
              </div>
            </div>

            {deliveryMode === 'scheduled' && (
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#1B1C1A] mb-2">
                  DATE & TIME
                </label>
                <div className="flex gap-2">
                  <input
                    type="date"
                    value={scheduleDate}
                    onChange={(e) => setScheduleDate(e.target.value)}
                    className="bg-white border border-[#1B1C1A] px-2 py-1 text-xs rounded-[2px] w-full"
                  />
                  <input
                    type="time"
                    value={scheduleTime}
                    onChange={(e) => setScheduleTime(e.target.value)}
                    className="bg-white border border-[#1B1C1A] px-2 py-1 text-xs rounded-[2px] w-full"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Bottom Action Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
            <div className="flex items-center gap-2">
              <button className="px-3 py-1.5 bg-[#FAF9F5] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-[#EFEEEA]">
                LOAD TEMPLATE
              </button>
              <button className="px-3 py-1.5 bg-[#FAF9F5] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-[#EFEEEA]">
                SAVE AS TEMPLATE
              </button>
              <button className="px-3 py-1.5 bg-[#FAF9F5] border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-[#EFEEEA]">
                SAVE AS DRAFT
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowPreviewModal(true)}
                className="px-4 py-2 bg-white border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px] hover:bg-[#EFEEEA] flex items-center gap-1.5"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>PREVIEW</span>
              </button>

              <button
                onClick={handleSend}
                className="px-5 py-2 bg-[#7C3AED] text-white border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px] hover:bg-[#6D28D9] flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>SEND ANNOUNCEMENT</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Preview Modal */}
      {showPreviewModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white border-2 border-[#1B1C1A] rounded-[2px] w-full max-w-2xl p-6 relative space-y-4">
            <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-3">
              <h3 className="text-lg font-bold text-[#1B1C1A] uppercase tracking-tight">
                Announcement Preview
              </h3>
              <button
                onClick={() => setShowPreviewModal(false)}
                className="text-xs font-bold text-gray-500 hover:text-black border border-[#1B1C1A] px-2 py-0.5 rounded-[2px]"
              >
                ✕
              </button>
            </div>

            <div className="bg-[#FAF9F5] border border-[#1B1C1A] p-4 rounded-[2px] space-y-2">
              <div className="text-xs text-gray-500 font-mono">SUBJECT:</div>
              <div className="text-sm font-bold text-[#1B1C1A]">
                {subject || "(No Subject Line Provided)"}
              </div>
              <div className="text-xs text-gray-500 font-mono pt-2">RECIPIENTS:</div>
              <div className="text-xs font-medium text-[#7C3AED]">
                {selectedSections.length > 0 ? `${selectedSections.length} Sections Selected` : "No sections selected"}
              </div>
            </div>

            <div className="border border-[#1B1C1A] p-4 rounded-[2px] text-xs leading-relaxed min-h-[120px]">
              {message || "No announcement content typed yet..."}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowPreviewModal(false)}
                className="px-4 py-1.5 bg-[#1B1C1A] text-white border border-[#1B1C1A] text-xs font-bold rounded-[2px]"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
