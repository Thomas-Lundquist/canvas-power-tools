import React, { useState } from 'react';
import {
  Copy,
  ArrowRight,
  Check,
  Calendar,
  BookOpen,
  Layers,
  FileText,
  AlertCircle
} from 'lucide-react';

export const AssignmentCopyScreen: React.FC = () => {
  const [sourceCourse, setSourceCourse] = useState('Biology 101 - Fall 2025');
  const [targetCourses, setTargetCourses] = useState<string[]>([
    'Biology 101 - Spring 2026',
    'Honors Biology - Spring 2026'
  ]);
  const [selectedAssignments, setSelectedAssignments] = useState<string[]>([
    'asn-1',
    'asn-2'
  ]);
  const [dateOffsetDays, setDateOffsetDays] = useState(120);
  const [copied, setCopied] = useState(false);

  const availableAssignments = [
    { id: 'asn-1', title: 'Lab Report 1: Osmosis in Plant Cells', group: 'Lab Reports', points: 50, origDate: '2025-09-15' },
    { id: 'asn-2', title: 'Midterm Examination (Ch. 1-6)', group: 'Exams', points: 100, origDate: '2025-10-10' },
    { id: 'asn-3', title: 'Cellular Respiration Quiz', group: 'Quizzes', points: 20, origDate: '2025-10-25' },
    { id: 'asn-4', title: 'Genetics Problem Set #3', group: 'Homework', points: 30, origDate: '2025-11-05' }
  ];

  const toggleAssignment = (id: string) => {
    if (selectedAssignments.includes(id)) {
      setSelectedAssignments(selectedAssignments.filter((a) => a !== id));
    } else {
      setSelectedAssignments([...selectedAssignments, id]);
    }
  };

  const handleExecuteCopy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            CROSS-COURSE ASSIGNMENT COPY
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Copy assignments across courses with optional date shifting. Arrives unpublished with clean settings.
          </p>
        </div>

        <button
          onClick={handleExecuteCopy}
          disabled={selectedAssignments.length === 0}
          className={`px-4 py-2 border border-[#1B1C1A] font-mono font-bold text-xs uppercase rounded-[2px] flex items-center gap-2 transition-all ${
            selectedAssignments.length === 0
              ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
              : copied
              ? 'bg-[#FEF08A] text-[#1B1C1A]'
              : 'bg-[#2563EB] text-white hover:bg-blue-700'
          }`}
        >
          {copied ? (
            <>
              <Check className="w-4 h-4 text-[#059669]" />
              <span>COPIED TO {targetCourses.length} COURSES!</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              <span>COPY {selectedAssignments.length} ASSIGNMENTS</span>
            </>
          )}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Source Assignment Picker */}
        <div className="lg:col-span-7 bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-gray-200 pb-3 font-mono text-xs">
            <span className="font-bold text-[#1B1C1A] uppercase">
              1. SELECT SOURCE ASSIGNMENTS ({selectedAssignments.length} SELECTED)
            </span>
            <span className="text-gray-500">SOURCE: {sourceCourse}</span>
          </div>

          <div className="space-y-2">
            {availableAssignments.map((a) => {
              const isChecked = selectedAssignments.includes(a.id);
              return (
                <div
                  key={a.id}
                  onClick={() => toggleAssignment(a.id)}
                  className={`p-3 border rounded-[2px] cursor-pointer flex items-center justify-between transition-all ${
                    isChecked
                      ? 'bg-[#FAF9F5] border-[#1B1C1A] border-l-4 border-l-[#2563EB]'
                      : 'bg-white border-gray-300 hover:border-[#1B1C1A]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => {}}
                      className="w-4 h-4 accent-[#2563EB]"
                    />
                    <div>
                      <h4 className="font-bold text-sm text-[#1B1C1A]">{a.title}</h4>
                      <span className="text-[10px] font-mono text-gray-500">
                        {a.group} · {a.points} Points · Original Date: {a.origDate}
                      </span>
                    </div>
                  </div>

                  <span className="text-xs font-mono text-gray-600">
                    Shifted: +{dateOffsetDays} days
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Destination & Offset Config */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#EFEEEA] border border-[#1B1C1A] p-4 rounded-[2px] space-y-4 font-mono text-xs">
            <h3 className="font-bold uppercase text-[#1B1C1A] flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#2563EB]" />
              <span>2. SEMESTER DATE SHIFTING</span>
            </h3>

            <div>
              <label className="block text-[11px] font-bold text-gray-600 mb-1 uppercase">
                Date Offset (Days Forward)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={dateOffsetDays}
                  onChange={(e) => setDateOffsetDays(parseInt(e.target.value) || 0)}
                  className="w-full p-2 bg-white border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                />
                <span className="font-bold text-gray-600">DAYS</span>
              </div>
              <p className="text-[10px] text-gray-500 mt-1">
                Shifts due dates relative to original term offset.
              </p>
            </div>
          </div>

          <div className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] space-y-3 font-mono text-xs">
            <h3 className="font-bold uppercase text-[#1B1C1A] flex items-center gap-2 border-b border-gray-200 pb-2">
              <BookOpen className="w-4 h-4 text-[#059669]" />
              <span>3. DESTINATION COURSES</span>
            </h3>

            {targetCourses.map((c, idx) => (
              <div key={idx} className="p-2 bg-[#FAF9F5] border border-gray-300 font-bold text-[#1B1C1A] rounded-[1px] flex items-center justify-between">
                <span>{c}</span>
                <Check className="w-4 h-4 text-[#059669]" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
