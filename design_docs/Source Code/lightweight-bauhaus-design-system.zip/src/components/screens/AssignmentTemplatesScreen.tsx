import React, { useState } from 'react';
import {
  Copy,
  Plus,
  Search,
  SlidersHorizontal,
  Grid,
  List,
  Calendar,
  Clock,
  ArrowRight,
  ExternalLink,
  Check,
  X,
  Trash2,
  Edit2,
  Play,
  Share2,
  Code,
  Eye,
  AlertTriangle,
  CheckCircle2,
  FolderPlus,
  FileText,
  Layers,
  ChevronRight,
  BookOpen,
  Sparkles,
  Info,
  Send,
  HelpCircle
} from 'lucide-react';
import { ToggleSwitch } from '../ToggleSwitch';

export interface TemplateItem {
  id: string;
  type: 'assignment' | 'page';
  folderId: string; // 'quizzes' | 'labs' | 'pages' | 'unfiled'
  name: string;
  createdAt: string;
  lastUsed: string | null;
  sourceId: string | null;
  publishDefault: 'auto' | 'published' | 'unpublished';
  fields: {
    name: string;
    instructions: string;
    points?: number;
    submissionType?: 'online' | 'on_paper' | 'external_tool';
    allowedFormats?: string[];
    assignmentGroup?: string;
    gradingType?: 'points' | 'percentage' | 'letter_grade' | 'pass_fail';
    peerReview?: boolean;
    engine?: 'assignment' | 'new_quiz';
  };
}

export interface Folder {
  id: string;
  name: string;
  count: number;
}

const INITIAL_FOLDERS: Folder[] = [
  { id: 'all', name: 'All Templates', count: 5 },
  { id: 'quizzes', name: 'Quizzes & Assessments', count: 2 },
  { id: 'labs', name: 'Lab Reports & Essays', count: 2 },
  { id: 'pages', name: 'Discussions & Pages', count: 1 },
  { id: 'unfiled', name: 'Unfiled', count: 1 },
];

const INITIAL_TEMPLATES: TemplateItem[] = [
  {
    id: 'template_001',
    type: 'assignment',
    folderId: 'quizzes',
    name: 'Weekly Quiz Format',
    createdAt: '2026-06-01T10:00:00Z',
    lastUsed: '2026-07-20T14:30:00Z',
    sourceId: 'asn_9823',
    publishDefault: 'auto',
    fields: {
      name: 'Weekly Knowledge Check',
      instructions: `<div class="prose max-w-none text-xs leading-relaxed space-y-2">
  <h3 class="font-bold text-[#1B1C1A] text-sm">Weekly Reading & Concept Assessment</h3>
  <p class="text-gray-700">Please complete all 5 conceptual questions based on Chapter 4 reading material before the due date.</p>
  <ul class="list-disc pl-4 text-gray-600 space-y-1">
    <li>Answer concisely in 2-3 sentences per response.</li>
    <li>Upload your typed PDF notes or enter text directly in the box below.</li>
    <li>Cite at least one primary source diagram from the textbook.</li>
  </ul>
</div>`,
      points: 20,
      submissionType: 'online',
      allowedFormats: ['online_text_entry', 'online_upload'],
      assignmentGroup: 'Quizzes',
      gradingType: 'points',
      peerReview: false,
      engine: 'assignment',
    },
  },
  {
    id: 'template_002',
    type: 'assignment',
    folderId: 'labs',
    name: 'Scientific Lab Writeup Template',
    createdAt: '2026-05-12T09:15:00Z',
    lastUsed: '2026-07-15T11:00:00Z',
    sourceId: 'asn_4412',
    publishDefault: 'published',
    fields: {
      name: 'Lab Report: Experimental Analysis',
      instructions: `<div class="prose max-w-none text-xs leading-relaxed space-y-2">
  <h3 class="font-bold text-[#1B1C1A] text-sm">Standard 5-Section Scientific Report</h3>
  <p class="text-gray-700">Submit your structured laboratory write-up adhering to the required department template:</p>
  <ol class="list-decimal pl-4 text-gray-600 space-y-1">
    <li><strong>Abstract & Hypothesis:</strong> Concise summary of findings.</li>
    <li><strong>Materials & Methodology:</strong> Detailed procedure steps.</li>
    <li><strong>Data & Graphical Analysis:</strong> Include labeled chart figures.</li>
    <li><strong>Discussion & Sources of Error:</strong> Critical evaluation.</li>
  </ol>
</div>`,
      points: 50,
      submissionType: 'online',
      allowedFormats: ['online_upload'],
      assignmentGroup: 'Lab Reports',
      gradingType: 'points',
      peerReview: true,
      engine: 'assignment',
    },
  },
  {
    id: 'template_003',
    type: 'page',
    folderId: 'pages',
    name: 'Weekly Discussion Prompt',
    createdAt: '2026-06-18T16:00:00Z',
    lastUsed: '2026-06-28T08:45:00Z',
    sourceId: 'page_1102',
    publishDefault: 'auto',
    fields: {
      name: 'Discussion & Peer Reflection',
      instructions: `<div class="prose max-w-none text-xs leading-relaxed space-y-2">
  <h3 class="font-bold text-[#1B1C1A] text-sm">Reflection & Peer Dialogue Guidelines</h3>
  <p class="text-gray-700">Use this discussion page to post your initial reflection response by Wednesday at 11:59 PM.</p>
  <p class="text-gray-600 bg-[#FAF9F5] p-2 border border-[#1B1C1A] rounded-[2px]">
    <strong>Peer Review Requirement:</strong> Reply constructively to at least two classmates by Sunday evening to receive full participation credit.
  </p>
</div>`,
    },
  },
  {
    id: 'template_004',
    type: 'assignment',
    folderId: 'labs',
    name: 'Midterm Research Essay',
    createdAt: '2026-04-10T08:00:00Z',
    lastUsed: '2026-05-10T15:20:00Z',
    sourceId: 'asn_8890',
    publishDefault: 'unpublished',
    fields: {
      name: 'Midterm Synthesis Essay (1,500 Words)',
      instructions: `<div class="prose max-w-none text-xs leading-relaxed space-y-2">
  <h3 class="font-bold text-[#1B1C1A] text-sm">Synthesis Research Essay Specifications</h3>
  <p class="text-gray-700">Write a 1,500-word critical synthesis comparing modern educational technology frameworks against traditional LMS architectures.</p>
  <ul class="list-disc pl-4 text-gray-600 space-y-1">
    <li>Double-spaced, 12pt Times New Roman font, 1-inch margins.</li>
    <li>Must include minimum 4 peer-reviewed academic references.</li>
  </ul>
</div>`,
      points: 100,
      submissionType: 'online',
      allowedFormats: ['online_upload', 'online_text_entry'],
      assignmentGroup: 'Exams & Papers',
      gradingType: 'letter_grade',
      peerReview: false,
      engine: 'assignment',
    },
  },
  {
    id: 'template_005',
    type: 'assignment',
    folderId: 'unfiled',
    name: 'Syllabus Agreement Form',
    createdAt: '2026-07-01T12:00:00Z',
    lastUsed: null,
    sourceId: null,
    publishDefault: 'published',
    fields: {
      name: 'Course Policy & Syllabus Acknowledgement',
      instructions: `<div class="prose max-w-none text-xs leading-relaxed space-y-2">
  <p class="text-gray-700 font-medium">Please confirm that you have thoroughly read and understood all course policies outlined in the syllabus.</p>
  <p class="text-gray-600">Type <strong>"AGREED"</strong> in the submission box below to confirm compliance.</p>
</div>`,
      points: 5,
      submissionType: 'online',
      allowedFormats: ['online_text_entry'],
      assignmentGroup: 'General',
      gradingType: 'pass_fail',
      peerReview: false,
      engine: 'assignment',
    },
  },
];

const MOCK_COURSES = [
  { id: 'c1', name: 'Biology 101 — Principles of Life', term: 'Fall 2026', defaultGroup: 'Quizzes' },
  { id: 'c2', name: 'Cellular Biology 202', term: 'Fall 2026', defaultGroup: 'Weekly Quizzes' },
  { id: 'c3', name: 'Genetics & Genomics 301', term: 'Fall 2026', defaultGroup: 'Assignments' },
  { id: 'c4', name: 'Introductory Botany 105', term: 'Fall 2026', defaultGroup: 'Quizzes' },
  { id: 'c5', name: 'Organic Chemistry 210', term: 'Spring 2027', defaultGroup: 'Quizzes & Checks' },
];

export const AssignmentTemplatesScreen: React.FC = () => {
  // Navigation Modes within screen
  const [activeSurface, setActiveSurface] = useState<
    'library' | 'editor' | 'bulk-deploy' | 'save-modal' | 'create-dialog'
  >('library');

  // State
  const [templates, setTemplates] = useState<TemplateItem[]>(INITIAL_TEMPLATES);
  const [folders, setFolders] = useState<Folder[]>(INITIAL_FOLDERS);
  const [selectedFolder, setSelectedFolder] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [viewMode, setViewMode] = useState<'list' | 'card'>('list');
  const [sortBy, setSortBy] = useState<'lastUsed' | 'name' | 'createdAt'>('lastUsed');

  // Selected template for Edit or Deploy
  const [activeTemplate, setActiveTemplate] = useState<TemplateItem | null>(templates[0]);

  // Editor Form State
  const [editorForm, setEditorForm] = useState<TemplateItem>({
    id: '',
    type: 'assignment',
    folderId: 'quizzes',
    name: 'New Template Specification',
    createdAt: new Date().toISOString(),
    lastUsed: null,
    sourceId: null,
    publishDefault: 'auto',
    fields: {
      name: 'New Assignment Title',
      instructions: '<p>Enter assignment instructions and requirements here...</p>',
      points: 20,
      submissionType: 'online',
      allowedFormats: ['online_text_entry', 'online_upload'],
      assignmentGroup: 'Quizzes',
      gradingType: 'points',
      peerReview: false,
      engine: 'assignment',
    },
  });
  const [editorSourceView, setEditorSourceView] = useState(false);
  const [editorSavedNotification, setEditorSavedNotification] = useState(false);

  // Bulk Deployment State
  const [selectedCourseIds, setSelectedCourseIds] = useState<string[]>(['c1', 'c2', 'c3']);
  const [groupMappings, setGroupMappings] = useState<Record<string, string>>({
    c1: 'Quizzes',
    c2: 'Weekly Quizzes',
    c3: 'Assignments',
    c4: 'Quizzes',
    c5: 'Quizzes & Checks',
  });
  const [dueDateMode, setDueDateMode] = useState<'shared' | 'individual'>('shared');
  const [sharedDueDate, setSharedDueDate] = useState<string>('2026-09-15T23:59');
  const [individualDates, setIndividualDates] = useState<Record<string, string>>({
    c1: '2026-09-15T23:59',
    c2: '2026-09-16T23:59',
    c3: '2026-09-17T23:59',
    c4: '2026-09-18T23:59',
    c5: '2026-09-20T23:59',
  });
  const [deployPublishState, setDeployPublishState] = useState<'auto' | 'published' | 'unpublished'>('auto');
  const [isDeploying, setIsDeploying] = useState(false);
  const [deployResults, setDeployResults] = useState<{
    success: Array<{ courseName: string; groupName: string; status: string }>;
    failed: Array<{ courseName: string; reason: string }>;
  } | null>(null);

  // Injected Save Modal State
  const [saveModalTemplateName, setSaveModalTemplateName] = useState('Biology Lab Writeup Format');
  const [saveModalFolder, setSaveModalFolder] = useState('labs');
  const [saveModalCaptured, setSaveModalCaptured] = useState(false);

  // Injected Create Dialog State
  const [createDialogTemplateId, setCreateDialogTemplateId] = useState('template_001');
  const [createDialogDueDate, setCreateDialogDueDate] = useState('2026-09-20T23:59');
  const [createDialogPublish, setCreateDialogPublish] = useState<'auto' | 'published' | 'unpublished'>('auto');
  const [createDialogSuccess, setCreateDialogSuccess] = useState(false);

  // Filtered Templates
  const filteredTemplates = templates
    .filter((t) => {
      if (searchQuery) {
        return t.name.toLowerCase().includes(searchQuery.toLowerCase()) || t.fields.name.toLowerCase().includes(searchQuery.toLowerCase());
      }
      if (selectedFolder === 'all') return true;
      return t.folderId === selectedFolder;
    })
    .sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'createdAt') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      // lastUsed
      if (!a.lastUsed && !b.lastUsed) return 0;
      if (!a.lastUsed) return 1;
      if (!b.lastUsed) return -1;
      return new Date(b.lastUsed).getTime() - new Date(a.lastUsed).getTime();
    });

  // Handlers
  const handleOpenEditor = (template?: TemplateItem) => {
    if (template) {
      setEditorForm({ ...template });
      setActiveTemplate(template);
    } else {
      setEditorForm({
        id: `template_${Date.now()}`,
        type: 'assignment',
        folderId: selectedFolder === 'all' ? 'quizzes' : selectedFolder,
        name: 'New Assignment Template',
        createdAt: new Date().toISOString(),
        lastUsed: null,
        sourceId: null,
        publishDefault: 'auto',
        fields: {
          name: 'New Assignment Name',
          instructions: '<div class="space-y-2"><p>Standard instructions template text...</p></div>',
          points: 25,
          submissionType: 'online',
          allowedFormats: ['online_upload'],
          assignmentGroup: 'Quizzes',
          gradingType: 'points',
          peerReview: false,
          engine: 'assignment',
        },
      });
    }
    setActiveSurface('editor');
  };

  const handleSaveEditor = () => {
    const existingIndex = templates.findIndex((t) => t.id === editorForm.id);
    if (existingIndex >= 0) {
      const updated = [...templates];
      updated[existingIndex] = { ...editorForm };
      setTemplates(updated);
    } else {
      setTemplates([editorForm, ...templates]);
    }
    setEditorSavedNotification(true);
    setTimeout(() => {
      setEditorSavedNotification(false);
      setActiveSurface('library');
    }, 900);
  };

  const handleOpenDeploy = (template: TemplateItem) => {
    setActiveTemplate(template);
    setDeployResults(null);
    setActiveSurface('bulk-deploy');
  };

  const handleExecuteBulkDeploy = () => {
    setIsDeploying(true);
    setTimeout(() => {
      setIsDeploying(false);
      setDeployResults({
        success: selectedCourseIds.map((cid) => {
          const c = MOCK_COURSES.find((item) => item.id === cid);
          return {
            courseName: c ? c.name : cid,
            groupName: groupMappings[cid] || 'Quizzes',
            status: deployPublishState === 'published' ? 'PUBLISHED' : deployPublishState === 'unpublished' ? 'DRAFT' : 'AUTO (PUBLISHED)',
          };
        }),
        failed: [],
      });

      // Update template lastUsed timestamp
      if (activeTemplate) {
        setTemplates((prev) =>
          prev.map((t) => (t.id === activeTemplate.id ? { ...t, lastUsed: new Date().toISOString() } : t))
        );
      }
    }, 1200);
  };

  const handleDeleteTemplate = (id: string) => {
    if (window.confirm('Delete this template? This operation cannot be undone.')) {
      setTemplates(templates.filter((t) => t.id !== id));
      if (activeTemplate?.id === id) setActiveTemplate(null);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn font-sans text-[#1B1C1A]">
      {/* Top Banner Header */}
      <div className="border-b border-[#1B1C1A] pb-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-[#1B1C1A] uppercase">
            ASSIGNMENT TEMPLATES
          </h1>
          <p className="text-xs text-gray-600 mt-1 font-mono max-w-2xl">
            Capture assignment and page structures once — excluding course dates — and deploy into one or many Canvas courses with guaranteed gradebook group mapping.
          </p>
        </div>

        {/* Global Action Mode Switcher */}
        <div className="flex flex-wrap items-center gap-1.5 bg-[#EFEEEA] p-1.5 border border-[#1B1C1A] rounded-[2px] font-mono text-xs font-bold">
          <button
            onClick={() => setActiveSurface('library')}
            className={`px-3 py-1.5 rounded-[2px] border transition-all flex items-center gap-1.5 ${
              activeSurface === 'library'
                ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>LIBRARY</span>
          </button>

          <button
            onClick={() => handleOpenEditor()}
            className={`px-3 py-1.5 rounded-[2px] border transition-all flex items-center gap-1.5 ${
              activeSurface === 'editor'
                ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
          >
            <Plus className="w-3.5 h-3.5 text-[#FEF08A]" />
            <span>NEW TEMPLATE</span>
          </button>

          <button
            onClick={() => {
              if (templates.length > 0) handleOpenDeploy(templates[0]);
              else setActiveSurface('bulk-deploy');
            }}
            className={`px-3 py-1.5 rounded-[2px] border transition-all flex items-center gap-1.5 ${
              activeSurface === 'bulk-deploy'
                ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
          >
            <Send className="w-3.5 h-3.5 text-[#2563EB]" />
            <span>BULK DEPLOY</span>
          </button>

          {/* Injected Triggers */}
          <button
            onClick={() => setActiveSurface('save-modal')}
            className={`px-3 py-1.5 rounded-[2px] border transition-all flex items-center gap-1.5 ${
              activeSurface === 'save-modal'
                ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
            title="Simulate Injected Canvas Save Button"
          >
            <ExternalLink className="w-3.5 h-3.5 text-[#059669]" />
            <span>IN-CANVAS: SAVE</span>
          </button>

          <button
            onClick={() => setActiveSurface('create-dialog')}
            className={`px-3 py-1.5 rounded-[2px] border transition-all flex items-center gap-1.5 ${
              activeSurface === 'create-dialog'
                ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
                : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
            title="Simulate Injected Canvas Module Drop"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#B7102A]" />
            <span>IN-CANVAS: CREATE</span>
          </button>
        </div>
      </div>

      {/* SURFACE 1: TEMPLATE LIBRARY (DASHBOARD) */}
      {activeSurface === 'library' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 animate-fadeIn">
          {/* Left Folder Sidebar & Metrics */}
          <div className="lg:col-span-1 space-y-4">
            <div className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden">
              <div className="bg-[#EFEEEA] border-b border-[#1B1C1A] p-3 flex items-center justify-between font-mono text-xs font-bold uppercase">
                <span className="flex items-center gap-2">
                  <FolderPlus className="w-4 h-4 text-[#1B1C1A]" />
                  FOLDER ARCHITECTURE
                </span>
                <span className="px-1.5 py-0.5 bg-white border border-[#1B1C1A] text-[10px]">
                  {folders.length - 1} FOLDERS
                </span>
              </div>

              <div className="p-2 space-y-1 font-mono text-xs">
                {folders.map((f) => {
                  const isSelected = selectedFolder === f.id;
                  const count =
                    f.id === 'all'
                      ? templates.length
                      : templates.filter((t) => t.folderId === f.id).length;
                  return (
                    <button
                      key={f.id}
                      onClick={() => setSelectedFolder(f.id)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-[2px] border transition-all ${
                        isSelected
                          ? 'bg-[#1B1C1A] text-white border-[#1B1C1A] font-bold'
                          : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-[#FAF9F5]'
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <span
                          className={`w-2 h-2 rounded-[0px] border border-[#1B1C1A] ${
                            isSelected ? 'bg-[#FEF08A]' : 'bg-[#EFEEEA]'
                          }`}
                        />
                        <span className="truncate">{f.name}</span>
                      </div>
                      <span
                        className={`text-[10px] px-1.5 py-0.5 border ${
                          isSelected
                            ? 'bg-white text-[#1B1C1A] border-white font-bold'
                            : 'bg-[#EFEEEA] text-gray-700 border-[#1B1C1A]'
                        }`}
                      >
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Architecture Split Disclaimer Box */}
            <div className="bg-[#FAF9F5] border border-[#1B1C1A] p-4 rounded-[2px] space-y-2 text-xs">
              <div className="flex items-center gap-2 font-bold text-[#1B1C1A] uppercase font-mono border-b border-gray-300 pb-2">
                <Info className="w-4 h-4 text-[#2563EB]" />
                <span>ARCHITECTURAL DECISION #1</span>
              </div>
              <p className="text-gray-700 leading-relaxed text-[11px]">
                <strong>PowerTools Dashboard</strong> owns the Library and Bulk Deployment Engine (batch deploy to many courses at once).
              </p>
              <p className="text-gray-700 leading-relaxed text-[11px]">
                <strong>Injected Buttons</strong> in Canvas handle single, in-context captures and module drops.
              </p>
            </div>
          </div>

          {/* Right Template Main Viewport */}
          <div className="lg:col-span-3 space-y-4">
            {/* Filter Bar */}
            <div className="bg-[#EFEEEA] border border-[#1B1C1A] p-3 rounded-[2px] flex flex-wrap items-center justify-between gap-3 font-mono text-xs">
              {/* Search Field */}
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-3.5 h-3.5 text-gray-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="SEARCH TEMPLATES BY NAME OR FIELD..."
                  className="w-full bg-white border border-[#1B1C1A] pl-9 pr-3 py-1.5 text-xs font-mono rounded-[2px] outline-none focus:ring-1 focus:ring-[#2563EB]"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-2 text-gray-400 hover:text-[#1B1C1A]"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Sort & View Mode Controls */}
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 bg-white border border-[#1B1C1A] px-2 py-1 rounded-[2px]">
                  <SlidersHorizontal className="w-3 h-3 text-gray-600" />
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="bg-transparent text-xs font-mono font-bold text-[#1B1C1A] outline-none cursor-pointer uppercase"
                  >
                    <option value="lastUsed">SORT: RECENTLY USED</option>
                    <option value="name">SORT: ALPHABETICAL</option>
                    <option value="createdAt">SORT: DATE CREATED</option>
                  </select>
                </div>

                {/* View Mode Toggle (Grouped List vs Card Thumbnails) */}
                <div className="flex items-center border border-[#1B1C1A] bg-white rounded-[2px] p-0.5">
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-1.5 rounded-[1px] transition-colors ${
                      viewMode === 'list' ? 'bg-[#1B1C1A] text-white' : 'text-[#1B1C1A] hover:bg-[#EFEEEA]'
                    }`}
                    title="Grouped List View"
                  >
                    <List className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setViewMode('card')}
                    className={`p-1.5 rounded-[1px] transition-colors ${
                      viewMode === 'card' ? 'bg-[#1B1C1A] text-white' : 'text-[#1B1C1A] hover:bg-[#EFEEEA]'
                    }`}
                    title="HTML Preview Card View"
                  >
                    <Grid className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* List / Card Render View */}
            {filteredTemplates.length === 0 ? (
              <div className="bg-white border border-[#1B1C1A] p-12 text-center rounded-[2px] space-y-3 font-mono">
                <FileText className="w-10 h-10 text-gray-400 mx-auto" />
                <h3 className="text-sm font-bold uppercase text-[#1B1C1A]">NO TEMPLATES MATCHED YOUR FILTER</h3>
                <p className="text-xs text-gray-600">Try adjusting your search terms or create a new template from scratch.</p>
                <button
                  onClick={() => handleOpenEditor()}
                  className="px-4 py-2 bg-[#1B1C1A] text-white text-xs font-bold uppercase rounded-[2px] hover:bg-black"
                >
                  + CREATE NEW TEMPLATE
                </button>
              </div>
            ) : viewMode === 'list' ? (
              /* GROUPED LIST VIEW */
              <div className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden shadow-none">
                <div className="bg-[#FAF9F5] border-b border-[#1B1C1A] px-4 py-2.5 font-mono text-xs font-bold uppercase flex items-center justify-between">
                  <span>TEMPLATE LIBRARY SPECIMENS ({filteredTemplates.length})</span>
                  <span className="text-[10px] text-gray-500">NO DATES STORED // DEPLOY-TIME RESOLUTION</span>
                </div>

                <div className="divide-y divide-[#E3E2DF]">
                  {filteredTemplates.map((t) => (
                    <div
                      key={t.id}
                      className="p-4 hover:bg-[#FAF9F5] transition-colors flex flex-wrap items-center justify-between gap-4 font-mono text-xs"
                    >
                      <div className="space-y-1.5 flex-1 min-w-[260px]">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2 py-0.5 border border-[#1B1C1A] text-[10px] font-bold uppercase rounded-[1px] ${
                              t.type === 'assignment'
                                ? 'bg-[#DBEAFE] text-[#1E40AF]'
                                : 'bg-[#FEF08A] text-[#7A5500]'
                            }`}
                          >
                            {t.type.toUpperCase()}
                          </span>

                          <span className="font-bold text-sm text-[#1B1C1A] tracking-tight">{t.name}</span>
                        </div>

                        <div className="text-xs text-gray-600 flex flex-wrap items-center gap-x-4 gap-y-1">
                          <span>
                            Deployed Name: <strong className="text-[#1B1C1A]">{t.fields.name}</strong>
                          </span>
                          {t.type === 'assignment' && (
                            <>
                              <span>Points: <strong>{t.fields.points} pts</strong></span>
                              <span>Group: <strong>{t.fields.assignmentGroup || 'Unassigned'}</strong></span>
                            </>
                          )}
                          <span>
                            Publish Default: <strong className="uppercase">{t.publishDefault}</strong>
                          </span>
                        </div>

                        <div className="text-[10px] text-gray-400 flex items-center gap-3 pt-0.5">
                          <span>
                            Last Used: {t.lastUsed ? new Date(t.lastUsed).toLocaleDateString() : 'Never'}
                          </span>
                          <span>•</span>
                          <span>Source ID: {t.sourceId || 'None (Created from Scratch)'}</span>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => handleOpenDeploy(t)}
                          className="px-3 py-1.5 bg-[#1B1C1A] text-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-black transition-colors flex items-center gap-1.5"
                        >
                          <Send className="w-3.5 h-3.5 text-[#FEF08A]" />
                          <span>USE & DEPLOY</span>
                        </button>

                        <button
                          onClick={() => handleOpenEditor(t)}
                          className="p-1.5 bg-white border border-[#1B1C1A] text-[#1B1C1A] hover:bg-[#EFEEEA] rounded-[2px]"
                          title="Edit Template"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => handleDeleteTemplate(t.id)}
                          className="p-1.5 bg-white border border-[#1B1C1A] text-[#B7102A] hover:bg-[#FEF2F2] rounded-[2px]"
                          title="Delete Template"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              /* CARD VIEW WITH SCALED HTML DOCUMENT THUMBNAILS */
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredTemplates.map((t) => (
                  <div
                    key={t.id}
                    className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden flex flex-col justify-between hover:border-[#2563EB] transition-colors"
                  >
                    <div>
                      {/* Card Header */}
                      <div className="bg-[#EFEEEA] border-b border-[#1B1C1A] p-3 flex items-center justify-between font-mono text-xs">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-1.5 py-0.5 border border-[#1B1C1A] text-[9px] font-bold uppercase rounded-[1px] ${
                              t.type === 'assignment'
                                ? 'bg-[#DBEAFE] text-[#1E40AF]'
                                : 'bg-[#FEF08A] text-[#7A5500]'
                            }`}
                          >
                            {t.type}
                          </span>
                          <span className="font-bold text-[#1B1C1A] truncate max-w-[180px]">{t.name}</span>
                        </div>
                        <span className="text-[10px] text-gray-500">{t.fields.points ? `${t.fields.points} pts` : 'Page'}</span>
                      </div>

                      {/* Scaled Sanitized HTML Thumbnail Render */}
                      <div className="p-3 bg-[#FAF9F5] border-b border-[#1B1C1A] h-32 overflow-hidden relative font-sans">
                        <div className="text-[10px] text-gray-400 font-mono uppercase mb-1">
                          DEPLOYED TITLE: {t.fields.name}
                        </div>
                        <div
                          className="p-2.5 bg-white border border-gray-300 rounded-[2px] text-[11px] scale-95 origin-top-left pointer-events-none line-clamp-4 select-none opacity-90"
                          dangerouslySetInnerHTML={{ __html: t.fields.instructions }}
                        />
                        <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-[#FAF9F5] to-transparent pointer-events-none" />
                      </div>
                    </div>

                    {/* Card Actions Footer */}
                    <div className="p-3 bg-white flex items-center justify-between gap-2 font-mono text-xs border-t border-[#E3E2DF]">
                      <span className="text-[10px] text-gray-500 uppercase">
                        GROUP: {t.fields.assignmentGroup || 'UNASSIGNED'}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleOpenEditor(t)}
                          className="px-2 py-1 bg-white border border-[#1B1C1A] text-[10px] font-bold uppercase hover:bg-[#EFEEEA]"
                        >
                          EDIT
                        </button>
                        <button
                          onClick={() => handleOpenDeploy(t)}
                          className="px-2.5 py-1 bg-[#1B1C1A] text-white border border-[#1B1C1A] text-[10px] font-bold uppercase hover:bg-black flex items-center gap-1"
                        >
                          <Send className="w-3 h-3 text-[#FEF08A]" />
                          <span>USE</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SURFACE 2: TEMPLATE EDITOR (DASHBOARD) */}
      {activeSurface === 'editor' && (
        <div className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden space-y-0 animate-fadeIn">
          {/* Header Bar */}
          <div className="bg-[#EFEEEA] border-b border-[#1B1C1A] p-4 flex flex-wrap items-center justify-between gap-4 font-mono">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase text-gray-600">
                <Edit2 className="w-4 h-4 text-[#2563EB]" />
                <span>TEMPLATE EDITOR // STRUCTURAL SPECIFICATION</span>
              </div>
              <h2 className="text-xl font-bold text-[#1B1C1A] uppercase tracking-tight mt-0.5">
                {editorForm.id ? `EDITING: ${editorForm.name}` : 'CREATE NEW TEMPLATE'}
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveSurface('library')}
                className="px-3 py-1.5 bg-white border border-[#1B1C1A] text-xs font-mono font-bold uppercase rounded-[2px] hover:bg-[#FAF9F5]"
              >
                CANCEL
              </button>
              <button
                onClick={handleSaveEditor}
                className="px-4 py-1.5 bg-[#1B1C1A] text-white border border-[#1B1C1A] text-xs font-mono font-bold uppercase rounded-[2px] hover:bg-black flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5 text-[#FEF08A]" />
                <span>SAVE TEMPLATE</span>
              </button>
            </div>
          </div>

          {editorSavedNotification && (
            <div className="bg-[#CCFBF1] text-[#0F766E] border-b border-[#1B1C1A] p-3 text-xs font-mono font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>TEMPLATE SPECIFICATION SAVED SUCCESSFULLY TO LOCAL STORAGE!</span>
            </div>
          )}

          <div className="p-6 space-y-6">
            {/* Type & Folder Selection Bar */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px]">
              <div>
                <label className="block text-xs font-mono font-bold uppercase text-[#1B1C1A] mb-1.5">
                  TEMPLATE TYPE
                </label>
                <div className="flex items-center border border-[#1B1C1A] bg-white rounded-[2px] p-0.5 font-mono text-xs font-bold">
                  <button
                    type="button"
                    onClick={() => setEditorForm({ ...editorForm, type: 'assignment' })}
                    className={`flex-1 py-1.5 text-center uppercase transition-colors ${
                      editorForm.type === 'assignment' ? 'bg-[#1B1C1A] text-white' : 'text-[#1B1C1A] hover:bg-[#EFEEEA]'
                    }`}
                  >
                    ASSIGNMENT
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditorForm({ ...editorForm, type: 'page' })}
                    className={`flex-1 py-1.5 text-center uppercase transition-colors ${
                      editorForm.type === 'page' ? 'bg-[#1B1C1A] text-white' : 'text-[#1B1C1A] hover:bg-[#EFEEEA]'
                    }`}
                  >
                    CANVAS PAGE
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono font-bold uppercase text-[#1B1C1A] mb-1.5">
                  LIBRARY TEMPLATE NAME
                </label>
                <input
                  type="text"
                  value={editorForm.name}
                  onChange={(e) => setEditorForm({ ...editorForm, name: e.target.value })}
                  placeholder="e.g. Weekly Quiz Template"
                  className="w-full bg-white border border-[#1B1C1A] p-2 text-xs font-mono rounded-[2px] outline-none focus:ring-1 focus:ring-[#2563EB]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono font-bold uppercase text-[#1B1C1A] mb-1.5">
                  FOLDER CATEGORY
                </label>
                <select
                  value={editorForm.folderId}
                  onChange={(e) => setEditorForm({ ...editorForm, folderId: e.target.value })}
                  className="w-full bg-white border border-[#1B1C1A] p-2 text-xs font-mono font-bold uppercase rounded-[2px] outline-none"
                >
                  <option value="quizzes">QUIZZES & ASSESSMENTS</option>
                  <option value="labs">LAB REPORTS & ESSAYS</option>
                  <option value="pages">DISCUSSIONS & PAGES</option>
                  <option value="unfiled">UNFILED</option>
                </select>
              </div>
            </div>

            {/* Deployed Item Title */}
            <div>
              <label className="block text-xs font-mono font-bold uppercase text-[#1B1C1A] mb-1">
                DEPLOYED ITEM TITLE (CANVAS TITLE) *
              </label>
              <input
                type="text"
                value={editorForm.fields.name}
                onChange={(e) =>
                  setEditorForm({
                    ...editorForm,
                    fields: { ...editorForm.fields, name: e.target.value },
                  })
                }
                placeholder="e.g. Weekly Knowledge Check #1"
                className="w-full bg-white border border-[#1B1C1A] p-2.5 text-sm font-bold rounded-[2px] outline-none focus:ring-1 focus:ring-[#2563EB]"
              />
              <p className="text-[10px] font-mono text-gray-500 mt-1">
                This exact title will be used when creating the item in Canvas.
              </p>
            </div>

            {/* Instructions Field (Decision 5-7: Sanitized Read-only Render + HTML Source Toggle) */}
            <div className="border border-[#1B1C1A] rounded-[2px] overflow-hidden">
              <div className="bg-[#EFEEEA] border-b border-[#1B1C1A] p-3 flex items-center justify-between font-mono text-xs">
                <span className="font-bold uppercase text-[#1B1C1A]">INSTRUCTIONS BODY (CANVAS HTML)</span>
                <button
                  type="button"
                  onClick={() => setEditorSourceView(!editorSourceView)}
                  className="px-2.5 py-1 bg-white border border-[#1B1C1A] font-bold text-[10px] uppercase hover:bg-[#FAF9F5] flex items-center gap-1"
                >
                  <Code className="w-3 h-3 text-[#2563EB]" />
                  <span>{editorSourceView ? 'VIEW SANITIZED RENDER' : 'EDIT HTML SOURCE'}</span>
                </button>
              </div>

              {editorSourceView ? (
                <textarea
                  rows={8}
                  value={editorForm.fields.instructions}
                  onChange={(e) =>
                    setEditorForm({
                      ...editorForm,
                      fields: { ...editorForm.fields, instructions: e.target.value },
                    })
                  }
                  className="w-full p-3 font-mono text-xs bg-white outline-none focus:ring-1 focus:ring-[#2563EB]"
                />
              ) : (
                <div className="p-4 bg-white min-h-[140px] prose max-w-none text-xs">
                  <div dangerouslySetInnerHTML={{ __html: editorForm.fields.instructions }} />
                </div>
              )}
            </div>

            {/* Conditional Assignment-Only Fields */}
            {editorForm.type === 'assignment' && (
              <div className="space-y-4 pt-4 border-t border-[#1B1C1A]">
                <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[#1B1C1A] bg-[#EFEEEA] p-2 border border-[#1B1C1A] rounded-[2px]">
                  ASSIGNMENT SPECIFIC FIELDS
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Points */}
                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-[#1B1C1A] mb-1">
                      POINTS POSSIBLE
                    </label>
                    <input
                      type="number"
                      value={editorForm.fields.points || 0}
                      onChange={(e) =>
                        setEditorForm({
                          ...editorForm,
                          fields: { ...editorForm.fields, points: Number(e.target.value) },
                        })
                      }
                      className="w-full bg-white border border-[#1B1C1A] p-2 text-xs font-mono font-bold rounded-[2px] outline-none"
                    />
                  </div>

                  {/* Assignment Group Combobox (Decision 8) */}
                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-[#1B1C1A] mb-1">
                      ASSIGNMENT GROUP (NAME LABEL)
                    </label>
                    <input
                      type="text"
                      list="assignment-groups-list"
                      value={editorForm.fields.assignmentGroup || ''}
                      onChange={(e) =>
                        setEditorForm({
                          ...editorForm,
                          fields: { ...editorForm.fields, assignmentGroup: e.target.value },
                        })
                      }
                      placeholder="e.g. Quizzes, Homework, Exams"
                      className="w-full bg-white border border-[#1B1C1A] p-2 text-xs font-mono rounded-[2px] outline-none"
                    />
                    <datalist id="assignment-groups-list">
                      <option value="Quizzes" />
                      <option value="Assignments" />
                      <option value="Lab Reports" />
                      <option value="Exams & Papers" />
                      <option value="Homework" />
                    </datalist>
                    <p className="text-[10px] font-mono text-gray-500 mt-1">
                      Course-agnostic text label; resolved or created at deploy time.
                    </p>
                  </div>

                  {/* Grading Type */}
                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-[#1B1C1A] mb-1">
                      GRADING TYPE
                    </label>
                    <select
                      value={editorForm.fields.gradingType || 'points'}
                      onChange={(e) =>
                        setEditorForm({
                          ...editorForm,
                          fields: { ...editorForm.fields, gradingType: e.target.value as any },
                        })
                      }
                      className="w-full bg-white border border-[#1B1C1A] p-2 text-xs font-mono font-bold uppercase rounded-[2px] outline-none"
                    >
                      <option value="points">POINTS</option>
                      <option value="percentage">PERCENTAGE</option>
                      <option value="letter_grade">LETTER GRADE</option>
                      <option value="pass_fail">COMPLETE / INCOMPLETE</option>
                    </select>
                  </div>
                </div>

                {/* Peer Review & Submissions */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#FAF9F5] p-4 border border-[#1B1C1A] rounded-[2px]">
                  <div>
                    <span className="block text-xs font-mono font-bold uppercase text-[#1B1C1A] mb-2">
                      SUBMISSION TYPES
                    </span>
                    <div className="flex items-center gap-4 text-xs font-mono">
                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={editorForm.fields.allowedFormats?.includes('online_upload')}
                          onChange={(e) => {
                            const formats = editorForm.fields.allowedFormats || [];
                            const next = e.target.checked
                              ? [...formats, 'online_upload']
                              : formats.filter((f) => f !== 'online_upload');
                            setEditorForm({
                              ...editorForm,
                              fields: { ...editorForm.fields, allowedFormats: next },
                            });
                          }}
                          className="accent-[#B7102A]"
                        />
                        <span>FILE UPLOAD</span>
                      </label>

                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={editorForm.fields.allowedFormats?.includes('online_text_entry')}
                          onChange={(e) => {
                            const formats = editorForm.fields.allowedFormats || [];
                            const next = e.target.checked
                              ? [...formats, 'online_text_entry']
                              : formats.filter((f) => f !== 'online_text_entry');
                            setEditorForm({
                              ...editorForm,
                              fields: { ...editorForm.fields, allowedFormats: next },
                            });
                          }}
                          className="accent-[#B7102A]"
                        />
                        <span>TEXT ENTRY</span>
                      </label>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="block text-xs font-mono font-bold uppercase text-[#1B1C1A]">
                        PEER REVIEW ASSIGNMENT
                      </span>
                      <span className="text-[10px] font-mono text-gray-500">Require student peer reviews</span>
                    </div>
                    <ToggleSwitch
                      checked={!!editorForm.fields.peerReview}
                      onChange={(val) =>
                        setEditorForm({
                          ...editorForm,
                          fields: { ...editorForm.fields, peerReview: val },
                        })
                      }
                      variant="yellow"
                      size="md"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Firm Design Rule Disclaimer */}
            <div className="p-3 bg-[#FEF08A]/30 border border-[#1B1C1A] rounded-[2px] text-xs font-mono flex items-center justify-between">
              <span className="font-bold text-[#1B1C1A]">
                NO DATES STORED IN TEMPLATES (CORE PRODUCT RULE)
              </span>
              <span className="text-[10px] text-gray-600">
                Due Date, Available From & Until are set exclusively at deploy time.
              </span>
            </div>
          </div>
        </div>
      )}

      {/* SURFACE 3: BULK DEPLOYMENT ENGINE (DASHBOARD) */}
      {activeSurface === 'bulk-deploy' && (
        <div className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden space-y-0 animate-fadeIn">
          {/* Header Bar */}
          <div className="bg-[#EFEEEA] border-b border-[#1B1C1A] p-4 flex flex-wrap items-center justify-between gap-4 font-mono">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase text-gray-600">
                <Send className="w-4 h-4 text-[#2563EB]" />
                <span>BULK DEPLOYMENT ENGINE // MULTI-COURSE DISPATCH</span>
              </div>
              <h2 className="text-xl font-bold text-[#1B1C1A] uppercase tracking-tight mt-0.5">
                DEPLOY: {activeTemplate ? activeTemplate.name : 'NO TEMPLATE SELECTED'}
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveSurface('library')}
                className="px-3 py-1.5 bg-white border border-[#1B1C1A] text-xs font-mono font-bold uppercase rounded-[2px] hover:bg-[#FAF9F5]"
              >
                BACK TO LIBRARY
              </button>
              <button
                disabled={selectedCourseIds.length === 0 || isDeploying}
                onClick={handleExecuteBulkDeploy}
                className="px-5 py-1.5 bg-[#1B1C1A] text-white border border-[#1B1C1A] text-xs font-mono font-bold uppercase rounded-[2px] hover:bg-black disabled:opacity-50 flex items-center gap-2"
              >
                {isDeploying ? (
                  <span>DISPATCHING TO CANVAS...</span>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5 text-[#FEF08A]" />
                    <span>EXECUTE BULK DEPLOY ({selectedCourseIds.length} COURSES)</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {deployResults ? (
            /* DEPLOYMENT EXECUTION REPORT SUMMARY */
            <div className="p-6 space-y-6 animate-fadeIn">
              <div className="p-4 bg-[#CCFBF1] border border-[#1B1C1A] rounded-[2px] space-y-2 font-mono">
                <div className="flex items-center gap-2 text-sm font-bold text-[#0F766E] uppercase">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>BULK DEPLOYMENT COMPLETED SUCCESSFULLY</span>
                </div>
                <p className="text-xs text-[#0F766E]">
                  Deployed "{activeTemplate?.fields.name}" into {deployResults.success.length} Canvas courses with matched gradebook groups.
                </p>
              </div>

              <div className="border border-[#1B1C1A] rounded-[2px] overflow-hidden font-mono text-xs">
                <div className="bg-[#FAF9F5] border-b border-[#1B1C1A] p-3 font-bold uppercase">
                  DEPLOYED COURSES AUDIT LOG
                </div>
                <div className="divide-y divide-[#E3E2DF]">
                  {deployResults.success.map((res, i) => (
                    <div key={i} className="p-3 flex items-center justify-between">
                      <span className="font-bold text-[#1B1C1A]">{res.courseName}</span>
                      <div className="flex items-center gap-3">
                        <span className="text-gray-600">Group: <strong>{res.groupName}</strong></span>
                        <span className="px-2 py-0.5 bg-[#CCFBF1] text-[#0F766E] border border-[#1B1C1A] text-[10px] font-bold">
                          {res.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  onClick={() => setActiveSurface('library')}
                  className="px-4 py-2 bg-white border border-[#1B1C1A] font-mono font-bold text-xs uppercase hover:bg-[#FAF9F5]"
                >
                  RETURN TO TEMPLATES LIBRARY
                </button>
              </div>
            </div>
          ) : (
            /* CONFIGURATION FORM */
            <div className="p-6 space-y-6">
              {/* Step 1: Select Target Courses */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-2 font-mono">
                  <span className="text-xs font-bold uppercase text-[#1B1C1A]">
                    1. SELECT TARGET COURSES ({selectedCourseIds.length} OF {MOCK_COURSES.length} SELECTED)
                  </span>
                  <button
                    onClick={() => {
                      if (selectedCourseIds.length === MOCK_COURSES.length) setSelectedCourseIds([]);
                      else setSelectedCourseIds(MOCK_COURSES.map((c) => c.id));
                    }}
                    className="text-[11px] font-bold uppercase text-[#2563EB] hover:underline"
                  >
                    {selectedCourseIds.length === MOCK_COURSES.length ? 'DESELECT ALL' : 'SELECT ALL'}
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 font-mono text-xs">
                  {MOCK_COURSES.map((c) => {
                    const isChecked = selectedCourseIds.includes(c.id);
                    return (
                      <div
                        key={c.id}
                        onClick={() => {
                          if (isChecked) setSelectedCourseIds(selectedCourseIds.filter((id) => id !== c.id));
                          else setSelectedCourseIds([...selectedCourseIds, c.id]);
                        }}
                        className={`p-3 border rounded-[2px] cursor-pointer transition-colors flex items-start gap-2.5 ${
                          isChecked ? 'bg-[#FAF9F5] border-[#1B1C1A]' : 'bg-white border-gray-300 opacity-60'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="mt-0.5 accent-[#B7102A]"
                        />
                        <div className="space-y-0.5">
                          <div className="font-bold text-[#1B1C1A]">{c.name}</div>
                          <div className="text-[10px] text-gray-500 uppercase">{c.term}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Step 2: Assignment Group Mapping (Decision 9) */}
              <div className="space-y-3 pt-2 border-t border-[#1B1C1A]">
                <div className="font-mono text-xs font-bold uppercase text-[#1B1C1A]">
                  2. ASSIGNMENT GROUP MAPPING (PER-COURSE GRADEBOOK BUCKETS)
                </div>
                <p className="text-xs text-gray-600 font-mono">
                  Each selected course shows a group selector pre-filled with a name match or falling back to top groups. Created automatically if not found.
                </p>

                <div className="bg-[#FAF9F5] border border-[#1B1C1A] p-4 rounded-[2px] divide-y divide-gray-300 font-mono text-xs">
                  {selectedCourseIds.map((cid) => {
                    const c = MOCK_COURSES.find((item) => item.id === cid);
                    return (
                      <div key={cid} className="py-2.5 first:pt-0 last:pb-0 flex flex-wrap items-center justify-between gap-2">
                        <span className="font-bold text-[#1B1C1A]">{c?.name}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-gray-500">GRADEBOOK GROUP:</span>
                          <input
                            type="text"
                            value={groupMappings[cid] || ''}
                            onChange={(e) =>
                              setGroupMappings({ ...groupMappings, [cid]: e.target.value })
                            }
                            className="bg-white border border-[#1B1C1A] px-2 py-1 text-xs font-bold rounded-[2px] outline-none w-48"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Step 3: Date Handling & Publish Mode */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2 border-t border-[#1B1C1A] font-mono text-xs">
                <div>
                  <div className="font-bold uppercase text-[#1B1C1A] mb-2">3. DEPLOYMENT DUE DATE SETTINGS</div>
                  <div className="space-y-3 bg-[#FAF9F5] p-3.5 border border-[#1B1C1A] rounded-[2px]">
                    <div className="flex items-center gap-4">
                      <label className="flex items-center gap-1.5 cursor-pointer font-bold">
                        <input
                          type="radio"
                          name="date-mode"
                          checked={dueDateMode === 'shared'}
                          onChange={() => setDueDateMode('shared')}
                          className="accent-[#B7102A]"
                        />
                        <span>SHARED DATE FOR ALL</span>
                      </label>
                      <label className="flex items-center gap-1.5 cursor-pointer font-bold">
                        <input
                          type="radio"
                          name="date-mode"
                          checked={dueDateMode === 'individual'}
                          onChange={() => setDueDateMode('individual')}
                          className="accent-[#B7102A]"
                        />
                        <span>INDIVIDUAL PER COURSE</span>
                      </label>
                    </div>

                    {dueDateMode === 'shared' ? (
                      <div>
                        <label className="block text-[10px] font-bold uppercase text-gray-600 mb-1">
                          ALL COURSES DUE DATE
                        </label>
                        <input
                          type="datetime-local"
                          value={sharedDueDate}
                          onChange={(e) => setSharedDueDate(e.target.value)}
                          className="w-full bg-white border border-[#1B1C1A] p-2 rounded-[2px] outline-none font-mono text-xs"
                        />
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                        {selectedCourseIds.map((cid) => (
                          <div key={cid} className="flex items-center justify-between text-[11px]">
                            <span className="truncate max-w-[160px]">
                              {MOCK_COURSES.find((item) => item.id === cid)?.name}
                            </span>
                            <input
                              type="datetime-local"
                              value={individualDates[cid] || '2026-09-15T23:59'}
                              onChange={(e) =>
                                setIndividualDates({ ...individualDates, [cid]: e.target.value })
                              }
                              className="bg-white border border-[#1B1C1A] px-1.5 py-0.5 text-[10px]"
                            />
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <div className="font-bold uppercase text-[#1B1C1A] mb-2">4. PUBLISH PREFERENCE (DECISION 10)</div>
                  <div className="space-y-2 bg-[#FAF9F5] p-3.5 border border-[#1B1C1A] rounded-[2px]">
                    <label className="flex items-start gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="deploy-publish"
                        checked={deployPublishState === 'auto'}
                        onChange={() => setDeployPublishState('auto')}
                        className="mt-0.5 accent-[#B7102A]"
                      />
                      <div>
                        <span className="font-bold uppercase text-[#1B1C1A]">AUTO (RECOMMENDED)</span>
                        <p className="text-[10px] text-gray-600">Publish if a due date is provided, otherwise leave as draft.</p>
                      </div>
                    </label>

                    <label className="flex items-start gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="deploy-publish"
                        checked={deployPublishState === 'published'}
                        onChange={() => setDeployPublishState('published')}
                        className="mt-0.5 accent-[#B7102A]"
                      />
                      <div>
                        <span className="font-bold uppercase text-[#1B1C1A]">FORCE PUBLISHED</span>
                        <p className="text-[10px] text-gray-600">Immediately visible to students in all target courses.</p>
                      </div>
                    </label>

                    <label className="flex items-start gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="deploy-publish"
                        checked={deployPublishState === 'unpublished'}
                        onChange={() => setDeployPublishState('unpublished')}
                        className="mt-0.5 accent-[#B7102A]"
                      />
                      <div>
                        <span className="font-bold uppercase text-[#1B1C1A]">FORCE UNPUBLISHED DRAFT</span>
                        <p className="text-[10px] text-gray-600">Save as unpublished draft across all courses.</p>
                      </div>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SURFACE 4: INJECTED "SAVE TO TEMPLATES" MODAL (CANVAS CAPTURE CONTEXT) */}
      {activeSurface === 'save-modal' && (
        <div className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden animate-fadeIn">
          <div className="bg-[#EFEEEA] border-b border-[#1B1C1A] p-4 flex items-center justify-between font-mono">
            <div>
              <span className="text-[10px] font-bold bg-[#FEF08A] border border-[#1B1C1A] px-1.5 py-0.5 uppercase">
                INJECTED CANVAS OVERLAY
              </span>
              <h2 className="text-lg font-bold uppercase text-[#1B1C1A] mt-1">SAVE TO TEMPLATES (IN-CONTEXT CAPTURE)</h2>
            </div>
            <button
              onClick={() => setActiveSurface('library')}
              className="px-3 py-1 bg-white border border-[#1B1C1A] font-bold text-xs uppercase hover:bg-[#FAF9F5]"
            >
              CLOSE DEMO
            </button>
          </div>

          <div className="p-6 max-w-xl mx-auto space-y-5 font-mono text-xs">
            {saveModalCaptured ? (
              <div className="p-4 bg-[#CCFBF1] border border-[#1B1C1A] rounded-[2px] text-center space-y-3">
                <CheckCircle2 className="w-8 h-8 text-[#0F766E] mx-auto" />
                <h3 className="font-bold text-sm text-[#0F766E] uppercase">TEMPLATE CAPTURED SUCCESSFULLY</h3>
                <p className="text-xs text-[#0F766E]">
                  "{saveModalTemplateName}" has been written verbatim to local storage and index synced.
                </p>
                <button
                  onClick={() => {
                    setSaveModalCaptured(false);
                    setActiveSurface('library');
                  }}
                  className="px-4 py-1.5 bg-[#1B1C1A] text-white font-bold uppercase rounded-[2px]"
                >
                  VIEW IN TEMPLATE LIBRARY
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-3 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px]">
                  <div className="text-[10px] text-gray-500 uppercase">CURRENT CANVAS PAGE:</div>
                  <div className="font-bold text-[#1B1C1A] text-sm">Biology 101 // Lab Report #4 Spec</div>
                </div>

                <div>
                  <label className="block font-bold uppercase text-[#1B1C1A] mb-1">NEW TEMPLATE NAME</label>
                  <input
                    type="text"
                    value={saveModalTemplateName}
                    onChange={(e) => setSaveModalTemplateName(e.target.value)}
                    className="w-full bg-white border border-[#1B1C1A] p-2 font-mono text-xs rounded-[2px] outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold uppercase text-[#1B1C1A] mb-1">DESTINATION FOLDER</label>
                  <select
                    value={saveModalFolder}
                    onChange={(e) => setSaveModalFolder(e.target.value)}
                    className="w-full bg-white border border-[#1B1C1A] p-2 font-mono text-xs font-bold uppercase rounded-[2px]"
                  >
                    <option value="labs">LAB REPORTS & ESSAYS</option>
                    <option value="quizzes">QUIZZES & ASSESSMENTS</option>
                    <option value="pages">DISCUSSIONS & PAGES</option>
                  </select>
                </div>

                {/* Explicit Checklist of Saved vs Excluded Fields */}
                <div className="border border-[#1B1C1A] p-3 rounded-[2px] bg-[#FAF9F5] space-y-2">
                  <span className="font-bold uppercase text-[#1B1C1A] block border-b border-gray-300 pb-1">
                    EXPLICIT CAPTURE CHECKLIST
                  </span>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="space-y-1 text-emerald-700">
                      <div className="flex items-center gap-1 font-bold">
                        <Check className="w-3 h-3" /> SAVED: Title & Instructions
                      </div>
                      <div className="flex items-center gap-1 font-bold">
                        <Check className="w-3 h-3" /> SAVED: Points & Formats
                      </div>
                      <div className="flex items-center gap-1 font-bold">
                        <Check className="w-3 h-3" /> SAVED: Group Label
                      </div>
                    </div>

                    <div className="space-y-1 text-red-700">
                      <div className="flex items-center gap-1 font-bold">
                        <X className="w-3 h-3" /> EXCLUDED: Due Date
                      </div>
                      <div className="flex items-center gap-1 font-bold">
                        <X className="w-3 h-3" /> EXCLUDED: Available From
                      </div>
                      <div className="flex items-center gap-1 font-bold">
                        <X className="w-3 h-3" /> EXCLUDED: Available Until
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setSaveModalCaptured(true)}
                  className="w-full py-2.5 bg-[#1B1C1A] text-white font-bold uppercase rounded-[2px] hover:bg-black transition-colors flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4 text-[#FEF08A]" />
                  <span>CAPTURE TO TEMPLATE LIBRARY</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SURFACE 5: INJECTED "CREATE FROM TEMPLATE" DIALOG (CANVAS MODULE SINGLE DEPLOY) */}
      {activeSurface === 'create-dialog' && (
        <div className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden animate-fadeIn">
          <div className="bg-[#EFEEEA] border-b border-[#1B1C1A] p-4 flex items-center justify-between font-mono">
            <div>
              <span className="text-[10px] font-bold bg-[#FEF08A] border border-[#1B1C1A] px-1.5 py-0.5 uppercase">
                INJECTED MODULE DIALOG
              </span>
              <h2 className="text-lg font-bold uppercase text-[#1B1C1A] mt-1">
                CREATE FROM TEMPLATE (SINGLE MODULE DROP)
              </h2>
            </div>
            <button
              onClick={() => setActiveSurface('library')}
              className="px-3 py-1 bg-white border border-[#1B1C1A] font-bold text-xs uppercase hover:bg-[#FAF9F5]"
            >
              CLOSE DEMO
            </button>
          </div>

          <div className="p-6 max-w-xl mx-auto space-y-5 font-mono text-xs">
            {createDialogSuccess ? (
              <div className="p-4 bg-[#CCFBF1] border border-[#1B1C1A] rounded-[2px] text-center space-y-3">
                <CheckCircle2 className="w-8 h-8 text-[#0F766E] mx-auto" />
                <h3 className="font-bold text-sm text-[#0F766E] uppercase">ASSIGNMENT CREATED IN MODULE</h3>
                <p className="text-xs text-[#0F766E]">
                  Successfully created and linked inside Canvas Module 02: Molecular Dynamics.
                </p>
                <button
                  onClick={() => {
                    setCreateDialogSuccess(false);
                    setActiveSurface('library');
                  }}
                  className="px-4 py-1.5 bg-[#1B1C1A] text-white font-bold uppercase rounded-[2px]"
                >
                  DONE
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-3 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px]">
                  <div className="text-[10px] text-gray-500 uppercase">TARGET CANVAS MODULE:</div>
                  <div className="font-bold text-[#1B1C1A] text-sm">Module 02: Molecular Dynamics</div>
                </div>

                <div>
                  <label className="block font-bold uppercase text-[#1B1C1A] mb-1">SELECT TEMPLATE SPECIMEN</label>
                  <select
                    value={createDialogTemplateId}
                    onChange={(e) => setCreateDialogTemplateId(e.target.value)}
                    className="w-full bg-white border border-[#1B1C1A] p-2.5 font-mono text-xs font-bold uppercase rounded-[2px]"
                  >
                    {templates.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} ({t.type.toUpperCase()})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold uppercase text-[#1B1C1A] mb-1">OPTIONAL DUE DATE</label>
                  <input
                    type="datetime-local"
                    value={createDialogDueDate}
                    onChange={(e) => setCreateDialogDueDate(e.target.value)}
                    className="w-full bg-white border border-[#1B1C1A] p-2 font-mono text-xs rounded-[2px]"
                  />
                </div>

                <div>
                  <label className="block font-bold uppercase text-[#1B1C1A] mb-1">PUBLISH PREFERENCE</label>
                  <div className="flex items-center gap-3 font-mono">
                    <label className="flex items-center gap-1.5 cursor-pointer font-bold">
                      <input
                        type="radio"
                        name="create-pub"
                        checked={createDialogPublish === 'auto'}
                        onChange={() => setCreateDialogPublish('auto')}
                        className="accent-[#B7102A]"
                      />
                      <span>AUTO</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer font-bold">
                      <input
                        type="radio"
                        name="create-pub"
                        checked={createDialogPublish === 'published'}
                        onChange={() => setCreateDialogPublish('published')}
                        className="accent-[#B7102A]"
                      />
                      <span>PUBLISHED</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer font-bold">
                      <input
                        type="radio"
                        name="create-pub"
                        checked={createDialogPublish === 'unpublished'}
                        onChange={() => setCreateDialogPublish('unpublished')}
                        className="accent-[#B7102A]"
                      />
                      <span>UNPUBLISHED</span>
                    </label>
                  </div>
                </div>

                <button
                  onClick={() => setCreateDialogSuccess(true)}
                  className="w-full py-2.5 bg-[#1B1C1A] text-white font-bold uppercase rounded-[2px] hover:bg-black transition-colors flex items-center justify-center gap-2"
                >
                  <Sparkles className="w-4 h-4 text-[#FEF08A]" />
                  <span>CREATE AND INJECT INTO MODULE</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
