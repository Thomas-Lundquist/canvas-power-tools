import React, { useState } from 'react';
import { INITIAL_ASSIGNMENTS } from '../../data/mockData';
import { Assignment } from '../../types';
import {
  Download,
  Plus,
  Filter,
  Calendar,
  FileText,
  CheckCircle,
  HelpCircle,
  Edit2,
  Trash2,
  Copy,
  Check,
  Sparkles,
  Sliders
} from 'lucide-react';
import { AssignmentEditorModal } from '../AssignmentEditorModal';

export const BulkEditorScreen: React.FC = () => {
  const [assignments, setAssignments] = useState<Assignment[]>(INITIAL_ASSIGNMENTS);
  const [activeCourseFilter, setActiveCourseFilter] = useState('CS101');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [groupFilter, setGroupFilter] = useState('ALL');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState<Assignment | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  const toggleSelect = (id: string) => {
    setAssignments(
      assignments.map((a) => (a.id === id ? { ...a, checked: !a.checked } : a))
    );
  };

  const toggleStatus = (id: string) => {
    setAssignments(
      assignments.map((a) =>
        a.id === id
          ? { ...a, status: a.status === 'PUBLISHED' ? 'UNPUBLISHED' : 'PUBLISHED' }
          : a
      )
    );
  };

  const handleOpenNewEditor = () => {
    setEditingAssignment(null);
    setIsModalOpen(true);
  };

  const handleOpenEditEditor = (asn: Assignment) => {
    setEditingAssignment(asn);
    setIsModalOpen(true);
  };

  const handleSaveAssignment = (savedAsn: Assignment) => {
    if (editingAssignment) {
      // Update existing
      setAssignments(prev =>
        prev.map(a => (a.id === savedAsn.id ? savedAsn : a))
      );
      showToast(`ASSIGNMENT "${savedAsn.title.toUpperCase()}" UPDATED SUCCESSFULLY!`);
    } else {
      // Add new
      setAssignments(prev => [savedAsn, ...prev]);
      showToast(`NEW ASSIGNMENT "${savedAsn.title.toUpperCase()}" CREATED & SYNCED!`);
    }
  };

  const handleDuplicate = (asn: Assignment) => {
    const dup: Assignment = {
      ...asn,
      id: `asn-${Date.now()}`,
      title: `${asn.title} (COPY)`,
      asnId: `ASGN-2026-0${Math.floor(Math.random() * 80 + 20)}`,
      status: 'UNPUBLISHED',
      checked: false
    };
    setAssignments([dup, ...assignments]);
    showToast(`DUPLICATED ASSIGNMENT "${asn.title.toUpperCase()}"`);
  };

  const handleDelete = (id: string, title: string) => {
    setAssignments(assignments.filter(a => a.id !== id));
    showToast(`DELETED "${title.toUpperCase()}" FROM CANVAS`);
  };

  const handleBulkPublish = () => {
    setAssignments(
      assignments.map(a => (a.checked ? { ...a, status: 'PUBLISHED' } : a))
    );
    showToast(`BULK PUBLISHED SELECTED ASSIGNMENTS`);
  };

  const handleBulkUnpublish = () => {
    setAssignments(
      assignments.map(a => (a.checked ? { ...a, status: 'UNPUBLISHED' } : a))
    );
    showToast(`BULK UNPUBLISHED SELECTED ASSIGNMENTS`);
  };

  const handleExportCSV = () => {
    const jsonStr = JSON.stringify(assignments, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `canvas_assignments_export_${Date.now()}.json`;
    a.click();
    showToast('EXPORTED ASSIGNMENTS MATRIX JSON');
  };

  // Filter logic
  const filteredAssignments = assignments.filter((a) => {
    if (statusFilter !== 'ALL' && a.status !== statusFilter) return false;
    if (groupFilter !== 'ALL' && a.group !== groupFilter) return false;
    return true;
  });

  const selectedCount = assignments.filter((a) => a.checked).length;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="bg-[#FEF08A] border-2 border-[#1B1C1A] p-3 rounded-[2px] font-mono text-xs font-bold text-[#1B1C1A] flex items-center justify-between shadow-xs animate-bounce">
          <div className="flex items-center gap-2 uppercase">
            <CheckCircle className="w-4 h-4 text-[#2563EB]" />
            <span>{toastMessage}</span>
          </div>
          <button onClick={() => setToastMessage(null)} className="hover:text-red-700">✕</button>
        </div>
      )}

      {/* Top Banner Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1B1C1A] pb-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-black text-[#1B1C1A] tracking-tight uppercase">
            BULK ASSIGNMENT EDITOR
          </h1>
          <p className="text-xs text-gray-600 mt-1 font-mono">
            Modify multiple assignment dates, groups, visibility states, or author new Canvas assignments in one view.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-3 py-1.5 bg-white border border-[#1B1C1A] text-xs font-mono font-bold uppercase rounded-[2px] hover:bg-[#EFEEEA] flex items-center gap-1.5 shadow-xs transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>EXPORT MATRIX</span>
          </button>

          <button
            onClick={handleOpenNewEditor}
            className="px-4 py-1.5 bg-[#2563EB] text-white border border-[#1B1C1A] text-xs font-mono font-bold uppercase tracking-wider rounded-[2px] hover:bg-[#1D4ED8] flex items-center gap-1.5 shadow-xs transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>NEW ASSIGNMENT</span>
          </button>
        </div>
      </div>

      {/* Filter Control Bar */}
      <div className="bg-[#FAF9F5] border border-[#1B1C1A] p-3 rounded-[2px] flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-bold text-[#1B1C1A] uppercase tracking-wider text-xs flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-[#2563EB]" />
            <span>FILTERS:</span>
          </span>

          {/* Active Filter Badge */}
          <div className="bg-[#BFDBFE] text-[#1E40AF] border border-[#1B1C1A] px-2.5 py-1 rounded-[2px] font-bold text-xs uppercase flex items-center gap-1.5">
            <span>COURSE: {activeCourseFilter}</span>
            <button onClick={() => setActiveCourseFilter('ALL')} className="hover:text-black">
              ✕
            </button>
          </div>

          {/* Status Dropdown */}
          <div className="relative">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-white border border-[#1B1C1A] text-xs font-bold px-2.5 py-1 rounded-[2px] focus:outline-none uppercase"
            >
              <option value="ALL">STATUS: ALL</option>
              <option value="PUBLISHED">STATUS: PUBLISHED</option>
              <option value="UNPUBLISHED">STATUS: UNPUBLISHED</option>
            </select>
          </div>

          {/* Group Dropdown */}
          <div className="relative">
            <select
              value={groupFilter}
              onChange={(e) => setGroupFilter(e.target.value)}
              className="bg-white border border-[#1B1C1A] text-xs font-bold px-2.5 py-1 rounded-[2px] focus:outline-none uppercase"
            >
              <option value="ALL">GROUP: ALL</option>
              <option value="PROJECTS">GROUP: PROJECTS</option>
              <option value="EXAMS">GROUP: EXAMS</option>
              <option value="HOMEWORK">GROUP: HOMEWORK</option>
              <option value="LABS">GROUP: LABS</option>
              <option value="QUIZZES">GROUP: QUIZZES</option>
            </select>
          </div>
        </div>

        <div className="text-xs font-mono font-bold text-gray-600">
          SHOWING: <span className="text-[#2563EB]">{filteredAssignments.length} OF {assignments.length}</span>
        </div>
      </div>

      {selectedCount > 0 && (
        <div className="bg-[#BFDBFE] border border-[#1B1C1A] p-3 rounded-[2px] flex flex-wrap items-center justify-between text-xs font-mono font-bold text-[#1E40AF]">
          <span>{selectedCount} ASSIGNMENT(S) SELECTED FOR BULK ACTION</span>
          <div className="flex gap-2">
            <button
              onClick={handleBulkPublish}
              className="px-3 py-1 bg-[#2563EB] text-white border border-[#1B1C1A] hover:bg-blue-700 text-xs font-bold uppercase rounded-[1px]"
            >
              BULK PUBLISH
            </button>
            <button
              onClick={handleBulkUnpublish}
              className="px-3 py-1 bg-white text-[#1B1C1A] border border-[#1B1C1A] hover:bg-gray-100 text-xs font-bold uppercase rounded-[1px]"
            >
              BULK UNPUBLISH
            </button>
          </div>
        </div>
      )}

      {/* Main Assignment Table with Squared Gridlines */}
      <div className="bg-white border-2 border-[#1B1C1A] rounded-[2px] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#EFEEEA] border-b border-[#1B1C1A] text-xs font-mono font-bold text-[#1B1C1A] uppercase tracking-wider">
                <th className="py-2.5 px-3 border-r border-[#1B1C1A] w-10 text-center">
                  <input
                    type="checkbox"
                    checked={filteredAssignments.length > 0 && filteredAssignments.every((a) => a.checked)}
                    onChange={() => {
                      const allChecked = filteredAssignments.every((a) => a.checked);
                      setAssignments(assignments.map((a) => ({ ...a, checked: !allChecked })));
                    }}
                    className="accent-[#2563EB]"
                  />
                </th>
                <th className="py-2.5 px-4 border-r border-[#1B1C1A]">TITLE & ID</th>
                <th className="py-2.5 px-4 border-r border-[#1B1C1A]">GROUP</th>
                <th className="py-2.5 px-4 border-r border-[#1B1C1A]">DUE DATE</th>
                <th className="py-2.5 px-4 border-r border-[#1B1C1A] text-center">STATUS</th>
                <th className="py-2.5 px-4 text-center">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1B1C1A] text-xs font-mono">
              {filteredAssignments.map((asn) => (
                <tr
                  key={asn.id}
                  className={`transition-colors ${
                    asn.checked ? 'bg-[#EFF6FF]' : 'hover:bg-[#FAF9F5]'
                  }`}
                >
                  {/* Select Checkbox */}
                  <td className="py-3 px-3 border-r border-[#1B1C1A] text-center">
                    <input
                      type="checkbox"
                      checked={!!asn.checked}
                      onChange={() => toggleSelect(asn.id)}
                      className="accent-[#2563EB] cursor-pointer"
                    />
                  </td>

                  {/* Title & ID */}
                  <td className="py-3 px-4 border-r border-[#1B1C1A]">
                    <div className="flex items-center gap-2.5">
                      <FileText className="w-4 h-4 text-[#2563EB] shrink-0" />
                      <div>
                        <button
                          onClick={() => handleOpenEditEditor(asn)}
                          className="font-bold text-[#1B1C1A] hover:text-[#2563EB] hover:underline text-left block"
                        >
                          {asn.title}
                        </button>
                        <div className="text-[10px] font-mono text-gray-500">ID: {asn.asnId}</div>
                      </div>
                    </div>
                  </td>

                  {/* Group Pill */}
                  <td className="py-3 px-4 border-r border-[#1B1C1A]">
                    <span className="inline-block px-2 py-0.5 border border-[#1B1C1A] text-xs font-mono font-bold uppercase rounded-[2px] bg-[#FAF9F5]">
                      {asn.group}
                    </span>
                  </td>

                  {/* Due Date */}
                  <td className="py-3 px-4 border-r border-[#1B1C1A] font-mono">
                    <div className="flex items-center gap-1.5 text-xs text-[#1B1C1A]">
                      <Calendar className="w-3.5 h-3.5 text-[#B7102A]" />
                      <span>{asn.dueDate}</span>
                    </div>
                  </td>

                  {/* Publication Status Badge */}
                  <td className="py-3 px-4 border-r border-[#1B1C1A] text-center">
                    <button
                      onClick={() => toggleStatus(asn.id)}
                      className={`px-2.5 py-1 border border-[#1B1C1A] text-[11px] font-bold uppercase rounded-[2px] transition-colors ${
                        asn.status === 'PUBLISHED'
                          ? 'bg-[#2563EB] text-white hover:bg-[#1D4ED8]'
                          : 'bg-[#FAF9F5] text-[#1B1C1A] hover:bg-[#EFEEEA]'
                      }`}
                    >
                      {asn.status}
                    </button>
                  </td>

                  {/* Actions Column */}
                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => handleOpenEditEditor(asn)}
                        title="Edit Assignment"
                        className="p-1.5 bg-white border border-[#1B1C1A] hover:bg-blue-50 text-[#2563EB] rounded-[1px] transition-all"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleDuplicate(asn)}
                        title="Duplicate Assignment"
                        className="p-1.5 bg-white border border-[#1B1C1A] hover:bg-purple-50 text-purple-700 rounded-[1px] transition-all"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleDelete(asn.id, asn.title)}
                        title="Delete Assignment"
                        className="p-1.5 bg-white border border-[#1B1C1A] hover:bg-red-50 text-red-600 rounded-[1px] transition-all"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Footer Pagination */}
      <div className="flex flex-wrap items-center justify-between text-xs font-mono text-gray-600 pt-2 border-t border-[#1B1C1A] gap-2">
        <span>SHOWING 1–{filteredAssignments.length} OF {assignments.length} ASSIGNMENTS</span>
        <div className="flex items-center gap-1 font-bold">
          <button className="px-2 py-1 bg-white border border-[#1B1C1A] rounded-[2px]">I&lt;</button>
          <button className="px-2 py-1 bg-white border border-[#1B1C1A] rounded-[2px]">&lt;</button>
          <button className="px-2.5 py-1 bg-[#2563EB] text-white border border-[#1B1C1A] rounded-[2px]">1</button>
          <button className="px-2.5 py-1 bg-white border border-[#1B1C1A] rounded-[2px]">2</button>
          <button className="px-2.5 py-1 bg-white border border-[#1B1C1A] rounded-[2px]">3</button>
          <button className="px-2 py-1 bg-white border border-[#1B1C1A] rounded-[2px]">&gt;</button>
          <button className="px-2 py-1 bg-white border border-[#1B1C1A] rounded-[2px]">&gt;I</button>
        </div>
      </div>

      {/* Assignment Editor Modal */}
      <AssignmentEditorModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveAssignment}
        initialAssignment={editingAssignment}
      />
    </div>
  );
};
