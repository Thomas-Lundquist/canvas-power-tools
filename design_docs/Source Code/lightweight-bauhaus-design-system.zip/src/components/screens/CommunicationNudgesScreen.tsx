import React, { useState, useEffect } from 'react';
import {
  Send,
  MessageSquare,
  Clock,
  Check,
  ShieldAlert,
  Users,
  FileText,
  AlertCircle
} from 'lucide-react';

export const CommunicationNudgesScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'nudges' | 'threshold' | 'sent-log'>('nudges');
  const [selectedAssignment, setSelectedAssignment] = useState('Quiz 1: Cell Biology');
  const [selectedStudents, setSelectedStudents] = useState<string[]>(['s-1', 's-2', 's-3']);
  const [messageBody, setMessageBody] = useState(
    'Hi {first_name}, just a friendly reminder that {assignment_name} is due on {due_date}. Please let me know if you need any support!'
  );
  const [previewing, setPreviewing] = useState(false);
  const [countdown, setCountdown] = useState(5);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    let timer: any;
    if (previewing && countdown > 0) {
      timer = setInterval(() => setCountdown((c) => c - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [previewing, countdown]);

  const handleStartSend = () => {
    setPreviewing(true);
    setCountdown(5);
  };

  const handleConfirmSend = () => {
    setPreviewing(false);
    setSent(true);
    setTimeout(() => setSent(false), 3000);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            COMMUNICATION NUDGES & THRESHOLD MESSENGER
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Send targeted messages to unsubmitted students or those above/below grade cutoffs with 5s delay safety preview.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => setActiveTab('nudges')}
            className={`px-3 py-1.5 font-bold uppercase rounded-[2px] border border-[#1B1C1A] ${
              activeTab === 'nudges' ? 'bg-[#7C3AED] text-white' : 'bg-white text-[#1B1C1A]'
            }`}
          >
            UNSUBMITTED NUDGES
          </button>

          <button
            onClick={() => setActiveTab('threshold')}
            className={`px-3 py-1.5 font-bold uppercase rounded-[2px] border border-[#1B1C1A] ${
              activeTab === 'threshold' ? 'bg-[#7C3AED] text-white' : 'bg-white text-[#1B1C1A]'
            }`}
          >
            GRADE THRESHOLD
          </button>

          <button
            onClick={() => setActiveTab('sent-log')}
            className={`px-3 py-1.5 font-bold uppercase rounded-[2px] border border-[#1B1C1A] ${
              activeTab === 'sent-log' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A]'
            }`}
          >
            SENT LOG (2)
          </button>
        </div>
      </div>

      {activeTab === 'nudges' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Form */}
          <div className="lg:col-span-8 bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-4">
            <div className="font-mono text-xs space-y-3">
              <label className="block font-bold text-[#1B1C1A] uppercase">1. SELECT TARGET ASSIGNMENT</label>
              <select
                value={selectedAssignment}
                onChange={(e) => setSelectedAssignment(e.target.value)}
                className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
              >
                <option>Quiz 1: Cell Biology (3 Students Unsubmitted)</option>
                <option>Essay Draft 1 (5 Students Unsubmitted)</option>
                <option>Lab Report 2 (1 Student Unsubmitted)</option>
              </select>

              <label className="block font-bold text-[#1B1C1A] uppercase pt-2">
                2. PERSONALIZED MESSAGE TEMPLATE
              </label>
              <textarea
                value={messageBody}
                onChange={(e) => setMessageBody(e.target.value)}
                rows={5}
                className="w-full p-3 bg-[#FAF9F5] border border-[#1B1C1A] font-mono text-xs leading-relaxed rounded-[1px] outline-none"
              />

              <div className="p-2 bg-[#EFEEEA] border border-gray-300 rounded-[1px] text-[11px] text-gray-600 flex flex-wrap gap-2">
                <span className="font-bold text-[#1B1C1A]">TOKENS:</span>
                <span>{"{first_name}"}</span>
                <span>{"{last_name}"}</span>
                <span>{"{assignment_name}"}</span>
                <span>{"{due_date}"}</span>
                <span>{"{teacher_name}"}</span>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200 flex justify-end">
              <button
                onClick={handleStartSend}
                disabled={selectedStudents.length === 0}
                className="px-5 py-2.5 bg-[#7C3AED] hover:bg-purple-700 text-white font-mono font-bold text-xs uppercase border border-[#1B1C1A] rounded-[2px] flex items-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>PREVIEW & RECIPIENTS ({selectedStudents.length})</span>
              </button>
            </div>
          </div>

          {/* Recipients List */}
          <div className="lg:col-span-4 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] p-4 space-y-3 font-mono text-xs">
            <h3 className="font-bold uppercase text-[#1B1C1A] flex items-center justify-between border-b border-gray-300 pb-2">
              <span>RECIPIENTS ({selectedStudents.length})</span>
              <span className="text-[10px] text-gray-500">3 UNPASSED</span>
            </h3>

            {['Alex Rivera', 'Jordan Chen', 'Taylor Swift'].map((name, idx) => (
              <div key={idx} className="p-2.5 bg-white border border-gray-300 rounded-[1px] flex items-center justify-between">
                <span className="font-bold text-[#1B1C1A]">{name}</span>
                <span className="text-[10px] text-red-600 font-bold uppercase">UNSUBMITTED</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Mandatory Safety Preview Overlay */}
      {previewing && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white border-2 border-[#1B1C1A] rounded-[2px] p-6 max-w-lg w-full space-y-4 font-mono text-xs shadow-2xl animate-fadeIn">
            <div className="flex items-center gap-2 text-red-700 font-bold uppercase border-b border-gray-200 pb-2">
              <ShieldAlert className="w-5 h-5" />
              <span>SAFETY CONFIRMATION & PREVIEW</span>
            </div>

            <div className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[1px] space-y-2">
              <span className="font-bold text-gray-500 uppercase">SAMPLE RENDERING (Alex Rivera):</span>
              <p className="text-gray-800 leading-relaxed italic">
                "{messageBody.replace('{first_name}', 'Alex').replace('{assignment_name}', 'Quiz 1: Cell Biology').replace('{due_date}', 'Tomorrow, 11:59 PM')}"
              </p>
            </div>

            <div className="p-3 bg-yellow-50 border border-yellow-300 text-yellow-900 rounded-[1px] font-bold">
              ⚠️ Messages cannot be recalled once sent to student Canvas inboxes.
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => setPreviewing(false)}
                className="px-3 py-2 bg-gray-200 text-[#1B1C1A] font-bold uppercase border border-[#1B1C1A]"
              >
                CANCEL
              </button>

              <button
                onClick={handleConfirmSend}
                disabled={countdown > 0}
                className={`px-4 py-2 font-bold uppercase border border-[#1B1C1A] flex items-center gap-2 ${
                  countdown > 0
                    ? 'bg-gray-300 text-gray-600 cursor-not-allowed'
                    : 'bg-[#7C3AED] text-white hover:bg-purple-800'
                }`}
              >
                <Send className="w-4 h-4" />
                <span>{countdown > 0 ? `SEND ACTIVATES IN ${countdown}S` : 'CONFIRM & SEND NOW'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
