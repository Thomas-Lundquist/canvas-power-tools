import React from 'react';
import { ScreenModule } from '../../types';
import {
  BarChart2,
  Users,
  FolderKanban,
  ArrowRight,
  CheckSquare,
  Megaphone,
  Sliders
} from 'lucide-react';

interface DashboardScreenProps {
  onNavigateScreen: (screen: ScreenModule) => void;
}

interface CoreModule {
  id: string;
  moduleNumber: string;
  name: string;
  subtitle: string;
  description: string;
  entryScreen: ScreenModule;
  accentBorder: string;
  badgeBg: string;
  buttonColor: string;
  icon: React.ReactNode;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({ onNavigateScreen }) => {
  const coreModules: CoreModule[] = [
    {
      id: 'assignments',
      moduleNumber: '01',
      name: 'Assignments Module',
      subtitle: '4 Integrated Tools',
      description: 'Comprehensive assignment management suite for Canvas. Batch edit due dates, manage template libraries, copy across courses, and author quizzes.',
      entryScreen: 'bulk-editor',
      accentBorder: 'border-t-[#2563EB]',
      badgeBg: 'bg-[#2563EB] text-white',
      buttonColor: 'bg-[#2563EB] hover:bg-[#1D4ED8] text-white',
      icon: <CheckSquare className="w-6 h-6 text-[#2563EB]" />
    },
    {
      id: 'grading',
      moduleNumber: '02',
      name: 'Grading Module',
      subtitle: '7 Integrated Tools',
      description: 'Centralized grading overview, zero grade & missing work tracker, grade curving formulas, late policy deductions, assignment group manager, rubric manager, and SpeedGrader suite.',
      entryScreen: 'grading-dashboard',
      accentBorder: 'border-t-[#059669]',
      badgeBg: 'bg-[#059669] text-white',
      buttonColor: 'bg-[#059669] hover:bg-[#047857] text-white',
      icon: <BarChart2 className="w-6 h-6 text-[#059669]" />
    },
    {
      id: 'people',
      moduleNumber: '03',
      name: 'People Module',
      subtitle: '4 Integrated Tools',
      description: 'Roster directory with student detail cards, automated group set generator, section-based due date manager, and FERPA-compliant accommodations overrides.',
      entryScreen: 'student-directory',
      accentBorder: 'border-t-[#EA580C]',
      badgeBg: 'bg-[#EA580C] text-white',
      buttonColor: 'bg-[#EA580C] hover:bg-[#C2410C] text-white',
      icon: <Users className="w-6 h-6 text-[#EA580C]" />
    },
    {
      id: 'communication',
      moduleNumber: '04',
      name: 'Communication Module',
      subtitle: '3 Integrated Tools',
      description: 'Cross-course announcement broadcaster, student threshold & unsubmitted reminder nudges, and recurring automated grade outreach emails.',
      entryScreen: 'announcements',
      accentBorder: 'border-t-[#7C3AED]',
      badgeBg: 'bg-[#7C3AED] text-white',
      buttonColor: 'bg-[#7C3AED] hover:bg-[#6D28D9] text-white',
      icon: <Megaphone className="w-6 h-6 text-[#7C3AED]" />
    },
    {
      id: 'content-modules',
      moduleNumber: '05',
      name: 'Content Modules',
      subtitle: '1 Core Module Tool',
      description: 'Structure course pages, assignments, quizzes, and discussions into sequential learning modules with prerequisites and requirement rules.',
      entryScreen: 'module-manager',
      accentBorder: 'border-t-[#0D9488]',
      badgeBg: 'bg-[#0D9488] text-white',
      buttonColor: 'bg-[#0D9488] hover:bg-[#0F766E] text-white',
      icon: <FolderKanban className="w-6 h-6 text-[#0D9488]" />
    },
    {
      id: 'admin-setup',
      moduleNumber: '06',
      name: 'Admin & Setup Module',
      subtitle: '3 Integrated Tools',
      description: 'Term-to-term course rollover wizard with date shifter, PIN protection & security audit trail, and extension settings with API token configuration.',
      entryScreen: 'rollover-wizard',
      accentBorder: 'border-t-[#334155]',
      badgeBg: 'bg-[#334155] text-white',
      buttonColor: 'bg-[#334155] hover:bg-[#1E293B] text-white',
      icon: <Sliders className="w-6 h-6 text-[#334155]" />
    }
  ];

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Top Banner Header */}
      <div className="border-b border-[#1B1C1A] pb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-[#1B1C1A] uppercase">
            CANVAS POWER TOOLS
          </h1>
          <p className="text-xs sm:text-sm font-medium text-gray-600 mt-2 font-mono">
            COMMAND CENTER
          </p>
        </div>
      </div>

      {/* 6 Original Core Module Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {coreModules.map((m) => (
          <div
            key={m.id}
            className={`bg-white border-2 border-[#1B1C1A] border-t-8 ${m.accentBorder} rounded-[2px] p-6 flex flex-col justify-between h-full shadow-sm hover:shadow-md transition-all`}
          >
            <div>
              {/* Header Row */}
              <div className="flex items-center justify-between mb-4">
                <div className="p-2.5 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px]">
                  {m.icon}
                </div>
                <span className={`px-2.5 py-1 text-[11px] font-mono font-bold uppercase rounded-[1px] ${m.badgeBg}`}>
                  MODULE {m.moduleNumber}
                </span>
              </div>

              {/* Title & Subtitle */}
              <h2 className="text-2xl font-black text-[#1B1C1A] tracking-tight mb-1 uppercase">
                {m.name}
              </h2>
              <div className="text-xs font-mono font-bold text-gray-500 mb-3">
                {m.subtitle}
              </div>

              {/* Description */}
              <p className="text-xs text-gray-600 leading-relaxed font-normal">
                {m.description}
              </p>
            </div>

            {/* Action Buttons Row */}
            <div className="pt-6 mt-6 border-t border-gray-100 flex flex-col gap-2">
              <button
                onClick={() => onNavigateScreen(m.entryScreen)}
                className={`w-full rounded-[2px] py-2.5 px-4 text-xs font-mono font-extrabold tracking-wider uppercase transition-colors flex items-center justify-center gap-2 ${m.buttonColor}`}
              >
                <span>ENTER {m.name.toUpperCase()}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
