import React, { useState } from 'react';
import {
  TrendingUp,
  Sliders,
  Check,
  RotateCcw,
  BarChart3,
  HelpCircle,
  Play
} from 'lucide-react';

export const GradeAdjustmentsScreen: React.FC = () => {
  const [curveType, setCurveType] = useState<'flat' | 'percent' | 'floor' | 'sqrt' | 'top100'>('flat');
  const [flatPoints, setFlatPoints] = useState(5);
  const [applied, setApplied] = useState(false);

  const sampleScores = [
    { name: 'Alex Rivera', raw: 68, curved: 68 + flatPoints },
    { name: 'Jordan Chen', raw: 74, curved: 74 + flatPoints },
    { name: 'Taylor Swift', raw: 82, curved: 82 + flatPoints },
    { name: 'Morgan Lee', raw: 91, curved: Math.min(100, 91 + flatPoints) }
  ];

  const origAvg = (sampleScores.reduce((acc, s) => acc + s.raw, 0) / sampleScores.length).toFixed(1);
  const curvedAvg = (sampleScores.reduce((acc, s) => acc + s.curved, 0) / sampleScores.length).toFixed(1);

  const handleApplyCurve = () => {
    setApplied(true);
    setTimeout(() => setApplied(false), 2500);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            GRADE ADJUSTMENTS & CURVING
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Apply mathematical curves across assignments: flat addition, percentage scaling, score floor, or square-root curves.
          </p>
        </div>

        <button
          onClick={handleApplyCurve}
          className={`px-4 py-2 border border-[#1B1C1A] font-mono font-bold text-xs uppercase rounded-[2px] transition-all flex items-center gap-2 ${
            applied ? 'bg-[#FEF08A] text-[#1B1C1A]' : 'bg-[#059669] text-white hover:bg-emerald-700'
          }`}
        >
          {applied ? (
            <>
              <Check className="w-4 h-4 text-[#1B1C1A]" />
              <span>CURVE APPLIED TO CANVAS!</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4" />
              <span>APPLY CURVE TO CANVAS</span>
            </>
          )}
        </button>
      </div>

      {/* Curve Type Selector */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 font-mono text-xs">
        {[
          { id: 'flat', label: 'FLAT ADDITION', desc: '+N points to all' },
          { id: 'percent', label: 'PERCENT SCALE', desc: 'Multiply by %' },
          { id: 'floor', label: 'SCORE FLOOR', desc: 'Min cutoff score' },
          { id: 'sqrt', label: 'SQRT CURVE', desc: '10 * sqrt(score)' },
          { id: 'top100', label: 'TOP TO 100', desc: 'Top scorer = 100%' }
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setCurveType(item.id as any)}
            className={`p-3 border rounded-[2px] text-left transition-all ${
              curveType === item.id
                ? 'bg-[#1B1C1A] text-[#FEF08A] border-[#1B1C1A]'
                : 'bg-white text-[#1B1C1A] border-gray-300 hover:border-[#1B1C1A]'
            }`}
          >
            <div className="font-bold uppercase">{item.label}</div>
            <div className="text-[10px] text-gray-400 mt-1">{item.desc}</div>
          </button>
        ))}
      </div>

      {/* Parameter Config & Live Class Average */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        <div className="md:col-span-6 bg-white border border-[#1B1C1A] p-6 rounded-[2px] space-y-4">
          <h3 className="font-mono font-bold text-xs uppercase text-gray-500 border-b border-gray-200 pb-2">
            CURVE PARAMETERS ({curveType.toUpperCase()})
          </h3>

          <div>
            <label className="block text-xs font-mono font-bold text-[#1B1C1A] uppercase mb-1">
              Flat Addition Points (+N)
            </label>
            <input
              type="number"
              value={flatPoints}
              onChange={(e) => setFlatPoints(parseInt(e.target.value) || 0)}
              className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-mono font-bold text-sm rounded-[1px] outline-none"
            />
          </div>
        </div>

        <div className="md:col-span-6 bg-[#EFEEEA] border border-[#1B1C1A] p-6 rounded-[2px] space-y-3 font-mono">
          <span className="text-xs font-bold uppercase text-gray-600">
            CLASS AVERAGE BEFORE & AFTER
          </span>
          <div className="flex items-center justify-between pt-2">
            <div>
              <span className="text-[10px] text-gray-500 uppercase">ORIGINAL AVG</span>
              <div className="text-2xl font-black text-gray-600">{origAvg}%</div>
            </div>

            <div className="text-2xl font-black text-[#1B1C1A]">→</div>

            <div>
              <span className="text-[10px] text-[#059669] uppercase font-bold">CURVED AVG</span>
              <div className="text-2xl font-black text-[#059669]">{curvedAvg}%</div>
            </div>
          </div>
        </div>
      </div>

      {/* Student Score Preview Matrix */}
      <div className="bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-4 font-mono text-xs">
        <h3 className="font-bold uppercase text-gray-500 border-b border-gray-200 pb-2">
          STUDENT IMPACT PREVIEW ({sampleScores.length} STUDENTS)
        </h3>

        <div className="space-y-2">
          {sampleScores.map((s, idx) => (
            <div key={idx} className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[2px] flex items-center justify-between">
              <span className="font-bold text-[#1B1C1A]">{s.name}</span>
              <div className="flex items-center gap-4">
                <span className="text-gray-500">RAW: {s.raw}%</span>
                <span className="font-bold text-[#059669]">CURVED: {s.curved}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
