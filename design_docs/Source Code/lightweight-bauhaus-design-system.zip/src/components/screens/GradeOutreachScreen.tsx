import React, { useState } from 'react';
import {
  Clock,
  Repeat,
  Send,
  AlertTriangle,
  CheckCircle2,
  Play,
  Pause,
  Trash2,
  Calendar,
  Sparkles,
  ShieldCheck,
  FileText,
  Users,
  Settings2,
  History,
  Plus
} from 'lucide-react';

interface RecurringRule {
  id: string;
  title: string;
  ruleType: 'missing' | 'low_grade' | 'praise';
  frequency: 'daily' | 'weekly' | 'monthly' | 'custom';
  scheduleDetail: string;
  conditionText: string;
  targetCountEstimate: number;
  status: 'active' | 'paused';
  lastRun: string;
  nextRun: string;
  template: string;
}

interface DispatchLog {
  id: string;
  timestamp: string;
  ruleTitle: string;
  recipientsCount: number;
  status: 'SUCCESS' | 'PARTIAL' | 'CANCELLED';
  summary: string;
}

export const GradeOutreachScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'schedules' | 'create' | 'history'>('schedules');

  // Sample active rules
  const [rules, setRules] = useState<RecurringRule[]>([
    {
      id: 'rule-1',
      title: 'Weekly Overdue Work Nudge',
      ruleType: 'missing',
      frequency: 'weekly',
      scheduleDetail: 'Every Monday @ 09:00 AM',
      conditionText: 'Unsubmitted assignments past due by > 1 day',
      targetCountEstimate: 5,
      status: 'active',
      lastRun: '2026-07-20 09:00',
      nextRun: '2026-07-27 09:00',
      template: 'Hi {first_name}, automated check shows you have {missing_count} unsubmitted assignment(s) in {course_name}: {missing_list}. Please submit as soon as possible!'
    },
    {
      id: 'rule-2',
      title: 'Monthly Low-Grade Alert (<70%)',
      ruleType: 'low_grade',
      frequency: 'monthly',
      scheduleDetail: '1st of every month @ 08:00 AM',
      conditionText: 'Overall course grade below 70.0%',
      targetCountEstimate: 3,
      status: 'active',
      lastRun: '2026-07-01 08:00',
      nextRun: '2026-08-01 08:00',
      template: 'Hello {first_name}, this is a friendly monthly update from {teacher_name}. Your current standing in {course_name} is {current_grade}%. Let us meet during office hours to discuss support!'
    }
  ]);

  // New Rule Form State
  const [newTitle, setNewTitle] = useState('Bi-Weekly Academic Progress Check');
  const [newType, setNewType] = useState<'missing' | 'low_grade' | 'praise'>('missing');
  const [newFreq, setNewFreq] = useState<'daily' | 'weekly' | 'monthly' | 'custom'>('weekly');
  const [newDay, setNewDay] = useState('Friday');
  const [newTime, setNewTime] = useState('16:00');
  const [thresholdVal, setThresholdVal] = useState('70');
  const [templateText, setTemplateText] = useState(
    'Hi {first_name}, this is your automated {frequency} progress check for {course_name}. Current status: {status_summary}. Reach out if you need assistance!'
  );
  const [dispatchMode, setDispatchMode] = useState<'direct' | 'draft'>('direct');
  const [maxPerRun, setMaxPerRun] = useState(25);
  const [createdSuccess, setCreatedSuccess] = useState(false);

  // Logs
  const [logs] = useState<DispatchLog[]>([
    {
      id: 'log-1',
      timestamp: '2026-07-20 09:00:12',
      ruleTitle: 'Weekly Overdue Work Nudge',
      recipientsCount: 5,
      status: 'SUCCESS',
      summary: 'Sent Canvas Inbox messages to 5 students with unsubmitted assignments'
    },
    {
      id: 'log-2',
      timestamp: '2026-07-13 09:00:08',
      ruleTitle: 'Weekly Overdue Work Nudge',
      recipientsCount: 4,
      status: 'SUCCESS',
      summary: 'Sent Canvas Inbox messages to 4 students with unsubmitted assignments'
    },
    {
      id: 'log-3',
      timestamp: '2026-07-01 08:00:22',
      ruleTitle: 'Monthly Low-Grade Alert (<70%)',
      recipientsCount: 3,
      status: 'SUCCESS',
      summary: 'Sent Canvas Inbox messages to 3 students below 70% grade threshold'
    }
  ]);

  const toggleStatus = (id: string) => {
    setRules((prev) =>
      prev.map((r) =>
        r.id === id ? { ...r, status: r.status === 'active' ? 'paused' : 'active' } : r
      )
    );
  };

  const deleteRule = (id: string) => {
    setRules((prev) => prev.filter((r) => r.id !== id));
  };

  const handleCreateRule = (e: React.FormEvent) => {
    e.preventDefault();
    const created: RecurringRule = {
      id: `rule-${Date.now()}`,
      title: newTitle || 'Custom Recurring Nudge',
      ruleType: newType,
      frequency: newFreq,
      scheduleDetail:
        newFreq === 'daily'
          ? `Daily @ ${newTime}`
          : newFreq === 'weekly'
          ? `Every ${newDay} @ ${newTime}`
          : newFreq === 'monthly'
          ? `Monthly (1st) @ ${newTime}`
          : `Custom Interval @ ${newTime}`,
      conditionText:
        newType === 'missing'
          ? 'Unsubmitted assignments past due date'
          : newType === 'low_grade'
          ? `Course grade below ${thresholdVal}%`
          : `Course grade at or above ${thresholdVal}%`,
      targetCountEstimate: 4,
      status: 'active',
      lastRun: 'Never',
      nextRun: 'Upcoming on schedule',
      template: templateText
    };

    setRules([created, ...rules]);
    setCreatedSuccess(true);
    setTimeout(() => {
      setCreatedSuccess(false);
      setActiveTab('schedules');
    }, 1500);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            RECURRING GRADE & NUDGE OUTREACH
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Automate recurring scans for missing work and low grades (daily, weekly, monthly) with Canvas Inbox dispatches.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => setActiveTab('schedules')}
            className={`px-3 py-1.5 font-bold uppercase rounded-[2px] border border-[#1B1C1A] transition-all flex items-center gap-1.5 ${
              activeTab === 'schedules' ? 'bg-[#7C3AED] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
          >
            <Repeat className="w-3.5 h-3.5" />
            <span>ACTIVE JOBS ({rules.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('create')}
            className={`px-3 py-1.5 font-bold uppercase rounded-[2px] border border-[#1B1C1A] transition-all flex items-center gap-1.5 ${
              activeTab === 'create' ? 'bg-[#7C3AED] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>NEW RECURRING RULE</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 font-bold uppercase rounded-[2px] border border-[#1B1C1A] transition-all flex items-center gap-1.5 ${
              activeTab === 'history' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A] hover:bg-[#FAF9F5]'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>DISPATCH LOGS</span>
          </button>
        </div>
      </div>

      {/* Safety Banner */}
      <div className="p-3 bg-purple-50 border border-[#7C3AED]/30 rounded-[2px] font-mono text-xs flex items-start gap-2.5">
        <ShieldCheck className="w-4 h-4 text-[#7C3AED] shrink-0 mt-0.5" />
        <div>
          <strong className="text-[#1B1C1A] uppercase">ETHICAL AUTOMATION & SAFETY GUARDRAILS:</strong>
          <p className="text-gray-700 text-[11px] mt-0.5">
            Recurring jobs execute locally in your active Canvas browser session. Messages include automated disclosure footers and respect max recipient caps to prevent inbox saturation.
          </p>
        </div>
      </div>

      {/* TAB 1: ACTIVE SCHEDULED JOBS */}
      {activeTab === 'schedules' && (
        <div className="space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between bg-[#EFEEEA] border border-[#1B1C1A] p-3 font-bold uppercase text-[#1B1C1A]">
            <span>AUTOMATED RECURRING OUTREACH JOBS ({rules.length})</span>
            <span className="text-[10px] text-gray-600">ALL SCHEDULES SYNCED WITH CANVAS API</span>
          </div>

          {rules.length === 0 ? (
            <div className="p-8 bg-white border border-[#1B1C1A] text-center space-y-3">
              <Clock className="w-8 h-8 text-gray-400 mx-auto" />
              <p className="font-bold text-[#1B1C1A] uppercase">No active recurring outreach rules</p>
              <button
                onClick={() => setActiveTab('create')}
                className="px-4 py-2 bg-[#7C3AED] text-white font-bold uppercase border border-[#1B1C1A] rounded-[2px]"
              >
                + Create First Recurring Schedule
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {rules.map((r) => (
                <div
                  key={r.id}
                  className={`p-5 bg-white border-2 rounded-[2px] space-y-3 transition-all ${
                    r.status === 'active' ? 'border-[#1B1C1A]' : 'border-gray-300 opacity-75'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-200 pb-3">
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`px-2 py-0.5 text-[10px] font-bold uppercase border ${
                          r.ruleType === 'missing'
                            ? 'bg-amber-100 text-amber-900 border-amber-300'
                            : r.ruleType === 'low_grade'
                            ? 'bg-red-100 text-red-900 border-red-300'
                            : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                        }`}
                      >
                        {r.ruleType.replace('_', ' ')}
                      </span>
                      <h3 className="font-bold text-base text-[#1B1C1A]">{r.title}</h3>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`px-2 py-0.5 font-bold uppercase text-[10px] rounded-[1px] border ${
                          r.status === 'active'
                            ? 'bg-[#059669] text-white border-[#059669]'
                            : 'bg-gray-200 text-gray-700 border-gray-400'
                        }`}
                      >
                        {r.status === 'active' ? 'ACTIVE SCHEDULE' : 'PAUSED'}
                      </span>

                      <button
                        onClick={() => toggleStatus(r.id)}
                        className="p-1.5 bg-[#FAF9F5] border border-[#1B1C1A] hover:bg-gray-100 rounded-[1px]"
                        title={r.status === 'active' ? 'Pause Rule' : 'Resume Rule'}
                      >
                        {r.status === 'active' ? (
                          <Pause className="w-3.5 h-3.5 text-gray-700" />
                        ) : (
                          <Play className="w-3.5 h-3.5 text-[#059669]" />
                        )}
                      </button>

                      <button
                        onClick={() => deleteRule(r.id)}
                        className="p-1.5 bg-[#FAF9F5] border border-[#1B1C1A] hover:bg-red-100 rounded-[1px]"
                        title="Delete Rule"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-600" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-[#FAF9F5] p-3 border border-gray-200 rounded-[1px]">
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase block">FREQUENCY</span>
                      <strong className="text-[#7C3AED] uppercase">{r.scheduleDetail}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase block">CONDITION</span>
                      <span className="text-[#1B1C1A] font-bold">{r.conditionText}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase block">LAST / NEXT RUN</span>
                      <span className="text-gray-700 font-bold">{r.lastRun} → {r.nextRun}</span>
                    </div>
                  </div>

                  <div className="p-3 bg-gray-50 border border-gray-200 rounded-[1px] space-y-1">
                    <span className="text-[10px] text-gray-500 uppercase font-bold">MESSAGE TEMPLATE:</span>
                    <p className="text-xs text-gray-800 italic leading-relaxed">"{r.template}"</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: CREATE RECURRING RULE */}
      {activeTab === 'create' && (
        <form onSubmit={handleCreateRule} className="bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-6 font-mono text-xs">
          <div className="border-b border-gray-200 pb-3 flex items-center justify-between">
            <h3 className="font-bold text-sm uppercase text-[#1B1C1A] flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#7C3AED]" />
              <span>CONFIGURE RECURRING OUTREACH SCHEDULER</span>
            </h3>
            <span className="text-[10px] text-gray-500">STEP-BY-STEP SCHEDULER WIZARD</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Configuration Inputs */}
            <div className="lg:col-span-7 space-y-4">
              <div>
                <label className="block font-bold text-[#1B1C1A] uppercase mb-1">1. RULE IDENTIFIER / TITLE</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full p-2.5 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  placeholder="e.g. Weekly Overdue Work Nudge"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-[#1B1C1A] uppercase mb-1">2. SCAN TRIGGER CONDITION</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full p-2.5 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  >
                    <option value="missing">🚨 Missing Work Scan (Unsubmitted)</option>
                    <option value="low_grade">📉 Low Grade Threshold (Below Cutoff)</option>
                    <option value="praise">🌟 Praise & Recognition (High Grade)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-[#1B1C1A] uppercase mb-1">3. RECURRENCE FREQUENCY</label>
                  <select
                    value={newFreq}
                    onChange={(e) => setNewFreq(e.target.value as any)}
                    className="w-full p-2.5 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  >
                    <option value="daily">Daily Scan</option>
                    <option value="weekly">Weekly Scan</option>
                    <option value="monthly">Monthly Scan (1st of Month)</option>
                    <option value="custom">Custom Interval</option>
                  </select>
                </div>
              </div>

              {newFreq === 'weekly' && (
                <div className="grid grid-cols-2 gap-4 bg-[#FAF9F5] p-3 border border-gray-300 rounded-[1px]">
                  <div>
                    <label className="block font-bold text-gray-600 uppercase mb-1">Select Day of Week:</label>
                    <select
                      value={newDay}
                      onChange={(e) => setNewDay(e.target.value)}
                      className="w-full p-2 bg-white border border-[#1B1C1A] font-bold rounded-[1px]"
                    >
                      <option value="Monday">Every Monday</option>
                      <option value="Wednesday">Every Wednesday</option>
                      <option value="Friday">Every Friday</option>
                      <option value="Sunday">Every Sunday</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-gray-600 uppercase mb-1">Execution Time:</label>
                    <input
                      type="time"
                      value={newTime}
                      onChange={(e) => setNewTime(e.target.value)}
                      className="w-full p-1.5 bg-white border border-[#1B1C1A] font-bold rounded-[1px]"
                    />
                  </div>
                </div>
              )}

              {newType !== 'missing' && (
                <div>
                  <label className="block font-bold text-[#1B1C1A] uppercase mb-1">Grade Threshold Cutoff Percentage (%)</label>
                  <input
                    type="number"
                    value={thresholdVal}
                    onChange={(e) => setThresholdVal(e.target.value)}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px]"
                  />
                </div>
              )}

              <div>
                <label className="block font-bold text-[#1B1C1A] uppercase mb-1">4. PERSONALIZED MESSAGE TEMPLATE</label>
                <textarea
                  value={templateText}
                  onChange={(e) => setTemplateText(e.target.value)}
                  rows={4}
                  className="w-full p-3 bg-[#FAF9F5] border border-[#1B1C1A] font-mono text-xs leading-relaxed rounded-[1px] outline-none"
                />
                <div className="p-2 bg-[#EFEEEA] border border-gray-300 rounded-[1px] text-[10px] text-gray-600 flex flex-wrap gap-2 mt-1">
                  <span className="font-bold text-[#1B1C1A]">TOKENS:</span>
                  <span>{"{first_name}"}</span>
                  <span>{"{course_name}"}</span>
                  <span>{"{missing_count}"}</span>
                  <span>{"{missing_list}"}</span>
                  <span>{"{current_grade}"}</span>
                  <span>{"{teacher_name}"}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block font-bold text-gray-600 uppercase mb-1">Dispatch Mode:</label>
                  <select
                    value={dispatchMode}
                    onChange={(e) => setDispatchMode(e.target.value as any)}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px]"
                  >
                    <option value="direct">Direct Send to Canvas Inbox</option>
                    <option value="draft">Save as Draft in Canvas</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-gray-600 uppercase mb-1">Max Recipients Per Run:</label>
                  <input
                    type="number"
                    value={maxPerRun}
                    onChange={(e) => setMaxPerRun(parseInt(e.target.value) || 10)}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px]"
                  />
                </div>
              </div>
            </div>

            {/* Right Live Template Preview */}
            <div className="lg:col-span-5 space-y-4">
              <div className="p-4 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] space-y-3">
                <h4 className="font-bold text-xs uppercase text-[#1B1C1A] border-b border-gray-300 pb-2 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-[#7C3AED]" />
                  <span>LIVE SAMPLE PREVIEW</span>
                </h4>

                <div className="bg-white p-3 border border-gray-300 rounded-[1px] space-y-2">
                  <div className="flex justify-between text-[10px] text-gray-500 border-b border-gray-100 pb-1">
                    <span>TO: Alex Rivera (Sample Student)</span>
                    <span>VIA: Canvas Inbox</span>
                  </div>
                  <p className="text-gray-800 leading-relaxed text-xs italic">
                    "{templateText
                      .replace('{first_name}', 'Alex')
                      .replace('{course_name}', 'Biology 101')
                      .replace('{missing_count}', '2')
                      .replace('{missing_list}', 'Lab Report 2, Quiz 1')
                      .replace('{current_grade}', '68.5')
                      .replace('{frequency}', newFreq)
                      .replace('{status_summary}', 'Missing 2 assignments')
                      .replace('{teacher_name}', 'Prof. Anderson')}"
                  </p>
                </div>

                <div className="p-2.5 bg-purple-100 border border-purple-300 text-purple-900 rounded-[1px] text-[11px] font-bold">
                  ⚡ Schedule summary: Runs {newFreq.toUpperCase()} on {newDay} at {newTime}. Directly sends up to {maxPerRun} messages per execution.
                </div>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  type="submit"
                  className={`w-full py-3 border border-[#1B1C1A] font-mono font-bold text-xs uppercase rounded-[2px] transition-all flex items-center justify-center gap-2 ${
                    createdSuccess
                      ? 'bg-[#FEF08A] text-[#1B1C1A]'
                      : 'bg-[#7C3AED] text-white hover:bg-purple-800'
                  }`}
                >
                  {createdSuccess ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-[#1B1C1A]" />
                      <span>RECURRING SCHEDULER CREATED & ACTIVATED!</span>
                    </>
                  ) : (
                    <>
                      <Repeat className="w-4 h-4" />
                      <span>ACTIVATE RECURRING SCHEDULER</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </form>
      )}

      {/* TAB 3: EXECUTION LOGS */}
      {activeTab === 'history' && (
        <div className="bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-gray-200 pb-2">
            <h3 className="font-bold text-xs uppercase text-[#1B1C1A]">AUTOMATED RECURRING DISPATCH AUDIT LOG</h3>
            <span className="text-[10px] text-gray-500">HISTORICAL CANVAS INBOX DISPATCHES</span>
          </div>

          <div className="space-y-3">
            {logs.map((log) => (
              <div key={log.id} className="p-4 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 bg-[#059669] text-white font-bold text-[10px] uppercase">
                      {log.status}
                    </span>
                    <strong className="text-sm text-[#1B1C1A]">{log.ruleTitle}</strong>
                  </div>
                  <p className="text-gray-600 mt-1">{log.summary}</p>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-gray-500 block uppercase">{log.timestamp}</span>
                  <span className="font-bold text-[#7C3AED] text-xs">{log.recipientsCount} Canvas Messages Sent</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
