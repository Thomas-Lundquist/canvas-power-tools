import React, { useState } from 'react';
import {
  Clock,
  Check,
  Shield,
  HelpCircle,
  Sliders,
  AlertCircle
} from 'lucide-react';

interface PolicyRule {
  type: string;
  enabled: boolean;
  penaltyPerDay: number;
  gracePeriodHours: number;
  maxPenaltyCap: number;
}

export const LatePolicyScreen: React.FC = () => {
  const [policies, setPolicies] = useState<PolicyRule[]>([
    { type: 'Homework & Problem Sets', enabled: true, penaltyPerDay: 10, gracePeriodHours: 2, maxPenaltyCap: 50 },
    { type: 'Quizzes & Exit Tickets', enabled: true, penaltyPerDay: 15, gracePeriodHours: 0, maxPenaltyCap: 60 },
    { type: 'Lab Reports & STEM Labs', enabled: true, penaltyPerDay: 5, gracePeriodHours: 12, maxPenaltyCap: 30 },
    { type: 'Exams & Midterm', enabled: false, penaltyPerDay: 20, gracePeriodHours: 0, maxPenaltyCap: 100 }
  ]);

  const [saved, setSaved] = useState(false);

  const handleToggle = (idx: number) => {
    const updated = [...policies];
    updated[idx].enabled = !updated[idx].enabled;
    setPolicies(updated);
  };

  const handleChange = (idx: number, field: keyof PolicyRule, val: number) => {
    const updated = [...policies];
    (updated[idx] as any)[field] = val;
    setPolicies(updated);
  };

  const handleSavePolicy = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            LATE POLICY & DEDUCTION MANAGER
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Configure automated late penalties with grace periods and maximum deduction caps by assignment group.
          </p>
        </div>

        <button
          onClick={handleSavePolicy}
          className={`px-4 py-2 border border-[#1B1C1A] font-mono font-bold text-xs uppercase rounded-[2px] transition-all flex items-center gap-2 ${
            saved ? 'bg-[#FEF08A] text-[#1B1C1A]' : 'bg-[#059669] text-white hover:bg-emerald-700'
          }`}
        >
          {saved ? (
            <>
              <Check className="w-4 h-4 text-[#1B1C1A]" />
              <span>POLICY SAVED TO CANVAS!</span>
            </>
          ) : (
            <>
              <Shield className="w-4 h-4" />
              <span>SAVE LATE POLICY</span>
            </>
          )}
        </button>
      </div>

      {/* Rules Matrix */}
      <div className="space-y-4">
        {policies.map((p, idx) => (
          <div
            key={idx}
            className={`p-6 border rounded-[2px] transition-all ${
              p.enabled
                ? 'bg-white border-[#1B1C1A] shadow-sm'
                : 'bg-[#FAF9F5] border-gray-300 opacity-75'
            }`}
          >
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-gray-200 pb-4 mb-4">
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={p.enabled}
                  onChange={() => handleToggle(idx)}
                  className="w-5 h-5 accent-[#059669]"
                />
                <h3 className="text-lg font-bold text-[#1B1C1A]">{p.type}</h3>
              </div>

              <span
                className={`text-xs font-mono font-bold uppercase px-2 py-1 rounded-[1px] ${
                  p.enabled ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' : 'bg-gray-200 text-gray-600'
                }`}
              >
                {p.enabled ? 'POLICY ACTIVE' : 'DISABLED'}
              </span>
            </div>

            {p.enabled && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
                <div>
                  <label className="block font-bold text-gray-600 uppercase mb-1">
                    Deduction Per Day (%):
                  </label>
                  <input
                    type="number"
                    value={p.penaltyPerDay}
                    onChange={(e) => handleChange(idx, 'penaltyPerDay', parseInt(e.target.value) || 0)}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-600 uppercase mb-1">
                    Grace Period (Hours):
                  </label>
                  <input
                    type="number"
                    value={p.gracePeriodHours}
                    onChange={(e) => handleChange(idx, 'gracePeriodHours', parseInt(e.target.value) || 0)}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-600 uppercase mb-1">
                    Maximum Penalty Cap (%):
                  </label>
                  <input
                    type="number"
                    value={p.maxPenaltyCap}
                    onChange={(e) => handleChange(idx, 'maxPenaltyCap', parseInt(e.target.value) || 0)}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
