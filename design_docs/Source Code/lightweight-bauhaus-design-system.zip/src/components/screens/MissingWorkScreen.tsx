import React, { useState } from 'react';
import {
  AlertTriangle,
  Send,
  CheckSquare,
  Search,
  Check,
  Users,
  FileText,
  Clock,
  ChevronDown,
  ChevronUp,
  Mail,
  UserX,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';

interface MissingStudent {
  studentId: string;
  studentName: string;
  email: string;
}

interface MissingAssignment {
  id: string;
  assignmentName: string;
  asnCode: string;
  dueDate: string;
  daysOverdue: number;
  pointsPossible: number;
  missingStudents: MissingStudent[];
}

export const MissingWorkScreen: React.FC = () => {
  // Default view mode is 'assignment' per requirement
  const [viewMode, setViewMode] = useState<'assignment' | 'student'>('assignment');
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>({
    'asn-1': true,
    'asn-2': true
  });

  // Action State Tracking
  const [nudgedAssignments, setNudgedAssignments] = useState<string[]>([]); // Assignment IDs nudged in bulk
  const [zeroedAssignments, setZeroedAssignments] = useState<string[]>([]); // Assignment IDs zeroed in bulk
  const [nudgedStudents, setNudgedStudents] = useState<string[]>([]); // Student IDs nudged in bulk for all work
  const [individualNudges, setIndividualNudges] = useState<string[]>([]); // "studentId_assignmentId"
  const [individualZeros, setIndividualZeros] = useState<string[]>([]); // "studentId_assignmentId"

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const missingAssignmentsData: MissingAssignment[] = [
    {
      id: 'asn-1',
      assignmentName: 'Lab Report 1: Osmosis & Cell Dynamics',
      asnCode: 'LAB-2026-01',
      dueDate: '2026-07-10',
      daysOverdue: 13,
      pointsPossible: 50,
      missingStudents: [
        { studentId: 's-101', studentName: 'Alex Rivera', email: 'a.rivera@university.edu' },
        { studentId: 's-104', studentName: 'Sarah Jenkins', email: 's.jenkins@university.edu' },
        { studentId: 's-105', studentName: 'Marcus Vance', email: 'm.vance@university.edu' }
      ]
    },
    {
      id: 'asn-2',
      assignmentName: 'Midterm Essay Draft & Thesis Outline',
      asnCode: 'PROJ-2026-04',
      dueDate: '2026-07-15',
      daysOverdue: 8,
      pointsPossible: 100,
      missingStudents: [
        { studentId: 's-102', studentName: 'Jordan Chen', email: 'j.chen@university.edu' },
        { studentId: 's-101', studentName: 'Alex Rivera', email: 'a.rivera@university.edu' },
        { studentId: 's-106', studentName: 'Chloe Bennett', email: 'c.bennett@university.edu' },
        { studentId: 's-107', studentName: 'Daniel Kim', email: 'd.kim@university.edu' }
      ]
    },
    {
      id: 'asn-3',
      assignmentName: 'Cellular Respiration & ATP Synthesis Quiz',
      asnCode: 'QUIZ-2026-02',
      dueDate: '2026-07-18',
      daysOverdue: 5,
      pointsPossible: 25,
      missingStudents: [
        { studentId: 's-101', studentName: 'Alex Rivera', email: 'a.rivera@university.edu' },
        { studentId: 's-102', studentName: 'Jordan Chen', email: 'j.chen@university.edu' }
      ]
    },
    {
      id: 'asn-4',
      assignmentName: 'Genetics & Punnett Squares Problem Set #3',
      asnCode: 'HW-2026-08',
      dueDate: '2026-07-20',
      daysOverdue: 3,
      pointsPossible: 30,
      missingStudents: [
        { studentId: 's-103', studentName: 'Taylor Swift', email: 't.swift@university.edu' },
        { studentId: 's-104', studentName: 'Sarah Jenkins', email: 's.jenkins@university.edu' }
      ]
    }
  ];

  const toggleExpand = (id: string) => {
    setExpandedItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // 1. Assignment Level Actions
  const handleNudgeAllForAssignment = (asn: MissingAssignment) => {
    if (!nudgedAssignments.includes(asn.id)) {
      setNudgedAssignments(prev => [...prev, asn.id]);
    }
    showToast(`NUDGE EMAILS DISPATCHED TO ALL ${asn.missingStudents.length} STUDENTS MISSING "${asn.assignmentName.toUpperCase()}"!`);
  };

  const handleGradeAsZeroForAssignment = (asn: MissingAssignment) => {
    if (!zeroedAssignments.includes(asn.id)) {
      setZeroedAssignments(prev => [...prev, asn.id]);
    }
    showToast(`GRADED ${asn.missingStudents.length} MISSING SUBMISSIONS AS 0/100 ON "${asn.assignmentName.toUpperCase()}"!`);
  };

  // 2. Student Level Actions (In By-Student View)
  const handleNudgeStudentAllAssignments = (studentName: string, studentId: string, count: number) => {
    if (!nudgedStudents.includes(studentId)) {
      setNudgedStudents(prev => [...prev, studentId]);
    }
    showToast(`CONSOLIDATED NUDGE DISPATCHED TO ${studentName.toUpperCase()} FOR ALL ${count} OVERDUE ASSIGNMENTS!`);
  };

  // 3. Individual Student-Assignment Action
  const handleIndividualNudge = (studentId: string, assignmentId: string, studentName: string) => {
    const key = `${studentId}_${assignmentId}`;
    if (!individualNudges.includes(key)) {
      setIndividualNudges(prev => [...prev, key]);
    }
    showToast(`NUDGE REMINDER SENT TO ${studentName.toUpperCase()}`);
  };

  const handleIndividualZero = (studentId: string, assignmentId: string, studentName: string) => {
    const key = `${studentId}_${assignmentId}`;
    if (!individualZeros.includes(key)) {
      setIndividualZeros(prev => [...prev, key]);
    }
    showToast(`GRADE OF 0 ENTERED FOR ${studentName.toUpperCase()}`);
  };

  // Filtered by Search Term
  const filteredAssignments = missingAssignmentsData.filter(asn => {
    const term = searchTerm.toLowerCase();
    const matchAsn = asn.assignmentName.toLowerCase().includes(term) || asn.asnCode.toLowerCase().includes(term);
    const matchStudent = asn.missingStudents.some(s => s.studentName.toLowerCase().includes(term) || s.email.toLowerCase().includes(term));
    return matchAsn || matchStudent;
  });

  // Grouping Data for "By Student" View
  const studentMap: Record<string, { studentId: string; studentName: string; email: string; assignments: MissingAssignment[] }> = {};

  missingAssignmentsData.forEach(asn => {
    asn.missingStudents.forEach(st => {
      if (!studentMap[st.studentId]) {
        studentMap[st.studentId] = {
          studentId: st.studentId,
          studentName: st.studentName,
          email: st.email,
          assignments: []
        };
      }
      studentMap[st.studentId].assignments.push(asn);
    });
  });

  const studentList = Object.values(studentMap).filter(st => {
    const term = searchTerm.toLowerCase();
    const matchName = st.studentName.toLowerCase().includes(term) || st.email.toLowerCase().includes(term);
    const matchAsn = st.assignments.some(a => a.assignmentName.toLowerCase().includes(term));
    return matchName || matchAsn;
  });

  const totalMissingSubmissions = missingAssignmentsData.reduce((acc, curr) => acc + curr.missingStudents.length, 0);

  return (
    <div className="space-y-6 animate-fadeIn font-mono text-xs">
      {/* Toast Banner */}
      {toastMessage && (
        <div className="bg-[#FEF08A] border-2 border-[#1B1C1A] p-3 rounded-[2px] font-mono text-xs font-bold text-[#1B1C1A] flex items-center justify-between shadow-xs animate-bounce">
          <div className="flex items-center gap-2 uppercase">
            <CheckCircle2 className="w-4 h-4 text-[#059669]" />
            <span>{toastMessage}</span>
          </div>
          <button onClick={() => setToastMessage(null)} className="hover:text-red-700">✕</button>
        </div>
      )}

      {/* Screen Header */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            MISSING WORK DASHBOARD
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Identify outstanding submissions across assignments or students and perform 1-click bulk nudges and zeroes.
          </p>
        </div>

        {/* View Mode Toggle Switch (Default: By Assignment) */}
        <div className="flex items-center gap-2 font-mono text-xs bg-[#FAF9F5] p-1.5 border border-[#1B1C1A] rounded-[2px]">
          <span className="font-bold text-[#1B1C1A] uppercase text-[10px] px-1">VIEW BY:</span>
          <button
            onClick={() => setViewMode('assignment')}
            className={`px-3 py-1.5 font-bold uppercase rounded-[1px] border transition-all ${
              viewMode === 'assignment'
                ? 'bg-[#059669] text-white border-[#1B1C1A] shadow-xs'
                : 'bg-white text-[#1B1C1A] border-gray-300 hover:border-[#1B1C1A]'
            }`}
          >
            BY ASSIGNMENT (DEFAULT)
          </button>
          <button
            onClick={() => setViewMode('student')}
            className={`px-3 py-1.5 font-bold uppercase rounded-[1px] border transition-all ${
              viewMode === 'student'
                ? 'bg-[#059669] text-white border-[#1B1C1A] shadow-xs'
                : 'bg-white text-[#1B1C1A] border-gray-300 hover:border-[#1B1C1A]'
            }`}
          >
            BY STUDENT
          </button>
        </div>
      </div>

      {/* Filter & Metric Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#EFEEEA] border border-[#1B1C1A] p-3 rounded-[2px]">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-gray-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="FILTER BY ASSIGNMENT TITLE, CODE, OR STUDENT NAME..."
            className="w-full bg-white border border-[#1B1C1A] pl-9 pr-3 py-1.5 text-xs font-mono rounded-[1px] outline-none focus:border-[#059669]"
          />
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-white px-3 py-1.5 border border-[#1B1C1A] rounded-[1px] font-bold text-xs">
            TOTAL MISSING: <span className="text-red-700">{totalMissingSubmissions} SUBMISSIONS</span>
          </div>
          <div className="bg-white px-3 py-1.5 border border-[#1B1C1A] rounded-[1px] font-bold text-xs">
            ASSIGNMENTS AFFECTED: <span className="text-[#059669]">{missingAssignmentsData.length}</span>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 1. DEFAULT VIEW: BY ASSIGNMENT                            */}
      {/* ========================================================= */}
      {viewMode === 'assignment' && (
        <div className="space-y-4">
          {filteredAssignments.map((asn) => {
            const isNudgedAll = nudgedAssignments.includes(asn.id);
            const isZeroedAll = zeroedAssignments.includes(asn.id);
            const isExpanded = expandedItems[asn.id] !== false;

            return (
              <div
                key={asn.id}
                className={`bg-white border-2 border-[#1B1C1A] rounded-[2px] transition-all overflow-hidden ${
                  isZeroedAll ? 'bg-gray-50 border-gray-400 opacity-90' : ''
                }`}
              >
                {/* Assignment Header Card */}
                <div className="p-4 bg-white border-b border-[#1B1C1A] flex flex-wrap items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2 py-0.5 bg-[#FEF08A] text-[#1B1C1A] font-extrabold text-[10px] border border-[#1B1C1A] uppercase">
                        {asn.missingStudents.length} STUDENTS MISSING
                      </span>
                      <span className="px-2 py-0.5 bg-[#FAF9F5] text-gray-700 font-bold text-[10px] border border-gray-300">
                        ID: {asn.asnCode}
                      </span>
                      <span className="px-2 py-0.5 bg-red-100 text-red-800 font-bold text-[10px] border border-red-300 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-red-600" />
                        {asn.daysOverdue} DAYS OVERDUE
                      </span>
                    </div>

                    <h3 className="font-extrabold text-base text-[#1B1C1A] uppercase tracking-tight">
                      {asn.assignmentName}
                    </h3>

                    <div className="flex items-center gap-4 text-xs font-mono text-gray-600 pt-0.5">
                      <span>DUE: <strong className="text-[#1B1C1A]">{asn.dueDate} 23:59</strong></span>
                      <span>•</span>
                      <span>POINTS: <strong className="text-[#059669]">{asn.pointsPossible} PT POSSIBLE</strong></span>
                    </div>
                  </div>

                  {/* Actions for this Assignment */}
                  <div className="flex flex-wrap items-center gap-2">
                    {/* Nudge All Button */}
                    <button
                      onClick={() => handleNudgeAllForAssignment(asn)}
                      className={`px-3 py-2 border border-[#1B1C1A] font-bold uppercase rounded-[2px] flex items-center gap-1.5 transition-all shadow-xs ${
                        isNudgedAll
                          ? 'bg-[#FEF08A] text-[#1B1C1A]'
                          : 'bg-[#059669] text-white hover:bg-emerald-700'
                      }`}
                    >
                      {isNudgedAll ? <Check className="w-3.5 h-3.5 text-[#059669]" /> : <Send className="w-3.5 h-3.5" />}
                      <span>{isNudgedAll ? 'NUDGED ALL STUDENTS' : `NUDGE ALL (${asn.missingStudents.length})`}</span>
                    </button>

                    {/* Grade as Zero Button */}
                    <button
                      onClick={() => handleGradeAsZeroForAssignment(asn)}
                      className={`px-3 py-2 border border-[#1B1C1A] font-bold uppercase rounded-[2px] flex items-center gap-1.5 transition-all shadow-xs ${
                        isZeroedAll
                          ? 'bg-gray-800 text-white'
                          : 'bg-red-600 text-white hover:bg-red-700'
                      }`}
                    >
                      {isZeroedAll ? <Check className="w-3.5 h-3.5" /> : <CheckSquare className="w-3.5 h-3.5" />}
                      <span>{isZeroedAll ? 'ALL GRADED AS ZERO' : `GRADE ALL AS ZERO`}</span>
                    </button>

                    <button
                      onClick={() => toggleExpand(asn.id)}
                      className="p-2 bg-[#FAF9F5] border border-[#1B1C1A] hover:bg-gray-100 rounded-[2px]"
                      title="Toggle Missing Students List"
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Missing Students Breakdown Drawer */}
                {isExpanded && (
                  <div className="bg-[#FAF9F5] p-3 border-t border-gray-200 divide-y divide-gray-200">
                    <span className="font-bold text-gray-500 text-[10px] uppercase block mb-2 px-1">
                      STUDENTS CURRENTLY MISSING THIS SUBMISSION ({asn.missingStudents.length}):
                    </span>

                    {asn.missingStudents.map((st) => {
                      const indKey = `${st.studentId}_${asn.id}`;
                      const isIndNudged = individualNudges.includes(indKey) || isNudgedAll;
                      const isIndZeroed = individualZeros.includes(indKey) || isZeroedAll;

                      return (
                        <div
                          key={st.studentId}
                          className="py-2 px-2 flex flex-wrap items-center justify-between gap-3 hover:bg-white rounded-[1px]"
                        >
                          <div className="flex items-center gap-2.5">
                            <div className="w-7 h-7 bg-red-100 border border-red-300 rounded-full flex items-center justify-center font-bold text-red-800 text-xs">
                              {st.studentName.charAt(0)}
                            </div>
                            <div>
                              <div className="font-bold text-[#1B1C1A]">{st.studentName}</div>
                              <div className="text-[10px] text-gray-500 font-mono">{st.email}</div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => handleIndividualNudge(st.studentId, asn.id, st.studentName)}
                              disabled={isIndNudged}
                              className={`px-2.5 py-1 border text-[10px] font-bold uppercase rounded-[1px] flex items-center gap-1 ${
                                isIndNudged
                                  ? 'bg-emerald-50 text-[#059669] border-emerald-300'
                                  : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-gray-100'
                              }`}
                            >
                              {isIndNudged ? <Check className="w-3 h-3 text-[#059669]" /> : <Send className="w-3 h-3" />}
                              <span>{isIndNudged ? 'NUDGED' : 'NUDGE'}</span>
                            </button>

                            <button
                              onClick={() => handleIndividualZero(st.studentId, asn.id, st.studentName)}
                              disabled={isIndZeroed}
                              className={`px-2.5 py-1 border text-[10px] font-bold uppercase rounded-[1px] flex items-center gap-1 ${
                                isIndZeroed
                                  ? 'bg-gray-200 text-gray-700 border-gray-400'
                                  : 'bg-white text-red-700 border-red-700 hover:bg-red-50'
                              }`}
                            >
                              {isIndZeroed ? <Check className="w-3 h-3" /> : <CheckSquare className="w-3 h-3" />}
                              <span>{isIndZeroed ? 'ZERO ENTERED' : 'ZERO'}</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ========================================================= */}
      {/* 2. VIEW BY STUDENT (Consolidated Nudge for Student, No Zero) */}
      {/* ========================================================= */}
      {viewMode === 'student' && (
        <div className="space-y-4">
          <div className="bg-[#FEF08A] border border-[#1B1C1A] p-3 rounded-[2px] text-xs font-bold text-[#1B1C1A] flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-800 shrink-0" />
            <span>
              NOTE: In Student View, you can nudge a student for all of their missing assignments in one click. Grade as Zero is performed at the Assignment level.
            </span>
          </div>

          {studentList.map((st) => {
            const isStudentNudged = nudgedStudents.includes(st.studentId);

            return (
              <div
                key={st.studentId}
                className="bg-white border-2 border-[#1B1C1A] rounded-[2px] p-4 space-y-3"
              >
                {/* Student Header */}
                <div className="border-b border-[#1B1C1A] pb-3 flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-[#059669] text-white border border-[#1B1C1A] rounded-[2px] flex items-center justify-center font-black text-base uppercase">
                      {st.studentName.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-extrabold text-base text-[#1B1C1A] uppercase tracking-tight">
                          {st.studentName}
                        </h3>
                        <span className="px-2 py-0.5 bg-red-100 text-red-800 font-bold text-[10px] border border-red-300 uppercase">
                          {st.assignments.length} MISSING ASSIGNMENTS
                        </span>
                      </div>
                      <div className="text-xs text-gray-500 font-mono">{st.email} · ID: {st.studentId}</div>
                    </div>
                  </div>

                  {/* Nudge Student Alone For All Assignments Button */}
                  <button
                    onClick={() => handleNudgeStudentAllAssignments(st.studentName, st.studentId, st.assignments.length)}
                    className={`px-4 py-2 border border-[#1B1C1A] font-bold uppercase rounded-[2px] flex items-center gap-2 transition-all shadow-xs ${
                      isStudentNudged
                        ? 'bg-[#FEF08A] text-[#1B1C1A]'
                        : 'bg-[#059669] text-white hover:bg-emerald-700'
                    }`}
                  >
                    {isStudentNudged ? <Check className="w-4 h-4 text-[#059669]" /> : <Send className="w-4 h-4" />}
                    <span>{isStudentNudged ? 'NUDGED FOR ALL WORK' : `NUDGE ${st.studentName.toUpperCase()} FOR ALL (${st.assignments.length})`}</span>
                  </button>
                </div>

                {/* List of Missing Assignments for this Student */}
                <div className="space-y-2 pt-1">
                  <span className="font-bold text-gray-500 text-[10px] uppercase block">
                    OUTSTANDING ASSIGNMENT SUBMISSIONS:
                  </span>

                  <div className="grid grid-cols-1 gap-2">
                    {st.assignments.map((asn) => {
                      const indKey = `${st.studentId}_${asn.id}`;
                      const isItemNudged = individualNudges.includes(indKey) || isStudentNudged || nudgedAssignments.includes(asn.id);

                      return (
                        <div
                          key={asn.id}
                          className="bg-[#FAF9F5] border border-gray-300 p-3 rounded-[1px] flex flex-wrap items-center justify-between gap-3"
                        >
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-[#1B1C1A]">{asn.assignmentName}</span>
                              <span className="text-[10px] font-bold text-gray-500">({asn.asnCode})</span>
                            </div>
                            <div className="text-[11px] font-mono text-gray-600 flex items-center gap-3">
                              <span>DUE: {asn.dueDate}</span>
                              <span className="text-red-700 font-bold">{asn.daysOverdue} DAYS OVERDUE</span>
                              <span className="text-[#059669] font-bold">{asn.pointsPossible} PTS</span>
                            </div>
                          </div>

                          <button
                            onClick={() => handleIndividualNudge(st.studentId, asn.id, st.studentName)}
                            disabled={isItemNudged}
                            className={`px-3 py-1 border text-xs font-bold uppercase rounded-[1px] flex items-center gap-1.5 ${
                              isItemNudged
                                ? 'bg-emerald-50 text-[#059669] border-emerald-300'
                                : 'bg-white text-[#1B1C1A] border-[#1B1C1A] hover:bg-gray-100'
                            }`}
                          >
                            {isItemNudged ? <Check className="w-3.5 h-3.5 text-[#059669]" /> : <Send className="w-3.5 h-3.5" />}
                            <span>{isItemNudged ? 'NUDGED' : 'NUDGE ITEM'}</span>
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
