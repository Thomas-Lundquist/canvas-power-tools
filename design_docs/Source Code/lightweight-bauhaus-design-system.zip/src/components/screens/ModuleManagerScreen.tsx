import React, { useState } from 'react';
import { INITIAL_MODULES } from '../../data/mockData';
import { CourseModule, ModuleItem } from '../../types';
import { Plus, GripVertical, CheckCircle, Circle, Edit2, Eye, Trash2, Video, FileText, ChevronDown, ChevronRight } from 'lucide-react';

export const ModuleManagerScreen: React.FC = () => {
  const [modules, setModules] = useState<CourseModule[]>(INITIAL_MODULES);
  const [showNewModuleModal, setShowNewModuleModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');

  const toggleExpand = (id: string) => {
    setModules(
      modules.map((m) => (m.id === id ? { ...m, expanded: !m.expanded } : m))
    );
  };

  const toggleStatus = (id: string) => {
    setModules(
      modules.map((m) =>
        m.id === id
          ? { ...m, status: m.status === 'PUBLISHED' ? 'DRAFT' : 'PUBLISHED' }
          : m
      )
    );
  };

  const toggleItemCompleted = (modId: string, itemId: string) => {
    setModules(
      modules.map((m) => {
        if (m.id === modId) {
          return {
            ...m,
            items: m.items.map((item) =>
              item.id === itemId ? { ...item, completed: !item.completed } : item
            )
          };
        }
        return m;
      })
    );
  };

  const handleAddModule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle) return;

    const newMod: CourseModule = {
      id: `mod-${Date.now()}`,
      number: `0${modules.length + 1}`,
      title: `Module 0${modules.length + 1}: ${newTitle}`,
      status: 'PUBLISHED',
      expanded: true,
      items: [
        { id: `item-${Date.now()}`, type: 'lecture', title: 'Lecture Intro & Overview', completed: false }
      ]
    };

    setModules([...modules, newMod]);
    setNewTitle('');
    setShowNewModuleModal(false);
  };

  const publishedCount = modules.filter((m) => m.status === 'PUBLISHED').length;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1B1C1A] pb-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-black text-[#1B1C1A] tracking-tight uppercase">
            Module Manager
          </h1>
          <p className="text-xs text-gray-600 mt-1">
            Curate and structure your resource flow.
          </p>
        </div>

        <button
          onClick={() => setShowNewModuleModal(true)}
          className="px-4 py-2 bg-[#0D9488] text-white border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px] hover:bg-[#0F766E] flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>CREATE MODULE</span>
        </button>
      </div>

      {/* Top Stat Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-[#FAF9F5] border border-[#1B1C1A] p-4 rounded-[2px]">
          <div className="text-xs font-mono font-bold text-gray-500 uppercase tracking-widest">
            TOTAL MODULES
          </div>
          <div className="text-4xl font-black text-[#1B1C1A] mt-1">
            {modules.length < 10 ? `0${modules.length}` : modules.length}
          </div>
        </div>

        <div className="bg-[#0D9488] border border-[#1B1C1A] p-4 rounded-[2px] text-white">
          <div className="text-xs font-mono font-bold uppercase tracking-widest opacity-90">
            PUBLISHED
          </div>
          <div className="text-4xl font-black mt-1">
            {publishedCount < 10 ? `0${publishedCount}` : publishedCount}
          </div>
        </div>
      </div>

      {/* Module Rows */}
      <div className="space-y-4">
        {modules.map((mod) => (
          <div
            key={mod.id}
            className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden"
          >
            {/* Module Title Bar */}
            <div className="bg-[#FAF9F5] border-b border-[#1B1C1A] p-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <button
                  onClick={() => toggleExpand(mod.id)}
                  className="p-1 hover:bg-[#EFEEEA] border border-[#1B1C1A] rounded-[2px]"
                >
                  <GripVertical className="w-4 h-4 text-gray-500" />
                </button>

                <div className="w-2.5 h-2.5 rounded-full bg-[#0D9488]" />

                <h3 className="text-sm font-bold text-[#1B1C1A] uppercase">
                  {mod.title}
                </h3>
              </div>

              <div className="flex items-center gap-3">
                {/* Status Switch */}
                <button
                  onClick={() => toggleStatus(mod.id)}
                  className={`px-2.5 py-1 border border-[#1B1C1A] rounded-[2px] text-xs font-bold uppercase flex items-center gap-1.5 transition-colors ${
                    mod.status === 'PUBLISHED'
                      ? 'bg-[#0D9488] text-white'
                      : 'bg-white text-[#1B1C1A]'
                  }`}
                >
                  <div className={`w-2 h-2 rounded-full ${mod.status === 'PUBLISHED' ? 'bg-white' : 'bg-gray-400'}`} />
                  <span>{mod.status}</span>
                </button>

                {/* Icons */}
                <div className="flex items-center gap-1 text-gray-600">
                  <button className="p-1 hover:bg-[#EFEEEA] border border-transparent hover:border-[#1B1C1A] rounded-[2px]">
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button className="p-1 hover:bg-[#EFEEEA] border border-transparent hover:border-[#1B1C1A] rounded-[2px]">
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                  <button className="p-1 hover:bg-[#EFEEEA] border border-transparent hover:border-[#1B1C1A] rounded-[2px]">
                    <Trash2 className="w-3.5 h-3.5 text-[#B7102A]" />
                  </button>
                </div>
              </div>
            </div>

            {/* Expandable Module Content Items */}
            {mod.expanded && (
              <div className="p-3 bg-white space-y-2">
                {mod.items.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => toggleItemCompleted(mod.id, item.id)}
                    className="border border-[#1B1C1A] p-2.5 rounded-[2px] bg-[#FAF9F5] hover:bg-[#EFEEEA] flex items-center justify-between cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      {item.type === 'video' ? (
                        <Video className="w-4 h-4 text-[#0D9488]" />
                      ) : (
                        <FileText className="w-4 h-4 text-[#0D9488]" />
                      )}
                      <span className="text-xs font-medium text-[#1B1C1A]">
                        {item.title}
                      </span>
                    </div>

                    <div>
                      {item.completed ? (
                        <CheckCircle className="w-4 h-4 text-[#059669]" />
                      ) : (
                        <Circle className="w-4 h-4 text-gray-400" />
                      )}
                    </div>
                  </div>
                ))}

                <button className="w-full py-2 border border-dashed border-[#1B1C1A] text-xs font-bold text-[#0D9488] uppercase tracking-wider rounded-[2px] hover:bg-[#FAF9F5]">
                  + ADD CONTENT ITEM
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Add Module Modal */}
      {showNewModuleModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <form
            onSubmit={handleAddModule}
            className="bg-white border-2 border-[#1B1C1A] rounded-[2px] w-full max-w-md p-6 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-3">
              <h3 className="text-base font-bold text-[#1B1C1A] uppercase">Create New Module</h3>
              <button
                type="button"
                onClick={() => setShowNewModuleModal(false)}
                className="text-xs font-bold border border-[#1B1C1A] px-2 py-0.5 rounded-[2px]"
              >
                ✕
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase mb-1">Module Title</label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g. Architectural Composition"
                className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs rounded-[2px]"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowNewModuleModal(false)}
                className="px-3 py-1.5 border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-[#0D9488] text-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]"
              >
                Create
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
