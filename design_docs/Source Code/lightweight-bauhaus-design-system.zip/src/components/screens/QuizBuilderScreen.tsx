import React, { useState } from 'react';
import {
  Code2,
  FileCode,
  Plus,
  Check,
  Upload,
  Play,
  HelpCircle,
  FileText,
  Copy,
  Trash2,
  AlertCircle
} from 'lucide-react';

interface Question {
  id: string;
  type: 'MC' | 'MA' | 'TF' | 'Essay' | 'Match' | 'FIB';
  stem: string;
  points: number;
  options?: string[];
  correctAnswer?: string;
}

export const QuizBuilderScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'editor' | 'markdown' | 'preview'>('markdown');
  const [quizTitle, setQuizTitle] = useState('Food Safety & Microbiology Basics');

  const [markdownText, setMarkdownText] = useState(`# Quiz: Food Safety & Microbiology Basics

## MC: Which temperature range is the Temperature Danger Zone? (2 pts)
- 0–32°F
* 41–135°F
- 135–212°F
> correct: Review the Temperature Danger Zone reference sheet.

## MA: Which foods are Time/Temperature Control for Safety (TCS)? (4 pts)
* Cooked rice
* Cut melons
- Dry flour
* Raw poultry

## TF (true): Chicken must reach 165°F internal temperature. (2 pts)

## Essay (5 pts): Explain how to prevent cross-contamination when prepping raw chicken in a commercial kitchen.

## Match: Match each food pathogen to its primary vehicle. (4 pts)
Salmonella = Raw poultry
E. coli = Undercooked ground beef
distractor: Cooked rice

## FIB: Minimum internal temperature for ground beef is {{155}}°F. (3 pts)
`);

  const [questions, setQuestions] = useState<Question[]>([
    { id: 'q-1', type: 'MC', stem: 'Which temperature range is the Temperature Danger Zone?', points: 2, options: ['0–32°F', '41–135°F', '135–212°F'], correctAnswer: '41–135°F' },
    { id: 'q-2', type: 'MA', stem: 'Which foods are Time/Temperature Control for Safety (TCS)?', points: 4, options: ['Cooked rice', 'Cut melons', 'Dry flour', 'Raw poultry'] },
    { id: 'q-3', type: 'TF', stem: 'Chicken must reach 165°F internal temperature.', points: 2, correctAnswer: 'True' },
    { id: 'q-4', type: 'Essay', stem: 'Explain how to prevent cross-contamination when prepping raw chicken in a commercial kitchen.', points: 5 },
    { id: 'q-5', type: 'Match', stem: 'Match each food pathogen to its primary vehicle.', points: 4 },
    { id: 'q-6', type: 'FIB', stem: 'Minimum internal temperature for ground beef is {{155}}°F.', points: 3 }
  ]);

  const [deployed, setDeployed] = useState(false);

  const totalPoints = questions.reduce((sum, q) => sum + q.points, 0);

  const handleParseMarkdown = () => {
    setActiveTab('preview');
  };

  const handleDeployToCanvas = () => {
    setDeployed(true);
    setTimeout(() => setDeployed(false), 3000);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            QUIZ BUILDER & MARKDOWN IMPORT
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Author New Quizzes visually or import plain text Quiz Markdown files. Deploys unpublished to Canvas.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono">
          <span className="px-3 py-1.5 bg-[#EFEEEA] border border-[#1B1C1A] text-xs font-bold uppercase">
            {questions.length} QUESTIONS · {totalPoints} PTS
          </span>

          <button
            onClick={handleDeployToCanvas}
            className={`px-4 py-2 border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] transition-all flex items-center gap-2 ${
              deployed
                ? 'bg-[#FEF08A] text-[#1B1C1A]'
                : 'bg-[#B7102A] text-white hover:bg-red-800'
            }`}
          >
            {deployed ? (
              <>
                <Check className="w-4 h-4 text-[#059669]" />
                <span>DEPLOYED UNPUBLISHED!</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                <span>DEPLOY TO CANVAS</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Mode Navigation Tabs */}
      <div className="flex border-b border-[#1B1C1A] bg-[#EFEEEA] p-1 gap-2 font-mono text-xs">
        <button
          onClick={() => setActiveTab('markdown')}
          className={`px-4 py-2 font-bold uppercase rounded-[2px] transition-all ${
            activeTab === 'markdown'
              ? 'bg-[#1B1C1A] text-[#FEF08A]'
              : 'text-gray-700 hover:bg-[#FAF9F5]'
          }`}
        >
          1. MARKDOWN IMPORT
        </button>

        <button
          onClick={() => setActiveTab('editor')}
          className={`px-4 py-2 font-bold uppercase rounded-[2px] transition-all ${
            activeTab === 'editor'
              ? 'bg-[#1B1C1A] text-[#FEF08A]'
              : 'text-gray-700 hover:bg-[#FAF9F5]'
          }`}
        >
          2. QUESTION EDITOR ({questions.length})
        </button>

        <button
          onClick={() => setActiveTab('preview')}
          className={`px-4 py-2 font-bold uppercase rounded-[2px] transition-all ${
            activeTab === 'preview'
              ? 'bg-[#1B1C1A] text-[#FEF08A]'
              : 'text-gray-700 hover:bg-[#FAF9F5]'
          }`}
        >
          3. QUIZ PREVIEW
        </button>
      </div>

      {/* Tab 1: Markdown Import */}
      {activeTab === 'markdown' && (
        <div className="space-y-4">
          <div className="bg-[#111210] text-[#FEF08A] border border-[#1B1C1A] rounded-[2px] p-4 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-[#262724] pb-2 mb-3">
              <span className="font-bold uppercase flex items-center gap-2">
                <FileCode className="w-4 h-4 text-[#38BDF8]" />
                <span>QUIZ MARKDOWN SPECIFICATION EDITOR</span>
              </span>
              <button
                onClick={handleParseMarkdown}
                className="px-3 py-1 bg-[#FEF08A] text-[#1B1C1A] font-bold text-xs uppercase rounded-[1px] hover:bg-yellow-300"
              >
                PARSE & PREVIEW
              </button>
            </div>

            <textarea
              value={markdownText}
              onChange={(e) => setMarkdownText(e.target.value)}
              rows={16}
              className="w-full bg-transparent text-gray-200 font-mono text-xs outline-none resize-none leading-relaxed"
            />
          </div>

          <div className="p-3 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] text-xs font-mono text-gray-700 flex items-center justify-between">
            <span>SYNTAX LEGEND: ## MC: Multiple Choice | ## MA: Multi Answer | ## TF: True/False | ## Essay | ## Match | ## FIB</span>
            <span className="text-[#2563EB] font-bold">100% Canvas New Quizzes REST API Compliant</span>
          </div>
        </div>
      )}

      {/* Tab 2: Visual Question Editor */}
      {activeTab === 'editor' && (
        <div className="bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-gray-200 pb-3">
            <h3 className="font-bold font-mono text-xs uppercase text-gray-600">
              QUESTION LIST ({questions.length} ITEMS)
            </h3>
            <button
              onClick={() => {
                const newQ: Question = {
                  id: `q-${Date.now()}`,
                  type: 'MC',
                  stem: 'New Quiz Question Stem...',
                  points: 2,
                  options: ['Option A', 'Option B']
                };
                setQuestions([...questions, newQ]);
              }}
              className="px-3 py-1.5 bg-[#2563EB] text-white font-mono font-bold text-xs uppercase rounded-[2px] flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>ADD QUESTION</span>
            </button>
          </div>

          <div className="space-y-3">
            {questions.map((q, idx) => (
              <div key={q.id} className="p-4 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] space-y-2">
                <div className="flex items-center justify-between font-mono text-xs">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 bg-[#1B1C1A] text-white font-bold text-[10px]">
                      Q{idx + 1} · {q.type}
                    </span>
                    <span className="font-bold text-gray-600">{q.points} PTS</span>
                  </div>
                  <button
                    onClick={() => setQuestions(questions.filter((item) => item.id !== q.id))}
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <p className="font-bold text-sm text-[#1B1C1A]">{q.stem}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Rendered Quiz Preview */}
      {activeTab === 'preview' && (
        <div className="bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-6">
          <div className="border-b border-gray-200 pb-4">
            <span className="text-xs font-mono font-bold uppercase text-[#2563EB]">
              PREVIEW RENDER
            </span>
            <h2 className="text-2xl font-black text-[#1B1C1A] uppercase mt-1">{quizTitle}</h2>
          </div>

          <div className="space-y-4 font-sans">
            {questions.map((q, idx) => (
              <div key={q.id} className="p-4 border border-[#1B1C1A] rounded-[2px] bg-[#FAF9F5] space-y-2">
                <div className="flex items-center justify-between font-mono text-xs border-b border-gray-200 pb-2">
                  <span className="font-bold text-[#1B1C1A]">QUESTION {idx + 1} ({q.type})</span>
                  <span className="font-bold text-[#2563EB]">{q.points} POINTS</span>
                </div>
                <p className="font-medium text-sm text-[#1B1C1A] pt-1">{q.stem}</p>
                {q.options && (
                  <div className="space-y-1 pl-4 pt-2 font-mono text-xs text-gray-700">
                    {q.options.map((opt, oIdx) => (
                      <div key={oIdx} className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full border border-gray-500 inline-block"></span>
                        <span>{opt}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
