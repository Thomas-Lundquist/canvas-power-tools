import React, { useState } from 'react';
import { ArrowRight, RotateCw, CheckCircle2, AlertCircle } from 'lucide-react';

export const RolloverWizardScreen: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<number>(2);
  const [sourceCourse, setSourceCourse] = useState('Intro to Psychology 101 (Fall 2026)');
  const [targetCourse, setTargetCourse] = useState('Intro to Psychology 101 (Fall 2027)');
  const [autoShiftDates, setAutoShiftDates] = useState(true);
  
  const [components, setComponents] = useState({
    syllabus: true,
    assignments: true,
    quizzes: false
  });

  const [wizardSuccess, setWizardSuccess] = useState(false);

  const toggleComponent = (key: keyof typeof components) => {
    setComponents({ ...components, [key]: !components[key] });
  };

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    } else {
      setWizardSuccess(true);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1B1C1A] pb-4">
        <div>
          <div className="text-xs font-bold text-[#B7102A] uppercase tracking-wider mb-1">
            SEMESTER MIGRATION ENGINE
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-[#1B1C1A] tracking-tight uppercase">
            Rollover Wizard
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentStep(1)}
            className="px-3 py-1.5 bg-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-[#EFEEEA]"
          >
            DISCARD
          </button>
          <button
            onClick={handleNext}
            className="px-4 py-1.5 bg-[#1B1C1A] text-white border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px] hover:bg-black flex items-center gap-1.5"
          >
            <span>{currentStep === 3 ? "EXECUTE ROLLOVER" : "NEXT STEP"}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {wizardSuccess && (
        <div className="bg-[#059669] text-white p-4 border border-[#1B1C1A] rounded-[2px] text-xs font-bold flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" />
            <span>MIGRATION EXECUTED SUCCESSFULLY! COURSE CONTENT TRANSFERRED TO TARGET TERM.</span>
          </div>
          <button onClick={() => setWizardSuccess(false)} className="underline">Dismiss</button>
        </div>
      )}

      {/* Main Grid: Left Stepper Navigation + Right Step Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: 3-Step Process List */}
        <div className="lg:col-span-4 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] p-5 space-y-6">
          <div>
            <h3 className="text-lg font-bold text-[#1B1C1A] uppercase tracking-tight">
              Rollover Wizard
            </h3>
            <p className="text-xs text-gray-600 mt-1 leading-relaxed">
              Configure the semester transition process for your institutional sub-accounts.
            </p>
          </div>

          <div className="space-y-4">
            {/* Step 1 */}
            <div
              onClick={() => setCurrentStep(1)}
              className={`flex items-start gap-3 p-3 border rounded-[2px] cursor-pointer transition-colors ${
                currentStep === 1
                  ? 'bg-white border-[#1B1C1A] border-l-4 border-l-[#B7102A]'
                  : 'bg-transparent border-transparent opacity-70 hover:opacity-100'
              }`}
            >
              <div
                className={`w-7 h-7 rounded-full border border-[#1B1C1A] flex items-center justify-center font-bold text-xs ${
                  currentStep === 1 ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A]'
                }`}
              >
                1
              </div>
              <div>
                <div className="text-xs font-bold text-[#1B1C1A] uppercase">DISCOVERY</div>
                <div className="text-xs text-gray-500">Analyze existing data</div>
              </div>
            </div>

            {/* Step 2 */}
            <div
              onClick={() => setCurrentStep(2)}
              className={`flex items-start gap-3 p-3 border rounded-[2px] cursor-pointer transition-colors ${
                currentStep === 2
                  ? 'bg-white border-[#1B1C1A] border-l-4 border-l-[#B7102A]'
                  : 'bg-transparent border-transparent opacity-70 hover:opacity-100'
              }`}
            >
              <div
                className={`w-7 h-7 rounded-full border border-[#1B1C1A] flex items-center justify-center font-bold text-xs ${
                  currentStep === 2 ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A]'
                }`}
              >
                2
              </div>
              <div>
                <div className="text-xs font-bold text-[#1B1C1A] uppercase">WIZARD (MAPPING)</div>
                <div className="text-xs text-gray-500">Source & destination map</div>
              </div>
            </div>

            {/* Step 3 */}
            <div
              onClick={() => setCurrentStep(3)}
              className={`flex items-start gap-3 p-3 border rounded-[2px] cursor-pointer transition-colors ${
                currentStep === 3
                  ? 'bg-white border-[#1B1C1A] border-l-4 border-l-[#B7102A]'
                  : 'bg-transparent border-transparent opacity-70 hover:opacity-100'
              }`}
            >
              <div
                className={`w-7 h-7 rounded-full border border-[#1B1C1A] flex items-center justify-center font-bold text-xs ${
                  currentStep === 3 ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A]'
                }`}
              >
                3
              </div>
              <div>
                <div className="text-xs font-bold text-[#1B1C1A] uppercase">SETTINGS</div>
                <div className="text-xs text-gray-500">Finalize configuration</div>
              </div>
            </div>
          </div>

          <div className="border-t border-[#1B1C1A] pt-4 flex items-center justify-between text-xs font-mono">
            <span className="text-gray-500">B4 Archetype System</span>
            <span className="font-bold text-[#059669]">ACTIVE</span>
          </div>
        </div>

        {/* Right Column: Active Step Content */}
        <div className="lg:col-span-8 bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-6">
          <div className="border-b border-[#E3E2DF] pb-3">
            <span className="text-xs font-mono font-bold tracking-widest text-gray-500 uppercase">
              STEP {currentStep} OF 3
            </span>
            <h2 className="text-2xl font-black text-[#1B1C1A] tracking-tight uppercase mt-0.5">
              {currentStep === 1 && "Course Discovery"}
              {currentStep === 2 && "Configuration Fields"}
              {currentStep === 3 && "Review & Execution"}
            </h2>
          </div>

          {currentStep === 2 && (
            <div className="space-y-6">
              {/* Source vs Target Course Selectors */}
              <div className="grid grid-cols-1 md:grid-cols-2 border border-[#1B1C1A] rounded-[2px] divide-y md:divide-y-0 md:divide-x divide-[#1B1C1A]">
                <div className="p-4 bg-[#FAF9F5]">
                  <label className="block text-xs font-bold text-gray-600 uppercase tracking-wider mb-2">
                    SOURCE COURSE
                  </label>
                  <select
                    value={sourceCourse}
                    onChange={(e) => setSourceCourse(e.target.value)}
                    className="w-full bg-white border border-[#1B1C1A] text-xs font-bold p-2 rounded-[2px] focus:outline-none"
                  >
                    <option>Intro to Psychology 101 (Fall 2026)</option>
                    <option>CS101: Intro to Computer Science</option>
                  </select>
                  <p className="text-xs italic text-gray-500 mt-2">
                    Note: Only archived courses with &apos;Final&apos; status appear here.
                  </p>
                </div>

                <div className="p-4 bg-[#FAF9F5]">
                  <label className="block text-xs font-bold text-gray-600 uppercase tracking-wider mb-2">
                    TARGET COURSE
                  </label>
                  <select
                    value={targetCourse}
                    onChange={(e) => setTargetCourse(e.target.value)}
                    className="w-full bg-white border border-[#1B1C1A] text-xs font-bold p-2 rounded-[2px] focus:outline-none"
                  >
                    <option>Intro to Psychology 101 (Fall 2027)</option>
                    <option>CS102: Data Structures & Algorithms</option>
                  </select>
                </div>
              </div>

              {/* Auto-Shift Dates Toggle */}
              <div className="border border-[#1B1C1A] p-4 rounded-[2px] bg-[#FAF9F5] flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-[#1B1C1A] uppercase tracking-wider">
                    Auto-Shift Dates
                  </h4>
                  <p className="text-xs text-gray-600 mt-0.5">
                    Automatically adjust assignment and module deadlines based on the new term start date.
                  </p>
                </div>

                <button
                  onClick={() => setAutoShiftDates(!autoShiftDates)}
                  className={`flex items-center gap-2 px-3 py-1.5 border border-[#1B1C1A] rounded-[2px] text-xs font-bold uppercase transition-colors ${
                    autoShiftDates ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A]'
                  }`}
                >
                  <div className={`w-3 h-3 rounded-full ${autoShiftDates ? 'bg-[#059669]' : 'bg-gray-400'}`} />
                  <span>{autoShiftDates ? 'ENABLED' : 'DISABLED'}</span>
                </button>
              </div>

              {/* Migration Components Checkboxes */}
              <div className="border border-[#1B1C1A] p-4 rounded-[2px] bg-white space-y-3">
                <h4 className="text-xs font-bold text-gray-600 uppercase tracking-wider">
                  MIGRATION COMPONENTS
                </h4>

                {/* Checkbox item 1 */}
                <div
                  onClick={() => toggleComponent('syllabus')}
                  className="border border-[#1B1C1A] p-3 rounded-[2px] bg-[#FAF9F5] flex items-start gap-3 cursor-pointer hover:bg-[#EFEEEA]"
                >
                  <div
                    className={`w-4 h-4 mt-0.5 border border-[#1B1C1A] rounded-[2px] flex items-center justify-center font-bold text-xs ${
                      components.syllabus ? 'bg-[#1B1C1A] text-white' : 'bg-white'
                    }`}
                  >
                    {components.syllabus && '✓'}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-[#1B1C1A] uppercase">
                      SYLLABUS & COURSE MODULES
                    </div>
                    <div className="text-xs text-gray-600">
                      Include all structural components and learning objects.
                    </div>
                  </div>
                </div>

                {/* Checkbox item 2 */}
                <div
                  onClick={() => toggleComponent('assignments')}
                  className="border border-[#1B1C1A] p-3 rounded-[2px] bg-[#FAF9F5] flex items-start gap-3 cursor-pointer hover:bg-[#EFEEEA]"
                >
                  <div
                    className={`w-4 h-4 mt-0.5 border border-[#1B1C1A] rounded-[2px] flex items-center justify-center font-bold text-xs ${
                      components.assignments ? 'bg-[#1B1C1A] text-white' : 'bg-white'
                    }`}
                  >
                    {components.assignments && '✓'}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-[#1B1C1A] uppercase">
                      ASSIGNMENTS & RUBRICS
                    </div>
                    <div className="text-xs text-gray-600">
                      Include grading schemas and outcome mapping.
                    </div>
                  </div>
                </div>

                {/* Checkbox item 3 */}
                <div
                  onClick={() => toggleComponent('quizzes')}
                  className="border border-[#1B1C1A] p-3 rounded-[2px] bg-[#FAF9F5] flex items-start gap-3 cursor-pointer hover:bg-[#EFEEEA]"
                >
                  <div
                    className={`w-4 h-4 mt-0.5 border border-[#1B1C1A] rounded-[2px] flex items-center justify-center font-bold text-xs ${
                      components.quizzes ? 'bg-[#1B1C1A] text-white' : 'bg-white'
                    }`}
                  >
                    {components.quizzes && '✓'}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-[#1B1C1A] uppercase">
                      QUIZZES & QUESTION BANKS
                    </div>
                    <div className="text-xs text-gray-600">
                      Include all quiz types, settings, and linked question repositories.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentStep === 1 && (
            <div className="p-6 border border-[#1B1C1A] bg-[#FAF9F5] text-center space-y-3">
              <RotateCw className="w-8 h-8 text-[#B7102A] mx-auto" />
              <h3 className="text-base font-bold text-[#1B1C1A] uppercase">Discovery Scan Complete</h3>
              <p className="text-xs text-gray-600 max-w-md mx-auto">
                Scanning target sub-accounts... Found 14 archive courses eligible for rollover in Fall 2027.
              </p>
              <button
                onClick={() => setCurrentStep(2)}
                className="mt-2 px-4 py-2 bg-[#1B1C1A] text-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]"
              >
                Proceed to Configuration
              </button>
            </div>
          )}

          {currentStep === 3 && (
            <div className="p-6 border border-[#1B1C1A] bg-[#FAF9F5] space-y-4">
              <h3 className="text-sm font-bold text-[#1B1C1A] uppercase">Migration Summary</h3>
              <ul className="text-xs space-y-2 font-mono">
                <li>• Source: {sourceCourse}</li>
                <li>• Target: {targetCourse}</li>
                <li>• Shift Deadlines: {autoShiftDates ? "YES (+365 Days)" : "NO"}</li>
                <li>• Modules included: {components.syllabus ? "YES" : "NO"}</li>
                <li>• Assignments included: {components.assignments ? "YES" : "NO"}</li>
                <li>• Quizzes included: {components.quizzes ? "YES" : "NO"}</li>
              </ul>
              <button
                onClick={handleNext}
                className="w-full py-3 bg-[#B7102A] text-white border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px]"
              >
                Confirm & Execute Rollover
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
