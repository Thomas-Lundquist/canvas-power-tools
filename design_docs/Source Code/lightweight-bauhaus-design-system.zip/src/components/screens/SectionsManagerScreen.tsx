import React, { useState } from 'react';
import {
  Users,
  Calendar,
  Check,
  BarChart3,
  Layers,
  FileText
} from 'lucide-react';

export const SectionsManagerScreen: React.FC = () => {
  const [sections, setSections] = useState([
    { id: 'sec-1', name: 'Section 001 - MWF Morning', studentsCount: 28, dueDate: '2026-07-28', avgScore: 86.2 },
    { id: 'sec-2', name: 'Section 002 - TR Afternoon', studentsCount: 32, dueDate: '2026-07-29', avgScore: 84.5 },
    { id: 'sec-3', name: 'Section 003 - Online Asynchronous', studentsCount: 45, dueDate: '2026-07-31', avgScore: 89.1 }
  ]);

  const [saved, setSaved] = useState(false);

  const handleDateChange = (id: string, newDate: string) => {
    setSections(sections.map((s) => (s.id === id ? { ...s, dueDate: newDate } : s)));
  };

  const handleSaveSections = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            SECTIONS & CROSS-SECTION MANAGER
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Set section-level due dates across assignments and compare grade distributions side-by-side.
          </p>
        </div>

        <button
          onClick={handleSaveSections}
          className={`px-4 py-2 border border-[#1B1C1A] font-mono font-bold text-xs uppercase rounded-[2px] transition-all flex items-center gap-2 ${
            saved ? 'bg-[#FEF08A] text-[#1B1C1A]' : 'bg-[#0D9488] text-white hover:bg-teal-700'
          }`}
        >
          {saved ? (
            <>
              <Check className="w-4 h-4 text-[#1B1C1A]" />
              <span>DATES SAVED TO CANVAS!</span>
            </>
          ) : (
            <>
              <Calendar className="w-4 h-4" />
              <span>SAVE SECTION DATES</span>
            </>
          )}
        </button>
      </div>

      {/* Sections Table */}
      <div className="bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-4">
        <h3 className="font-mono font-bold text-xs uppercase text-gray-500 border-b border-gray-200 pb-2">
          SECTION DUE DATES & PERFORMANCE MATRIX
        </h3>

        <div className="space-y-3 font-mono text-xs">
          {sections.map((s) => (
            <div key={s.id} className="p-4 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] flex flex-wrap items-center justify-between gap-4">
              <div>
                <h4 className="font-bold text-sm text-[#1B1C1A]">{s.name}</h4>
                <span className="text-[10px] text-gray-500">{s.studentsCount} Enrolled Students</span>
              </div>

              <div className="flex items-center gap-6">
                <div>
                  <span className="text-[10px] text-gray-500 block uppercase">AVG SCORE</span>
                  <span className="font-bold text-[#0D9488] text-sm">{s.avgScore}%</span>
                </div>

                <div>
                  <span className="text-[10px] text-gray-500 block uppercase mb-1">SECTION DUE DATE</span>
                  <input
                    type="date"
                    value={s.dueDate}
                    onChange={(e) => handleDateChange(s.id, e.target.value)}
                    className="p-1.5 bg-white border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
