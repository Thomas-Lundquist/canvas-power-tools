import React, { useState } from 'react';
import {
  ShieldAlert,
  Lock,
  Clock,
  Check,
  FileText,
  Key,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

interface AuditLogEntry {
  id: string;
  timestamp: string;
  action: string;
  summary: string;
  courseName: string;
  pinVerified: boolean;
}

export const SecurityAuditScreen: React.FC = () => {
  const [pinEnabled, setPinEnabled] = useState(true);
  const [pinMode, setPinMode] = useState<'inactivity' | 'every_write'>('inactivity');
  const [inactivityMinutes, setInactivityMinutes] = useState(30);

  const [auditLogs] = useState<AuditLogEntry[]>([
    { id: 'aud-1', timestamp: '2026-07-23 19:42:10', action: 'bulk_edit', summary: 'Shifted due dates on 4 assignments', courseName: 'Biology 101 - Fall 2025', pinVerified: true },
    { id: 'aud-2', timestamp: '2026-07-22 14:15:00', action: 'accommodation_override', summary: 'Applied 3-day extension for Jane Smith', courseName: 'Biology 101 - Fall 2025', pinVerified: true },
    { id: 'aud-3', timestamp: '2026-07-20 11:05:30', action: 'message_sent', summary: 'Sent missing assignment nudges to 3 students', courseName: 'Biology 101 - Fall 2025', pinVerified: true }
  ]);

  const [saved, setSaved] = useState(false);

  const handleSaveSecurity = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            PIN SECURITY & AUDIT TRAIL LOG
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Configure PIN protection for Canvas write operations and review the 50-entry local audit log.
          </p>
        </div>

        <button
          onClick={handleSaveSecurity}
          className={`px-4 py-2 border border-[#1B1C1A] font-mono font-bold text-xs uppercase rounded-[2px] transition-all flex items-center gap-2 ${
            saved ? 'bg-[#FEF08A] text-[#1B1C1A]' : 'bg-[#1B1C1A] text-white hover:bg-gray-800'
          }`}
        >
          {saved ? (
            <>
              <Check className="w-4 h-4 text-[#059669]" />
              <span>SECURITY PREFERENCES SAVED!</span>
            </>
          ) : (
            <>
              <Lock className="w-4 h-4" />
              <span>SAVE SECURITY CONFIG</span>
            </>
          )}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Security Settings */}
        <div className="lg:col-span-5 bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-4 font-mono text-xs">
          <h3 className="font-bold uppercase text-[#1B1C1A] border-b border-gray-200 pb-2">
            PIN PROTECTION CONFIGURATION
          </h3>

          <div className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[2px] flex items-center justify-between">
            <span className="font-bold text-[#1B1C1A]">PIN Protection Enabled</span>
            <input
              type="checkbox"
              checked={pinEnabled}
              onChange={(e) => setPinEnabled(e.target.checked)}
              className="w-4 h-4 accent-[#1B1C1A]"
            />
          </div>

          <div>
            <label className="block font-bold text-gray-600 uppercase mb-1">PIN Mode:</label>
            <select
              value={pinMode}
              onChange={(e) => setPinMode(e.target.value as any)}
              className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
            >
              <option value="inactivity">Lock After Inactivity Period</option>
              <option value="every_write">Require PIN on Every Canvas Write</option>
            </select>
          </div>

          <div>
            <label className="block font-bold text-gray-600 uppercase mb-1">Inactivity Timeout (Minutes):</label>
            <input
              type="number"
              value={inactivityMinutes}
              onChange={(e) => setInactivityMinutes(parseInt(e.target.value) || 15)}
              className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
            />
          </div>
        </div>

        {/* Audit Trail Log */}
        <div className="lg:col-span-7 bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-gray-200 pb-2">
            <h3 className="font-bold uppercase text-[#1B1C1A]">LOCAL AUDIT TRAIL LOG ({auditLogs.length})</h3>
            <span className="text-[10px] text-gray-500">LAST 50 OPERATIONS STORED</span>
          </div>

          <div className="space-y-2">
            {auditLogs.map((log) => (
              <div key={log.id} className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[2px] space-y-1">
                <div className="flex items-center justify-between text-[10px] text-gray-500">
                  <span className="font-bold text-[#1B1C1A] uppercase">{log.action}</span>
                  <span>{log.timestamp}</span>
                </div>
                <p className="font-bold text-xs text-[#1B1C1A]">{log.summary}</p>
                <div className="flex items-center justify-between text-[10px] text-gray-500 pt-1">
                  <span>Course: {log.courseName}</span>
                  {log.pinVerified && (
                    <span className="text-[#059669] font-bold flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> PIN VERIFIED
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
