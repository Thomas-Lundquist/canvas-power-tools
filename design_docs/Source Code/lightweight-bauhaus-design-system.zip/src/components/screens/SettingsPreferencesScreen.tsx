import React, { useState, useEffect } from 'react';
import {
  Settings,
  Key,
  Check,
  Download,
  Upload,
  RefreshCw,
  Database,
  Sliders,
  ShieldCheck,
  Terminal,
  FileText,
  GraduationCap,
  Users,
  Megaphone,
  FolderKanban,
  Lock,
  Zap,
  AlertCircle,
  HelpCircle,
  CheckCircle2,
  Trash2,
  Eye,
  EyeOff,
  Server
} from 'lucide-react';

export const SettingsPreferencesScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('all');

  // 1. Canvas API & Connection Settings
  const [canvasUrl, setCanvasUrl] = useState('https://canvas.instructure.com');
  const [apiToken, setApiToken] = useState('78901~aB3cD4eF5gH6iJ7kL8mN9oP0qR1sT2uV3wX4yZ5aB6');
  const [showToken, setShowToken] = useState(false);
  const [apiConnectionStatus, setApiConnectionStatus] = useState<'connected' | 'testing' | 'error'>('connected');
  const [autoRetry429, setAutoRetry429] = useState(true);

  // 2. Assignments Module Settings
  const [defaultSubmissionType, setDefaultSubmissionType] = useState('Online');
  const [autoPublishNewAssignments, setAutoPublishNewAssignments] = useState(true);
  const [defaultTurnitinScan, setDefaultTurnitinScan] = useState(true);
  const [defaultPointsPossible, setDefaultPointsPossible] = useState(100);
  const [allowedExtensions, setAllowedExtensions] = useState('pdf, docx, zip');

  // 3. Grading Module Settings
  const [latePenaltyPerDay, setLatePenaltyPerDay] = useState(5.0);
  const [maxLatePenaltyCap, setMaxLatePenaltyCap] = useState(50.0);
  const [missingWorkGraceHours, setMissingWorkGraceHours] = useState(24);
  const [enableSpeedGraderCommentBank, setEnableSpeedGraderCommentBank] = useState(true);
  const [curvingRoundingRule, setCurvingRoundingRule] = useState('STANDARD');

  // 4. People & Roster Settings
  const [ferpaMaskEnabled, setFerpaMaskEnabled] = useState(false);
  const [inactivityThresholdDays, setInactivityThresholdDays] = useState(7);
  const [photoThumbnailQuality, setPhotoThumbnailQuality] = useState('STANDARD');
  const [nameFormat, setNameFormat] = useState('LAST_FIRST');

  // 5. Communication & Nudges Settings
  const [outboundProvider, setOutboundProvider] = useState('CANVAS_INBOX');
  const [nudgeRateLimit, setNudgeRateLimit] = useState(50);
  const [quietHoursEnabled, setQuietHoursEnabled] = useState(true);
  const [officeHoursLink, setOfficeHoursLink] = useState('https://zoom.us/j/9876543210');

  // 6. Content & Modules Settings
  const [autoLockCompletedModules, setAutoLockCompletedModules] = useState(false);
  const [brokenLinkScanFrequency, setBrokenLinkScanFrequency] = useState('WEEKLY');
  const [enforcePrerequisites, setEnforcePrerequisites] = useState(true);

  // 7. Admin & Security
  const [inactivityLockTimeout, setInactivityLockTimeout] = useState('30_MIN');
  const [pinProtectionForGrades, setPinProtectionForGrades] = useState(true);
  const [auditLogRetention, setAuditLogRetention] = useState('90_DAYS');

  // 8. Global UI & Developer Preferences
  const [themeMode, setThemeMode] = useState<'bauhaus' | 'accessible'>('bauhaus');
  const [apiRequestDelayMs, setApiRequestDelayMs] = useState(150);
  const [logLevel, setLogLevel] = useState('INFO');
  const [developerUnlocked, setDeveloperUnlocked] = useState(false);
  const [devClicks, setDeveloperClicks] = useState(0);

  // UI Toast State
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const handleVersionClick = () => {
    const next = devClicks + 1;
    setDeveloperClicks(next);
    if (next >= 7) {
      setDeveloperUnlocked(true);
      showToast('DEVELOPER MODE UNLOCKED! REST API ENGINE CONTROLS EXPOSED.');
    }
  };

  const handleTestConnection = () => {
    setApiConnectionStatus('testing');
    setTimeout(() => {
      setApiConnectionStatus('connected');
      showToast('CANVAS API CONNECTION VERIFIED (HTTP 200 OK — REST API v1)');
    }, 1200);
  };

  const handleSaveAll = () => {
    const configData = {
      canvasUrl,
      defaultSubmissionType,
      autoPublishNewAssignments,
      latePenaltyPerDay,
      ferpaMaskEnabled,
      outboundProvider,
      enforcePrerequisites,
      themeMode,
      updatedAt: new Date().toISOString()
    };
    localStorage.setItem('canvas_power_tools_settings', JSON.stringify(configData));
    showToast('ALL MODULE PREFERENCES SAVED TO LOCAL STORAGE SUCCESSFULLY!');
  };

  const handleExportJSON = () => {
    const fullConfig = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      connection: { canvasUrl, autoRetry429 },
      assignments: { defaultSubmissionType, autoPublishNewAssignments, defaultTurnitinScan, defaultPointsPossible, allowedExtensions },
      grading: { latePenaltyPerDay, maxLatePenaltyCap, missingWorkGraceHours, enableSpeedGraderCommentBank, curvingRoundingRule },
      people: { ferpaMaskEnabled, inactivityThresholdDays, photoThumbnailQuality, nameFormat },
      communication: { outboundProvider, nudgeRateLimit, quietHoursEnabled, officeHoursLink },
      content: { autoLockCompletedModules, brokenLinkScanFrequency, enforcePrerequisites },
      admin: { inactivityLockTimeout, pinProtectionForGrades, auditLogRetention },
      developer: { themeMode, apiRequestDelayMs, logLevel }
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(fullConfig, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `canvas_power_tools_settings_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    showToast('SETTINGS CONFIGURATION EXPORTED TO JSON FILE!');
  };

  const handleResetDefaults = () => {
    if (window.confirm('Are you sure you want to reset all module settings to default values?')) {
      setCanvasUrl('https://canvas.instructure.com');
      setThemeMode('bauhaus');
      setLatePenaltyPerDay(5.0);
      setMaxLatePenaltyCap(50.0);
      setFerpaMaskEnabled(false);
      setAutoPublishNewAssignments(true);
      setDefaultTurnitinScan(true);
      setOutboundProvider('CANVAS_INBOX');
      setEnforcePrerequisites(true);
      showToast('RESET ALL MODULE PREFERENCES TO FACTORY DEFAULTS!');
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn font-mono text-xs">
      {/* Toast Notification Banner */}
      {toastMsg && (
        <div className="bg-[#FEF08A] border-2 border-[#1B1C1A] p-3 rounded-[2px] font-mono text-xs font-bold text-[#1B1C1A] flex items-center justify-between shadow-xs animate-bounce">
          <div className="flex items-center gap-2 uppercase">
            <CheckCircle2 className="w-4 h-4 text-[#059669]" />
            <span>{toastMsg}</span>
          </div>
          <button onClick={() => setToastMsg(null)} className="hover:text-red-700">✕</button>
        </div>
      )}

      {/* Main Screen Header */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            POWER TOOLS SETTINGS & CONFIGURATION
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Configure rules, thresholds, API connections, and preferences for all 6 Canvas Power Tools modules.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportJSON}
            className="px-3 py-2 bg-white border border-[#1B1C1A] font-bold text-xs uppercase rounded-[2px] hover:bg-gray-100 flex items-center gap-1.5 shadow-xs transition-all"
          >
            <Download className="w-3.5 h-3.5 text-[#2563EB]" />
            <span>EXPORT JSON</span>
          </button>

          <button
            onClick={handleSaveAll}
            className="px-5 py-2 bg-[#1B1C1A] text-white font-black text-xs uppercase rounded-[2px] hover:bg-gray-800 flex items-center gap-2 shadow-xs transition-all"
          >
            <Check className="w-4 h-4 text-[#FEF08A]" />
            <span>SAVE ALL SETTINGS</span>
          </button>
        </div>
      </div>

      {/* Navigation Module Tab Switcher */}
      <div className="bg-[#FAF9F5] border border-[#1B1C1A] p-2 rounded-[2px] flex flex-wrap items-center gap-1">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-3 py-1.5 font-bold uppercase rounded-[1px] border transition-all ${
            activeTab === 'all'
              ? 'bg-[#1B1C1A] text-white border-[#1B1C1A]'
              : 'bg-white text-gray-700 border-gray-300 hover:border-[#1B1C1A]'
          }`}
        >
          SHOW ALL MODULES
        </button>

        <button
          onClick={() => setActiveTab('api')}
          className={`px-3 py-1.5 font-bold uppercase rounded-[1px] border transition-all flex items-center gap-1.5 ${
            activeTab === 'api'
              ? 'bg-[#2563EB] text-white border-[#1B1C1A]'
              : 'bg-white text-gray-700 border-gray-300 hover:border-[#1B1C1A]'
          }`}
        >
          <Key className="w-3.5 h-3.5" />
          <span>1. CANVAS API</span>
        </button>

        <button
          onClick={() => setActiveTab('assignments')}
          className={`px-3 py-1.5 font-bold uppercase rounded-[1px] border transition-all flex items-center gap-1.5 ${
            activeTab === 'assignments'
              ? 'bg-[#2563EB] text-white border-[#1B1C1A]'
              : 'bg-white text-gray-700 border-gray-300 hover:border-[#1B1C1A]'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>2. ASSIGNMENTS</span>
        </button>

        <button
          onClick={() => setActiveTab('grading')}
          className={`px-3 py-1.5 font-bold uppercase rounded-[1px] border transition-all flex items-center gap-1.5 ${
            activeTab === 'grading'
              ? 'bg-[#059669] text-white border-[#1B1C1A]'
              : 'bg-white text-gray-700 border-gray-300 hover:border-[#1B1C1A]'
          }`}
        >
          <GraduationCap className="w-3.5 h-3.5" />
          <span>3. GRADING</span>
        </button>

        <button
          onClick={() => setActiveTab('people')}
          className={`px-3 py-1.5 font-bold uppercase rounded-[1px] border transition-all flex items-center gap-1.5 ${
            activeTab === 'people'
              ? 'bg-[#EA580C] text-white border-[#1B1C1A]'
              : 'bg-white text-gray-700 border-gray-300 hover:border-[#1B1C1A]'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>4. PEOPLE</span>
        </button>

        <button
          onClick={() => setActiveTab('communication')}
          className={`px-3 py-1.5 font-bold uppercase rounded-[1px] border transition-all flex items-center gap-1.5 ${
            activeTab === 'communication'
              ? 'bg-[#7C3AED] text-white border-[#1B1C1A]'
              : 'bg-white text-gray-700 border-gray-300 hover:border-[#1B1C1A]'
          }`}
        >
          <Megaphone className="w-3.5 h-3.5" />
          <span>5. COMMUNICATION</span>
        </button>

        <button
          onClick={() => setActiveTab('content')}
          className={`px-3 py-1.5 font-bold uppercase rounded-[1px] border transition-all flex items-center gap-1.5 ${
            activeTab === 'content'
              ? 'bg-[#0D9488] text-white border-[#1B1C1A]'
              : 'bg-white text-gray-700 border-gray-300 hover:border-[#1B1C1A]'
          }`}
        >
          <FolderKanban className="w-3.5 h-3.5" />
          <span>6. CONTENT</span>
        </button>

        <button
          onClick={() => setActiveTab('admin')}
          className={`px-3 py-1.5 font-bold uppercase rounded-[1px] border transition-all flex items-center gap-1.5 ${
            activeTab === 'admin'
              ? 'bg-[#334155] text-white border-[#1B1C1A]'
              : 'bg-white text-gray-700 border-gray-300 hover:border-[#1B1C1A]'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>7. ADMIN & BACKUP</span>
        </button>
      </div>

      {/* Main Grid for Settings Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

        {/* SECTION 1: CANVAS API & CONNECTION SETTINGS */}
        {(activeTab === 'all' || activeTab === 'api') && (
          <div className="lg:col-span-6 bg-white border-2 border-[#1B1C1A] rounded-[2px] p-5 space-y-4 shadow-sm">
            <div className="border-b border-[#1B1C1A] pb-2 flex items-center justify-between">
              <h3 className="font-bold uppercase text-[#1B1C1A] flex items-center gap-2">
                <Key className="w-4 h-4 text-[#2563EB]" />
                <span>1. CANVAS API & CREDENTIALS</span>
              </h3>
              <span className="px-2 py-0.5 bg-blue-100 text-[#2563EB] border border-[#1B1C1A] font-bold text-[10px]">
                REST v1
              </span>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1">Canvas Institution Host URL:</label>
                <input
                  type="text"
                  value={canvasUrl}
                  onChange={(e) => setCanvasUrl(e.target.value)}
                  className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1">Canvas OAuth / Personal Access Token:</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type={showToken ? 'text' : 'password'}
                      value={apiToken}
                      onChange={(e) => setApiToken(e.target.value)}
                      className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none pr-9"
                    />
                    <button
                      type="button"
                      onClick={() => setShowToken(!showToken)}
                      className="absolute right-2 top-2 text-gray-500 hover:text-black"
                    >
                      {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <button
                    onClick={handleTestConnection}
                    className="px-3 py-2 bg-[#2563EB] text-white border border-[#1B1C1A] font-bold uppercase rounded-[1px] hover:bg-blue-700"
                  >
                    {apiConnectionStatus === 'testing' ? 'TESTING...' : 'VERIFY LINK'}
                  </button>
                </div>
                <p className="text-[10px] text-gray-500 mt-1">
                  Tokens are stored encrypted in your browser's extension storage and never shared with 3rd parties.
                </p>
              </div>

              <div className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[2px] space-y-2">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="font-bold text-[#1B1C1A]">Auto-Retry API Throttling (429 Rate Limit)</span>
                  <input
                    type="checkbox"
                    checked={autoRetry429}
                    onChange={(e) => setAutoRetry429(e.target.checked)}
                    className="w-4 h-4 accent-[#2563EB]"
                  />
                </label>
                <span className="text-[10px] text-gray-500 block">
                  Automatically wait & exponential backoff on Instructure API rate limit spikes.
                </span>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 2: ASSIGNMENTS MODULE SETTINGS */}
        {(activeTab === 'all' || activeTab === 'assignments') && (
          <div className="lg:col-span-6 bg-white border-2 border-[#1B1C1A] rounded-[2px] p-5 space-y-4 shadow-sm">
            <div className="border-b border-[#1B1C1A] pb-2 flex items-center justify-between">
              <h3 className="font-bold uppercase text-[#1B1C1A] flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#2563EB]" />
                <span>2. ASSIGNMENTS MODULE DEFAULTS</span>
              </h3>
              <span className="px-2 py-0.5 bg-blue-100 text-[#2563EB] border border-[#1B1C1A] font-bold text-[10px]">
                AUTHORING
              </span>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 uppercase mb-1">Default Submission Type:</label>
                  <select
                    value={defaultSubmissionType}
                    onChange={(e) => setDefaultSubmissionType(e.target.value)}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  >
                    <option value="Online">Online Uploads</option>
                    <option value="Paper">On Paper / In Class</option>
                    <option value="External Tool">External LTI Tool</option>
                    <option value="No Submission">No Submission Required</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-gray-700 uppercase mb-1">Default Points Possible:</label>
                  <input
                    type="number"
                    value={defaultPointsPossible}
                    onChange={(e) => setDefaultPointsPossible(Number(e.target.value))}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1">Allowed File Extensions:</label>
                <input
                  type="text"
                  value={allowedExtensions}
                  onChange={(e) => setAllowedExtensions(e.target.value)}
                  placeholder="pdf, docx, zip"
                  className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                />
              </div>

              <div className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[2px] space-y-2">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="font-bold text-[#1B1C1A]">Auto-Publish New Created Assignments</span>
                  <input
                    type="checkbox"
                    checked={autoPublishNewAssignments}
                    onChange={(e) => setAutoPublishNewAssignments(e.target.checked)}
                    className="w-4 h-4 accent-[#2563EB]"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer pt-1 border-t border-gray-200">
                  <span className="font-bold text-[#1B1C1A]">Default Enable Turnitin Similarity Report</span>
                  <input
                    type="checkbox"
                    checked={defaultTurnitinScan}
                    onChange={(e) => setDefaultTurnitinScan(e.target.checked)}
                    className="w-4 h-4 accent-[#2563EB]"
                  />
                </label>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 3: GRADING MODULE SETTINGS */}
        {(activeTab === 'all' || activeTab === 'grading') && (
          <div className="lg:col-span-6 bg-white border-2 border-[#1B1C1A] rounded-[2px] p-5 space-y-4 shadow-sm">
            <div className="border-b border-[#1B1C1A] pb-2 flex items-center justify-between">
              <h3 className="font-bold uppercase text-[#1B1C1A] flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-[#059669]" />
                <span>3. GRADING MODULE & LATE POLICY</span>
              </h3>
              <span className="px-2 py-0.5 bg-emerald-100 text-[#059669] border border-[#1B1C1A] font-bold text-[10px]">
                CALCULATIONS
              </span>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 uppercase mb-1">Late Penalty % Per Day:</label>
                  <input
                    type="number"
                    step="0.5"
                    value={latePenaltyPerDay}
                    onChange={(e) => setLatePenaltyPerDay(Number(e.target.value))}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none text-[#059669]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 uppercase mb-1">Maximum Penalty Cap %:</label>
                  <input
                    type="number"
                    value={maxLatePenaltyCap}
                    onChange={(e) => setMaxLatePenaltyCap(Number(e.target.value))}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 uppercase mb-1">Missing Work Grace (Hours):</label>
                  <input
                    type="number"
                    value={missingWorkGraceHours}
                    onChange={(e) => setMissingWorkGraceHours(Number(e.target.value))}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 uppercase mb-1">Grade Curving Rounding:</label>
                  <select
                    value={curvingRoundingRule}
                    onChange={(e) => setCurvingRoundingRule(e.target.value)}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  >
                    <option value="STANDARD">Standard Nearest Half (0.5)</option>
                    <option value="CEIL">Round Up Always (Ceil)</option>
                    <option value="FLOOR">Truncate Decimal (Floor)</option>
                  </select>
                </div>
              </div>

              <div className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[2px]">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="font-bold text-[#1B1C1A]">Enable SpeedGrader Comment Bank Suggestions</span>
                  <input
                    type="checkbox"
                    checked={enableSpeedGraderCommentBank}
                    onChange={(e) => setEnableSpeedGraderCommentBank(e.target.checked)}
                    className="w-4 h-4 accent-[#059669]"
                  />
                </label>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 4: PEOPLE & ROSTER SETTINGS */}
        {(activeTab === 'all' || activeTab === 'people') && (
          <div className="lg:col-span-6 bg-white border-2 border-[#1B1C1A] rounded-[2px] p-5 space-y-4 shadow-sm">
            <div className="border-b border-[#1B1C1A] pb-2 flex items-center justify-between">
              <h3 className="font-bold uppercase text-[#1B1C1A] flex items-center gap-2">
                <Users className="w-4 h-4 text-[#EA580C]" />
                <span>4. PEOPLE & ROSTER PRIVACY</span>
              </h3>
              <span className="px-2 py-0.5 bg-orange-100 text-[#EA580C] border border-[#1B1C1A] font-bold text-[10px]">
                FERPA
              </span>
            </div>

            <div className="space-y-3">
              <div className="p-3 bg-orange-50 border border-orange-300 rounded-[2px]">
                <label className="flex items-center justify-between cursor-pointer">
                  <div className="pr-2">
                    <span className="font-bold text-[#1B1C1A] block">Enable FERPA Privacy Mask</span>
                    <span className="text-[10px] text-gray-600 block">
                      Mask student emails & IDs when recording screen or sharing views in public.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={ferpaMaskEnabled}
                    onChange={(e) => setFerpaMaskEnabled(e.target.checked)}
                    className="w-4 h-4 accent-[#EA580C]"
                  />
                </label>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 uppercase mb-1">Inactivity Alert (Days):</label>
                  <input
                    type="number"
                    value={inactivityThresholdDays}
                    onChange={(e) => setInactivityThresholdDays(Number(e.target.value))}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 uppercase mb-1">Roster Name Format:</label>
                  <select
                    value={nameFormat}
                    onChange={(e) => setNameFormat(e.target.value)}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  >
                    <option value="LAST_FIRST">Last Name, First Name</option>
                    <option value="FIRST_LAST">First Name Last Name</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 5: COMMUNICATION & NUDGES SETTINGS */}
        {(activeTab === 'all' || activeTab === 'communication') && (
          <div className="lg:col-span-6 bg-white border-2 border-[#1B1C1A] rounded-[2px] p-5 space-y-4 shadow-sm">
            <div className="border-b border-[#1B1C1A] pb-2 flex items-center justify-between">
              <h3 className="font-bold uppercase text-[#1B1C1A] flex items-center gap-2">
                <Megaphone className="w-4 h-4 text-[#7C3AED]" />
                <span>5. COMMUNICATION & DISPATCH</span>
              </h3>
              <span className="px-2 py-0.5 bg-purple-100 text-[#7C3AED] border border-[#1B1C1A] font-bold text-[10px]">
                NUDGES
              </span>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 uppercase mb-1">Outbound Dispatch Provider:</label>
                  <select
                    value={outboundProvider}
                    onChange={(e) => setOutboundProvider(e.target.value)}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  >
                    <option value="CANVAS_INBOX">Canvas Conversations (Inbox API)</option>
                    <option value="SENDGRID">SendGrid Transactional Email</option>
                    <option value="DIRECT_SMTP">Institutional Direct SMTP</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-gray-700 uppercase mb-1">Max Nudges / Hour:</label>
                  <input
                    type="number"
                    value={nudgeRateLimit}
                    onChange={(e) => setNudgeRateLimit(Number(e.target.value))}
                    className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1">Default Office Hours URL:</label>
                <input
                  type="text"
                  value={officeHoursLink}
                  onChange={(e) => setOfficeHoursLink(e.target.value)}
                  className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                />
              </div>

              <div className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[2px]">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="font-bold text-[#1B1C1A]">Respect Student Quiet Hours (22:00 - 07:00)</span>
                  <input
                    type="checkbox"
                    checked={quietHoursEnabled}
                    onChange={(e) => setQuietHoursEnabled(e.target.checked)}
                    className="w-4 h-4 accent-[#7C3AED]"
                  />
                </label>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 6: CONTENT & MODULES SETTINGS */}
        {(activeTab === 'all' || activeTab === 'content') && (
          <div className="lg:col-span-6 bg-white border-2 border-[#1B1C1A] rounded-[2px] p-5 space-y-4 shadow-sm">
            <div className="border-b border-[#1B1C1A] pb-2 flex items-center justify-between">
              <h3 className="font-bold uppercase text-[#1B1C1A] flex items-center gap-2">
                <FolderKanban className="w-4 h-4 text-[#0D9488]" />
                <span>6. CONTENT & MODULE RULES</span>
              </h3>
              <span className="px-2 py-0.5 bg-teal-100 text-[#0D9488] border border-[#1B1C1A] font-bold text-[10px]">
                PREREQUISITES
              </span>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1">External Broken Link Scanner:</label>
                <select
                  value={brokenLinkScanFrequency}
                  onChange={(e) => setBrokenLinkScanFrequency(e.target.value)}
                  className="w-full p-2 bg-[#FAF9F5] border border-[#1B1C1A] font-bold rounded-[1px] outline-none"
                >
                  <option value="WEEKLY">Weekly Automated Background Scan</option>
                  <option value="ON_DEMAND">Manual On-Demand Scan Only</option>
                  <option value="DISABLED">Disable Scanner</option>
                </select>
              </div>

              <div className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[2px] space-y-2">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="font-bold text-[#1B1C1A]">Enforce Sequential Module Prerequisites</span>
                  <input
                    type="checkbox"
                    checked={enforcePrerequisites}
                    onChange={(e) => setEnforcePrerequisites(e.target.checked)}
                    className="w-4 h-4 accent-[#0D9488]"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer pt-1 border-t border-gray-200">
                  <span className="font-bold text-[#1B1C1A]">Auto-Lock Past Semester Modules</span>
                  <input
                    type="checkbox"
                    checked={autoLockCompletedModules}
                    onChange={(e) => setAutoLockCompletedModules(e.target.checked)}
                    className="w-4 h-4 accent-[#0D9488]"
                  />
                </label>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 7: ADMIN, SECURITY & BACKUP SETTINGS */}
        {(activeTab === 'all' || activeTab === 'admin') && (
          <div className="lg:col-span-12 bg-white border-2 border-[#1B1C1A] rounded-[2px] p-5 space-y-4 shadow-sm">
            <div className="border-b border-[#1B1C1A] pb-2 flex items-center justify-between">
              <h3 className="font-bold uppercase text-[#1B1C1A] flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#334155]" />
                <span>7. ADMIN, SECURITY & BACKUP MAINTENANCE</span>
              </h3>
              <span className="px-2 py-0.5 bg-slate-200 text-[#334155] border border-[#1B1C1A] font-bold text-[10px]">
                MAINTENANCE
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[2px] space-y-2">
                <span className="font-bold text-[#1B1C1A] block">Inactivity PIN Lock Timeout:</span>
                <select
                  value={inactivityLockTimeout}
                  onChange={(e) => setInactivityLockTimeout(e.target.value)}
                  className="w-full p-2 bg-white border border-[#1B1C1A] font-bold rounded-[1px]"
                >
                  <option value="15_MIN">15 Minutes</option>
                  <option value="30_MIN">30 Minutes</option>
                  <option value="60_MIN">1 Hour</option>
                  <option value="NEVER">Never Lock</option>
                </select>
              </div>

              <div className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[2px] space-y-2">
                <span className="font-bold text-[#1B1C1A] block">Audit Log History Retention:</span>
                <select
                  value={auditLogRetention}
                  onChange={(e) => setAuditLogRetention(e.target.value)}
                  className="w-full p-2 bg-white border border-[#1B1C1A] font-bold rounded-[1px]"
                >
                  <option value="30_DAYS">30 Days</option>
                  <option value="90_DAYS">90 Days</option>
                  <option value="1_YEAR">1 Full Year</option>
                </select>
              </div>

              <div className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[2px] flex flex-col justify-between">
                <div>
                  <span className="font-bold text-[#1B1C1A] block">Factory Reset All Settings:</span>
                  <p className="text-[10px] text-gray-500">Restore default values across all 6 modules.</p>
                </div>
                <button
                  onClick={handleResetDefaults}
                  className="mt-2 w-full py-1.5 bg-red-50 text-red-700 border border-red-300 font-bold uppercase rounded-[1px] hover:bg-red-100 flex items-center justify-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>RESET TO DEFAULTS</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* SECTION 8: DEVELOPER MODE & DIAGNOSTICS */}
        <div className="lg:col-span-12 bg-[#EFEEEA] border border-[#1B1C1A] rounded-[2px] p-5 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <span className="font-bold uppercase text-[#1B1C1A] flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-[#1B1C1A]" />
                <span>CANVAS POWER TOOLS // EXTENSION ENGINE DIAGNOSTICS</span>
              </span>
              <p
                onClick={handleVersionClick}
                className="text-xs text-gray-600 cursor-pointer select-none mt-0.5 hover:text-black"
              >
                Version 1.0.0 (Build 2026.07) · Click version string 7x to reveal Developer Mode {devClicks > 0 && `(${devClicks}/7)`}
              </p>
            </div>

            {developerUnlocked ? (
              <span className="px-2.5 py-1 bg-[#1B1C1A] text-[#FEF08A] font-bold uppercase rounded-[1px] flex items-center gap-1 text-xs">
                <Zap className="w-3.5 h-3.5 fill-current" /> DEVELOPER MODE ACTIVE
              </span>
            ) : (
              <span className="text-[10px] text-gray-500 font-bold uppercase">
                STATUS: PRODUCTION BUILD
              </span>
            )}
          </div>

          {developerUnlocked && (
            <div className="pt-3 border-t border-gray-300 grid grid-cols-1 sm:grid-cols-3 gap-3 animate-fadeIn">
              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1 text-[10px]">Simulated Latency (ms):</label>
                <input
                  type="number"
                  value={apiRequestDelayMs}
                  onChange={(e) => setApiRequestDelayMs(Number(e.target.value))}
                  className="w-full p-1.5 bg-white border border-[#1B1C1A] font-bold rounded-[1px]"
                />
              </div>

              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1 text-[10px]">Extension Log Level:</label>
                <select
                  value={logLevel}
                  onChange={(e) => setLogLevel(e.target.value)}
                  className="w-full p-1.5 bg-white border border-[#1B1C1A] font-bold rounded-[1px]"
                >
                  <option value="DEBUG">DEBUG (Verbose REST payloads)</option>
                  <option value="INFO">INFO (Standard Events)</option>
                  <option value="WARN">WARN (Errors & Retries only)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1 text-[10px]">Design System Palette:</label>
                <select
                  value={themeMode}
                  onChange={(e) => setThemeMode(e.target.value as any)}
                  className="w-full p-1.5 bg-white border border-[#1B1C1A] font-bold rounded-[1px]"
                >
                  <option value="bauhaus">Bauhaus (Flat High-Contrast Grid)</option>
                  <option value="accessible">Accessible High Contrast</option>
                </select>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
