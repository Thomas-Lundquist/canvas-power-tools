import React, { useState } from 'react';
import {
  GraduationCap,
  MessageSquare,
  Users,
  Command,
  CheckSquare,
  Check,
  Send,
  Plus,
  Play,
  FileText
} from 'lucide-react';

export const SpeedGraderSuiteScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'comment-bank' | 'progress-panel' | 'shortcuts' | 'bulk-actions'>('comment-bank');
  const [comments, setComments] = useState([
    { id: 'cb-1', category: 'General Praise', text: 'Great analysis on {assignment_name}, {first_name}! Strong supporting arguments.' },
    { id: 'cb-2', category: 'Constructive Feedback', text: 'Hi {first_name}, please make sure to include a formal reference list in future drafts.' },
    { id: 'cb-3', category: 'Formatting & Mechanics', text: 'Check your paragraph spacing and citation style according to the lab guide.' }
  ]);

  const [copiedToken, setCopiedToken] = useState(false);

  const handleInsertComment = () => {
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            SPEEDGRADER SUITE & COMMENT BANK
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Injected controls for Canvas SpeedGrader: comment bank with tokens, student progress panel, and shortcuts.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => setActiveTab('comment-bank')}
            className={`px-3 py-1.5 font-bold uppercase rounded-[2px] border border-[#1B1C1A] ${
              activeTab === 'comment-bank' ? 'bg-[#059669] text-white' : 'bg-white text-[#1B1C1A]'
            }`}
          >
            COMMENT BANK ({comments.length})
          </button>

          <button
            onClick={() => setActiveTab('progress-panel')}
            className={`px-3 py-1.5 font-bold uppercase rounded-[2px] border border-[#1B1C1A] ${
              activeTab === 'progress-panel' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A]'
            }`}
          >
            PROGRESS PANEL
          </button>

          <button
            onClick={() => setActiveTab('shortcuts')}
            className={`px-3 py-1.5 font-bold uppercase rounded-[2px] border border-[#1B1C1A] ${
              activeTab === 'shortcuts' ? 'bg-[#1B1C1A] text-white' : 'bg-white text-[#1B1C1A]'
            }`}
          >
            SHORTCUTS
          </button>
        </div>
      </div>

      {activeTab === 'comment-bank' && (
        <div className="bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-gray-200 pb-3">
            <h3 className="font-bold text-gray-600 uppercase">SAVED COMMENT BANK LIBRARY</h3>
            <button className="px-3 py-1.5 bg-[#059669] text-white font-bold uppercase rounded-[2px] flex items-center gap-1">
              <Plus className="w-3.5 h-3.5" />
              <span>ADD SAVED COMMENT</span>
            </button>
          </div>

          <div className="space-y-3">
            {comments.map((c) => (
              <div key={c.id} className="p-4 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] flex items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] font-bold text-[#059669] uppercase bg-emerald-50 px-1.5 py-0.5 border border-emerald-200">
                    {c.category}
                  </span>
                  <p className="font-medium text-sm text-[#1B1C1A] mt-2">{c.text}</p>
                </div>

                <button
                  onClick={handleInsertComment}
                  className="px-3 py-1.5 bg-white hover:bg-[#EFEEEA] border border-[#1B1C1A] text-[#1B1C1A] font-bold uppercase rounded-[2px] whitespace-nowrap shrink-0 flex items-center gap-1.5"
                >
                  {copiedToken ? <Check className="w-3.5 h-3.5 text-[#059669]" /> : <Send className="w-3.5 h-3.5" />}
                  <span>{copiedToken ? 'INSERTED!' : 'INSERT TO SPEEDGRADER'}</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'shortcuts' && (
        <div className="bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-4 font-mono text-xs">
          <h3 className="font-bold text-gray-600 uppercase border-b border-gray-200 pb-2">
            SPEEDGRADER KEYBOARD SHORTCUTS REFERENCE
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              { key: 'Alt + Enter', action: 'Submit grade and advance to next student' },
              { key: 'Alt + Right', action: 'Navigate to next student' },
              { key: 'Alt + Left', action: 'Navigate to previous student' },
              { key: 'Alt + G', action: 'Focus grade entry input field' },
              { key: 'Alt + C', action: 'Focus comment entry field' },
              { key: 'Alt + 1..9', action: 'Quick insert saved comment #1 through #9' }
            ].map((sc, idx) => (
              <div key={idx} className="p-3 bg-[#FAF9F5] border border-gray-300 rounded-[2px] flex items-center justify-between">
                <span className="font-bold text-[#1B1C1A]">{sc.action}</span>
                <span className="px-2 py-1 bg-[#1B1C1A] text-[#FEF08A] font-bold rounded-[1px]">
                  {sc.key}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
