import React, { useState } from 'react';
import { INITIAL_STUDENTS } from '../../data/mockData';
import { Student } from '../../types';
import { UserPlus, Search, ChevronLeft, ChevronRight, Activity, Percent, Users } from 'lucide-react';

export const StudentDirectoryScreen: React.FC = () => {
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [showAddModal, setShowAddModal] = useState(false);

  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newSection, setNewSection] = useState('INTRO TO BAUHAUS');

  const filteredStudents = students.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.section.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newEmail) return;

    const newStudent: Student = {
      id: `st-${Date.now()}`,
      name: newName,
      email: newEmail,
      studentId: `#ST-${Math.floor(10000 + Math.random() * 90000)}`,
      section: newSection,
      sectionColor: newSection.includes('BAUHAUS') ? 'yellow' : 'blue',
      avatarUrl: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`
    };

    setStudents([newStudent, ...students]);
    setNewName('');
    setNewEmail('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1B1C1A] pb-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-black text-[#1B1C1A] tracking-tight uppercase">
            STUDENT DIRECTORY
          </h1>
          <p className="text-xs text-gray-600 mt-1 max-w-xl">
            Manage academic enrollments, section assignments, and access to accommodations across the current semester.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 bg-[#EA580C] text-white border border-[#1B1C1A] text-xs font-bold uppercase tracking-wider rounded-[2px] hover:bg-[#C2410C] flex items-center gap-1.5"
        >
          <UserPlus className="w-4 h-4" />
          <span>ADD STUDENT</span>
        </button>
      </div>

      {/* 3 Metric Summary Blocks */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Metric 1 */}
        <div className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] flex flex-col justify-between">
          <div className="text-xs font-mono font-bold text-gray-500 uppercase tracking-widest flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-[#1B1C1A]" />
            <span>TOTAL STUDENTS</span>
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-4xl font-black text-[#1B1C1A]">1,248</span>
            <span className="text-xs font-bold text-[#EA580C]">+12%</span>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] flex flex-col justify-between">
          <div className="text-xs font-mono font-bold text-gray-500 uppercase tracking-widest flex items-center gap-1.5">
            <Percent className="w-3.5 h-3.5 text-[#1B1C1A]" />
            <span>AVERAGE GRADE</span>
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-4xl font-black text-[#1B1C1A]">84%</span>
            <span className="text-xs font-bold text-gray-500">class avg</span>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white border border-[#1B1C1A] p-4 rounded-[2px] flex flex-col justify-between relative overflow-hidden">
          <div className="text-xs font-mono font-bold text-gray-500 uppercase tracking-widest flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-[#059669]" />
            <span>SYSTEM HEALTH</span>
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-4xl font-black text-[#1B1C1A]">99.9%</span>
          </div>
          <div className="absolute right-[-10px] bottom-[-10px] w-16 h-16 bg-[#2563EB]/10 rotate-45 pointer-events-none" />
        </div>
      </div>

      {/* Search Input Bar */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Filter by name, email, student ID, or course section..."
          className="w-full bg-white border border-[#1B1C1A] pl-9 pr-4 py-2 text-xs font-medium rounded-[2px] focus:outline-none focus:ring-1 focus:ring-[#EA580C]"
        />
      </div>

      {/* Main Student Directory Table */}
      <div className="bg-white border border-[#1B1C1A] rounded-[2px] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#EFEEEA] border-b border-[#1B1C1A] text-xs font-bold text-gray-600 uppercase tracking-wider">
                <th className="py-2.5 px-4">NAME</th>
                <th className="py-2.5 px-4">STUDENT ID</th>
                <th className="py-2.5 px-4">SECTION</th>
                <th className="py-2.5 px-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E3E2DF] text-xs">
              {filteredStudents.map((student) => (
                <tr key={student.id} className="hover:bg-[#FAF9F5] transition-colors">
                  {/* Name + Avatar */}
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={student.avatarUrl}
                        alt={student.name}
                        className="w-8 h-8 rounded-[2px] border border-[#1B1C1A] object-cover shrink-0"
                      />
                      <div>
                        <div className="font-bold text-[#1B1C1A]">{student.name}</div>
                        <div className="text-xs text-gray-500 font-mono">{student.email}</div>
                      </div>
                    </div>
                  </td>

                  {/* Student ID */}
                  <td className="py-3 px-4 font-mono font-bold text-gray-700">
                    {student.studentId}
                  </td>

                  {/* Course Section Pill */}
                  <td className="py-3 px-4">
                    <span
                      className={`inline-block px-2.5 py-1 text-xs font-bold uppercase rounded-[2px] border border-[#1B1C1A] ${
                        student.sectionColor === 'yellow'
                          ? 'bg-[#FEF08A] text-[#7A5500]'
                          : student.sectionColor === 'blue'
                          ? 'bg-[#BFDBFE] text-[#1E40AF]'
                          : 'bg-[#CCFBF1] text-[#0F766E]'
                      }`}
                    >
                      {student.section}
                    </span>
                  </td>

                  {/* Action Buttons */}
                  <td className="py-3 px-4 text-right">
                    <button className="px-2.5 py-1 bg-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px] hover:bg-[#EFEEEA]">
                      VIEW PROFILE
                    </button>
                  </td>
                </tr>
              ))}

              {filteredStudents.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-8 text-center text-xs text-gray-500 font-mono">
                    NO STUDENTS FOUND MATCHING SEARCH QUERY.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bauhaus Pagination Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
        <div className="text-xs font-mono text-gray-600 font-bold uppercase">
          SHOWING 1–{filteredStudents.length} OF 1,248 STUDENTS
        </div>

        <div className="flex items-center gap-1 font-mono text-xs font-bold">
          <button
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(currentPage - 1)}
            className="p-1.5 bg-white border border-[#1B1C1A] rounded-[2px] disabled:opacity-40 hover:bg-[#EFEEEA]"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            onClick={() => setCurrentPage(1)}
            className={`w-7 h-7 border border-[#1B1C1A] rounded-[2px] flex items-center justify-center ${
              currentPage === 1 ? 'bg-[#EA580C] text-white' : 'bg-white text-[#1B1C1A]'
            }`}
          >
            1
          </button>

          <button
            onClick={() => setCurrentPage(2)}
            className={`w-7 h-7 border border-[#1B1C1A] rounded-[2px] flex items-center justify-center ${
              currentPage === 2 ? 'bg-[#EA580C] text-white' : 'bg-white text-[#1B1C1A]'
            }`}
          >
            2
          </button>

          <button
            onClick={() => setCurrentPage(3)}
            className={`w-7 h-7 border border-[#1B1C1A] rounded-[2px] flex items-center justify-center ${
              currentPage === 3 ? 'bg-[#EA580C] text-white' : 'bg-white text-[#1B1C1A]'
            }`}
          >
            3
          </button>

          <span className="px-1 text-gray-500">...</span>

          <button className="w-7 h-7 bg-white border border-[#1B1C1A] rounded-[2px] flex items-center justify-center">
            50
          </button>

          <button
            onClick={() => setCurrentPage(currentPage + 1)}
            className="p-1.5 bg-white border border-[#1B1C1A] rounded-[2px] hover:bg-[#EFEEEA]"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Add Student Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <form
            onSubmit={handleAddStudent}
            className="bg-white border-2 border-[#1B1C1A] rounded-[2px] w-full max-w-md p-6 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-[#1B1C1A] pb-3">
              <h3 className="text-base font-bold text-[#1B1C1A] uppercase">Add New Student</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-xs font-bold border border-[#1B1C1A] px-2 py-0.5 rounded-[2px]"
              >
                ✕
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase mb-1">Full Name</label>
              <input
                type="text"
                required
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. Walter Gropius"
                className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs rounded-[2px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase mb-1">Email Address</label>
              <input
                type="email"
                required
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="wgropius@bauhaus.edu"
                className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs rounded-[2px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase mb-1">Assign Section</label>
              <select
                value={newSection}
                onChange={(e) => setNewSection(e.target.value)}
                className="w-full bg-[#FAF9F5] border border-[#1B1C1A] px-3 py-2 text-xs rounded-[2px]"
              >
                <option value="INTRO TO BAUHAUS">INTRO TO BAUHAUS</option>
                <option value="ADVANCED PHYSICS">ADVANCED PHYSICS</option>
                <option value="STRUCTURAL GEOMETRY">STRUCTURAL GEOMETRY</option>
              </select>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-3 py-1.5 border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-[#EA580C] text-white border border-[#1B1C1A] text-xs font-bold uppercase rounded-[2px]"
              >
                Add Student
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
