import React, { useState } from 'react';
import {
  Users,
  Shuffle,
  Plus,
  Check,
  Folder,
  Layers,
  ArrowRight
} from 'lucide-react';

interface GroupSet {
  id: string;
  name: string;
  groupsCount: number;
  totalStudents: number;
  mode: 'random' | 'alphabetical' | 'performance';
}

export const StudentGroupsScreen: React.FC = () => {
  const [groupSets, setGroupSets] = useState<GroupSet[]>([
    { id: 'gs-1', name: 'Lab Experiment Groups', groupsCount: 4, totalStudents: 24, mode: 'random' },
    { id: 'gs-2', name: 'Midterm Research Teams', groupsCount: 6, totalStudents: 24, mode: 'performance' }
  ]);

  const [selectedSet, setSelectedSet] = useState<GroupSet>(groupSets[0]);
  const [autoAssigned, setAutoAssigned] = useState(false);

  const handleRunAutoAssign = () => {
    setAutoAssigned(true);
    setTimeout(() => setAutoAssigned(false), 2500);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-[#1B1C1A] pb-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-[#1B1C1A] uppercase">
            STUDENT GROUP MANAGER
          </h1>
          <p className="text-xs text-gray-600 font-mono mt-0.5">
            Auto-assign student groups by random distribution, alphabetical split, or performance tiers.
          </p>
        </div>

        <button
          onClick={handleRunAutoAssign}
          className={`px-4 py-2 border border-[#1B1C1A] font-mono font-bold text-xs uppercase rounded-[2px] transition-all flex items-center gap-2 ${
            autoAssigned ? 'bg-[#FEF08A] text-[#1B1C1A]' : 'bg-[#EA580C] text-white hover:bg-orange-700'
          }`}
        >
          {autoAssigned ? (
            <>
              <Check className="w-4 h-4 text-[#1B1C1A]" />
              <span>AUTO-ASSIGNED TO CANVAS!</span>
            </>
          ) : (
            <>
              <Shuffle className="w-4 h-4" />
              <span>RUN AUTO-ASSIGN ALGORITHM</span>
            </>
          )}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Sets List */}
        <div className="lg:col-span-4 space-y-3 font-mono text-xs">
          <div className="bg-[#EFEEEA] border border-[#1B1C1A] p-3 font-bold uppercase flex items-center justify-between">
            <span>GROUP SETS ({groupSets.length})</span>
            <button className="text-[#EA580C] font-bold">+ NEW SET</button>
          </div>

          <div className="space-y-2">
            {groupSets.map((gs) => (
              <div
                key={gs.id}
                onClick={() => setSelectedSet(gs)}
                className={`p-4 border rounded-[2px] cursor-pointer transition-all ${
                  selectedSet.id === gs.id
                    ? 'bg-white border-[#1B1C1A] border-l-4 border-l-[#EA580C]'
                    : 'bg-[#FAF9F5] border-gray-300'
                }`}
              >
                <h4 className="font-bold text-sm text-[#1B1C1A]">{gs.name}</h4>
                <div className="flex items-center justify-between text-[10px] text-gray-500 mt-2">
                  <span>{gs.groupsCount} Groups</span>
                  <span>{gs.totalStudents} Students</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Groups Breakdown */}
        <div className="lg:col-span-8 bg-white border border-[#1B1C1A] rounded-[2px] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-gray-200 pb-3 font-mono text-xs">
            <h3 className="font-bold uppercase text-[#1B1C1A]">{selectedSet.name} BREAKDOWN</h3>
            <span className="text-gray-500">MODE: {selectedSet.mode.toUpperCase()}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((num) => (
              <div key={num} className="p-4 bg-[#FAF9F5] border border-[#1B1C1A] rounded-[2px] space-y-2 font-mono text-xs">
                <div className="flex items-center justify-between font-bold border-b border-gray-300 pb-2">
                  <span className="text-[#EA580C]">GROUP {num}</span>
                  <span className="text-gray-500">6 STUDENTS</span>
                </div>
                <div className="space-y-1 text-gray-700 pt-1">
                  <div>· Alex Rivera</div>
                  <div>· Jordan Chen</div>
                  <div>· Taylor Swift</div>
                  <div>· Morgan Lee</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
