import { ColorToken, TypographyToken } from '../types';

export const SYSTEM_META = {
  title: "Lightweight Bauhaus Design System",
  subtitle: "21st-Century Windows 98 Squared Grid Architecture",
  version: "v2.4.0",
  lastUpdated: "July 2026",
  archetype: "B4 Archetype System - Crisp Grid Functionalism",
  description: "A digital design brief merging early 20th-century Bauhaus constructivism with modern Swiss layout precision and 90s OS squared structural borders."
};

export const COLOR_TOKENS: ColorToken[] = [
  // Foundation
  { name: "Surface Canvas", hex: "#FAF9F5", role: "Primary background canvas ('paper' texture)", category: "foundation" },
  { name: "Surface Container", hex: "#EFEEEA", role: "Section background, secondary panel container", category: "foundation" },
  { name: "Surface Low", hex: "#F4F4F0", role: "Slight contrast container fill", category: "foundation" },
  { name: "Surface Bright / Card", hex: "#FFFFFF", role: "Card backgrounds, input field interiors", category: "foundation" },
  { name: "On Surface (Dark Slate)", hex: "#1B1C1A", role: "Primary typography, sharp structural borders", category: "foundation" },

  // Primary Triad (Bauhaus Colors)
  { name: "Primary Red", hex: "#B7102A", role: "High-priority actions, destructive alerts, key visual emphasis", category: "primary-triad" },
  { name: "Primary Blue", hex: "#485F84", role: "Primary interactive buttons, focused inputs, course pills", category: "primary-triad" },
  { name: "Primary Yellow / Ochre", hex: "#7A5500", role: "Warnings, active highlights, tag badges", category: "primary-triad" },

  // Module Category Accents
  { name: "Module Blue", hex: "#2563EB", role: "Assignments module top accent border", category: "module-accent" },
  { name: "Module Green", hex: "#059669", role: "Grading module top accent border & published status", category: "module-accent" },
  { name: "Module Purple", hex: "#7C3AED", role: "Communication module top accent border & recipient selection", category: "module-accent" },
  { name: "Module Orange", hex: "#EA580C", role: "People module top accent border", category: "module-accent" },
  { name: "Module Teal", hex: "#0D9488", role: "Content & Module Manager accent block", category: "module-accent" },
  { name: "Module Dark Slate", hex: "#334155", role: "Setup module top accent border", category: "module-accent" },

  // Borders & Grid
  { name: "Solid Border Stroke", hex: "#1B1C1A", role: "1px crisp outer frame borders on all cards, inputs, buttons", category: "border-stroke" },
  { name: "Subtle Grid Line", hex: "#E3E2DF", role: "Internal table dividers and subtle grid structures", category: "border-stroke" }
];

export const TYPOGRAPHY_TOKENS: TypographyToken[] = [
  {
    name: "Display Title",
    fontFamily: "Inter / System Sans",
    fontSize: "64px (4rem)",
    fontWeight: "800 (Extra Bold)",
    lineHeight: "1.1",
    letterSpacing: "-0.02em",
    usage: "Page headers, main screen banners (e.g. 'DASHBOARD')"
  },
  {
    name: "Headline Large",
    fontFamily: "Inter / System Sans",
    fontSize: "32px (2rem)",
    fontWeight: "700 (Bold)",
    lineHeight: "1.2",
    letterSpacing: "-0.01em",
    usage: "Section titles, module headers (e.g. 'STUDENT DIRECTORY')"
  },
  {
    name: "Headline Medium",
    fontFamily: "Inter / System Sans",
    fontSize: "20px (1.25rem)",
    fontWeight: "600 (Semi Bold)",
    lineHeight: "1.4",
    usage: "Card titles, subsection headings (e.g. 'Assignments', 'Grading')"
  },
  {
    name: "Body Regular",
    fontFamily: "Inter / System Sans",
    fontSize: "16px (1rem)",
    fontWeight: "400 (Regular)",
    lineHeight: "1.5",
    usage: "Standard paragraph text, form descriptions, table row values"
  },
  {
    name: "Label Bold Uppercase",
    fontFamily: "Inter / System Sans",
    fontSize: "12px / 14px",
    fontWeight: "700 (Bold)",
    lineHeight: "1.2",
    letterSpacing: "0.05em (Tracked Out)",
    usage: "Action button text ('OPEN MODULE'), section badges, table headers"
  },
  {
    name: "Label Small Metadata",
    fontFamily: "Inter / System Sans",
    fontSize: "11px / 12px",
    fontWeight: "500 (Medium)",
    lineHeight: "1.2",
    usage: "System status tags ('#ST-99201'), footer metrics, subtle captions"
  }
];

export const DESIGN_PRINCIPLES = [
  {
    number: "01",
    title: "Zero Shadows, Pure Geometry",
    description: "Every container sits flat on a single dimensional plane. Structural depth is defined exclusively through 1px solid dark borders and solid color fills—never soft drop-shadows or ambient blurs."
  },
  {
    number: "02",
    title: "Windows 98 Precision x Modern Bauhaus",
    description: "Inspired by classical 90s operating system window structures—clean rectangular divisions, prominent title banners, strict inset forms, and crisp gridlines—elevated with warm off-white canvas and bold Swiss typography."
  },
  {
    number: "03",
    title: "Top-Border Categorization",
    description: "Modules and functional cards use a distinctive 4px solid top-accent strip (Red, Blue, Green, Purple, Orange, Teal) to denote domain context without cluttering the interior content."
  },
  {
    number: "04",
    title: "Asymmetrical Grid Alignment",
    description: "All components align strictly to a 4px baseline shift and a 12-column Swiss grid. High-contrast line dividers carve up complex data tables into clear, scannable reading columns."
  },
  {
    number: "05",
    title: "Mathematical Corner Radii",
    description: "Corners maintain crisp 0px to 2px radii across cards, buttons, and inputs. When elements nest inside containers, inner corners follow mathematical alignment to prevent awkward visual overlaps."
  }
];

export const BORDER_SPECIFICATIONS = {
  outerFrame: "1px solid #1B1C1A (or #4A4E69)",
  accentStripTop: "4px solid [Module Color] on top boundary",
  accentStripLeft: "4px solid [Module Color] on left boundary",
  tableGridLines: "1px solid #1B1C1A horizontally and vertically between cells",
  shadowRule: "box-shadow: NONE throughout entire application",
  borderRadiusDefault: "2px (rounded-sm) or 0px sharp right angles"
};
