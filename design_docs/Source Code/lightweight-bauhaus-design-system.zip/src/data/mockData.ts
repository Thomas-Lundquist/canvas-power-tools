import { Student, Assignment, CourseModule, GradingItem } from '../types';

export const INITIAL_STUDENTS: Student[] = [
  {
    id: "st-1",
    name: "Elena Rodriguez",
    email: "erodriguez@university.edu",
    studentId: "#ST-99201",
    section: "ADVANCED PHYSICS",
    sectionColor: "blue",
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
  },
  {
    id: "st-2",
    name: "Julian Schmidt",
    email: "jschmidt@university.edu",
    studentId: "#ST-88124",
    section: "INTRO TO BAUHAUS",
    sectionColor: "yellow",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"
  },
  {
    id: "st-3",
    name: "Sarah Chen",
    email: "schen@university.edu",
    studentId: "#ST-77349",
    section: "ADVANCED PHYSICS",
    sectionColor: "blue",
    avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80"
  },
  {
    id: "st-4",
    name: "Amir Hassan",
    email: "ahassan@university.edu",
    studentId: "#ST-44210",
    section: "INTRO TO BAUHAUS",
    sectionColor: "yellow",
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80"
  },
  {
    id: "st-5",
    name: "Maya Lin",
    email: "mlin@university.edu",
    studentId: "#ST-33290",
    section: "STRUCTURAL GEOMETRY",
    sectionColor: "teal",
    avatarUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80"
  },
  {
    id: "st-6",
    name: "David Vance",
    email: "dvance@university.edu",
    studentId: "#ST-11928",
    section: "DIGITAL ARCHITECTURE",
    sectionColor: "purple",
    avatarUrl: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80"
  }
];

export const INITIAL_ASSIGNMENTS: Assignment[] = [
  {
    id: "asn-1",
    title: "Final Project Proposal",
    asnId: "ASGN-2024-001",
    group: "PROJECTS",
    dueDate: "Oct 12, 2026 11:59 PM",
    status: "PUBLISHED",
    checked: false
  },
  {
    id: "asn-2",
    title: "Mid-Term Quiz (Advanced)",
    asnId: "ASGN-2024-042",
    group: "EXAMS",
    dueDate: "Oct 15, 2026 08:00 AM",
    status: "UNPUBLISHED",
    checked: false
  },
  {
    id: "asn-3",
    title: "Module 4: Logic Gates & Bauhaus Circuits",
    asnId: "ASGN-2024-019",
    group: "HOMEWORK",
    dueDate: "Oct 20, 2026 11:59 PM",
    status: "PUBLISHED",
    checked: true
  },
  {
    id: "asn-4",
    title: "System Architecture Review",
    asnId: "ASGN-2024-022",
    group: "LABS",
    dueDate: "Oct 24, 2026 04:00 PM",
    status: "PUBLISHED",
    checked: false
  },
  {
    id: "asn-5",
    title: "Bonus Exercise: Binary Trees & Spatial Grids",
    asnId: "ASGN-2024-030",
    group: "EXTRA CREDIT",
    dueDate: "Nov 01, 2026 11:59 PM",
    status: "UNPUBLISHED",
    checked: false
  }
];

export const INITIAL_MODULES: CourseModule[] = [
  {
    id: "mod-1",
    number: "01",
    title: "Module 01: Foundations of Design Geometry",
    status: "PUBLISHED",
    expanded: true,
    items: [
      { id: "item-1", type: "lecture", title: "Lecture: Euclidean Principles in UI Design", completed: true },
      { id: "item-2", type: "workshop", title: "Workshop: Drawing with Mathematical Precision", completed: false }
    ]
  },
  {
    id: "mod-2",
    number: "02",
    title: "Module 02: Advanced Color Theory & Primary Triads",
    status: "DRAFT",
    expanded: true,
    items: [
      { id: "item-3", type: "video", title: "Video: The Bauhaus Palette Explained", completed: false }
    ]
  },
  {
    id: "mod-3",
    number: "03",
    title: "Module 03: Typographic Systems & Baseline Rhythms",
    status: "PUBLISHED",
    expanded: false,
    items: []
  }
];

export const INITIAL_GRADING_ITEMS: GradingItem[] = [
  {
    id: "grd-1",
    assignment: "Binary Search Trees Lab",
    graded: 45,
    submitted: 45,
    missing: 0,
    due: "Completed"
  },
  {
    id: "grd-2",
    assignment: "Complexity Analysis Essay",
    graded: 32,
    submitted: 45,
    missing: 13,
    due: "Yesterday"
  },
  {
    id: "grd-3",
    assignment: "Memory Leak Debugging",
    graded: 15,
    submitted: 45,
    missing: 30,
    due: "In 2 days"
  },
  {
    id: "grd-4",
    assignment: "Final Project Proposal",
    graded: 0,
    submitted: 45,
    missing: 45,
    due: "In 5 days"
  }
];
