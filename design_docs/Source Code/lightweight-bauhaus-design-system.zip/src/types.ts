export type NavigationTab = 
  | 'design-brief'
  | 'screens'
  | 'component-library'
  | 'token-inspector'
  | 'spec-document'
  | 'app-test';

export type ScreenModule = 
  | 'dashboard'
  | 'announcements'
  | 'rollover-wizard'
  | 'student-directory'
  | 'bulk-editor'
  | 'module-manager'
  | 'grading-dashboard'
  | 'assignment-templates'
  | 'rubric-manager'
  | 'assignment-groups'
  | 'assignment-copy'
  | 'quiz-builder'
  | 'missing-work'
  | 'grade-adjustments'
  | 'late-policy'
  | 'communication-nudges'
  | 'student-groups'
  | 'sections-manager'
  | 'accommodations'
  | 'accommodation-creator'
  | 'speedgrader-suite'
  | 'security-audit'
  | 'settings-preferences'
  | 'grade-outreach';

export interface ColorToken {
  name: string;
  hex: string;
  role: string;
  category: 'foundation' | 'primary-triad' | 'module-accent' | 'border-stroke';
  borderStyle?: string;
}

export interface TypographyToken {
  name: string;
  fontFamily: string;
  fontSize: string;
  fontWeight: string;
  lineHeight: string;
  letterSpacing?: string;
  usage: string;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  studentId: string;
  section: string;
  sectionColor: 'blue' | 'yellow' | 'teal' | 'purple';
  avatarUrl: string;
}

export interface Assignment {
  id: string;
  title: string;
  asnId: string;
  group: string;
  dueDate: string;
  status: 'PUBLISHED' | 'UNPUBLISHED';
  checked?: boolean;
}

export interface ModuleItem {
  id: string;
  type: 'lecture' | 'workshop' | 'video';
  title: string;
  completed: boolean;
}

export interface CourseModule {
  id: string;
  number: string;
  title: string;
  status: 'PUBLISHED' | 'DRAFT';
  items: ModuleItem[];
  expanded?: boolean;
}

export interface GradingItem {
  id: string;
  assignment: string;
  graded: number;
  submitted: number;
  missing: number;
  due: string;
}

export interface SystemThemeConfig {
  strokeWidth: '1px' | '2px' | '3px';
  borderColor: string; // e.g. '#1b1c1a' or '#4a4e69'
  borderRadius: '0px' | '2px' | '4px' | '8px';
  bgCanvas: string; // '#faf9f5' | '#f4f4f0' | '#ffffff'
  primaryAccent: string; // '#b7102a' | '#2563eb' | '#1b1c1a'
}
